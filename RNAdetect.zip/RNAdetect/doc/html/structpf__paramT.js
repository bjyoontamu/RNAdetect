var structpf__paramT =
[
    [ "pf_scale", "structpf__paramT.html#aef40322e7ca1adbd9b438aeda0352e8f", null ],
    [ "temperature", "structpf__paramT.html#aa0e11e9f1f6e212640baf40d7195a014", null ],
    [ "alpha", "structpf__paramT.html#a3d2af9040acfa08295efb50f0219149d", null ],
    [ "model_details", "structpf__paramT.html#a43ec875779c5e7c8bf5fa7e837ec6d09", null ]
];