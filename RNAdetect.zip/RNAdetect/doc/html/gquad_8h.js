var gquad_8h =
[
    [ "get_gquad_matrix", "gquad_8h.html#a8b0784c14fa1208d0aebbebdc1318b7a", null ],
    [ "parse_gquad", "gquad_8h.html#ae41763215b9c64d2a7b67f0df8a28078", null ],
    [ "backtrack_GQuad_IntLoop", "gquad_8h.html#a54475a8eb898fa1e8af8ab5f5375f3be", null ],
    [ "backtrack_GQuad_IntLoop_L", "gquad_8h.html#a118ec7289f1936bd810be7fe50b98212", null ]
];