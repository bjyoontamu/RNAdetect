var group__local__mfe__fold =
[
    [ "Lfold", "group__local__mfe__fold.html#ga16e5a70e60835bb969eaecbe6482f1be", null ],
    [ "Lfoldz", "group__local__mfe__fold.html#gab6d79eecc180f586679f7b85cce5cbe9", null ]
];