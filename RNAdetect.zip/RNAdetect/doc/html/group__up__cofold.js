var group__up__cofold =
[
    [ "part_func_up.h", "part__func__up_8h.html", null ],
    [ "pf_unstru", "group__up__cofold.html#ga5b4ee40e190d2f633cd01cf0d2fe93cf", null ],
    [ "pf_interact", "group__up__cofold.html#ga1aa0aa02bc3a724f87360c03097afd00", null ],
    [ "free_interact", "group__up__cofold.html#gadde308fd5f696dc271b1532aa96fd12f", null ],
    [ "free_pu_contrib_struct", "group__up__cofold.html#gac20bd61824981d45ce0dc9934aa56df8", null ]
];