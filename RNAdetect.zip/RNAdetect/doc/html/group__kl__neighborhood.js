var group__kl__neighborhood =
[
    [ "Calculating MFE representatives of a Distance Based Partitioning", "group__kl__neighborhood__mfe.html", "group__kl__neighborhood__mfe" ],
    [ "Calculate Partition Functions of a Distance Based Partitioning", "group__kl__neighborhood__pf.html", "group__kl__neighborhood__pf" ],
    [ "Stochastic Backtracking of Structures from Distance Based Partitioning", "group__kl__neighborhood__stochbt.html", "group__kl__neighborhood__stochbt" ]
];