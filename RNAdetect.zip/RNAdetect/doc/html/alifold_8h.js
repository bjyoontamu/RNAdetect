var alifold_8h =
[
    [ "update_alifold_params", "alifold_8h.html#ac484c6bd429bafbd353b91044508d8e9", null ],
    [ "alifold", "alifold_8h.html#ga4cf00f0659e5f0480335d69e797f05b1", null ],
    [ "circalifold", "alifold_8h.html#gadbd3b0b1c144cbfb4efe704b2b260f96", null ],
    [ "free_alifold_arrays", "alifold_8h.html#ga72095e4554b5d577250ea14c42acc49e", null ],
    [ "get_mpi", "alifold_8h.html#gaa2d600be90844094ec145ea14a314d2f", null ],
    [ "readribosum", "alifold_8h.html#ga5e125c9586fcd4e2e1559fe76f7289cc", null ],
    [ "energy_of_alistruct", "alifold_8h.html#ga1c48869c03b49a342bf4cbdd61900081", null ],
    [ "encode_ali_sequence", "alifold_8h.html#gaa3e40277c837d6f7603afe319884c786", null ],
    [ "alloc_sequence_arrays", "alifold_8h.html#ga8a560930f7f2582cc3967723a86cfdfa", null ],
    [ "free_sequence_arrays", "alifold_8h.html#ga298a420a8c879202e2617b3f724fde38", null ],
    [ "alipf_fold_par", "alifold_8h.html#ga4d2ff54d8210fc7cceeeff389d4dbd1d", null ],
    [ "alipf_fold", "alifold_8h.html#gad32ded7d753ccaf211ab35782d1f42a9", null ],
    [ "alipf_circ_fold", "alifold_8h.html#ga6b4dde1d43b79ab3753508c46cf50363", null ],
    [ "export_ali_bppm", "alifold_8h.html#gadaaf83394216413505e48d913dbc1b4e", null ],
    [ "alipbacktrack", "alifold_8h.html#ga0df40248788f0fb17ebdc59d74116d1c", null ],
    [ "get_alipf_arrays", "alifold_8h.html#ga0cc49457fd79eeb04d4a7f97c868b09b", null ],
    [ "cv_fact", "alifold_8h.html#gaf3cbac6ff5d706d6e414677841ddf94c", null ],
    [ "nc_fact", "alifold_8h.html#ga502948a122a2af5b914355b1f3ea2f61", null ]
];