var group__mfe__cofold =
[
    [ "cofold.h", "cofold_8h.html", null ],
    [ "cofold", "group__mfe__cofold.html#gabc8517f22cfe70595ee81fc837910d52", null ],
    [ "cofold_par", "group__mfe__cofold.html#gafe430060533f14b11fc611f60b3f1f6f", null ],
    [ "free_co_arrays", "group__mfe__cofold.html#gaafb33d7473eb9af9d1b168ca8761c41a", null ],
    [ "update_cofold_params", "group__mfe__cofold.html#ga4fcbf34e77b99bfbb2333d2ab0c41a57", null ],
    [ "export_cofold_arrays_gq", "group__mfe__cofold.html#ga5f5bf4df35d0554f6ace9579f8744c48", null ],
    [ "export_cofold_arrays", "group__mfe__cofold.html#ga5cb6b59983f1f74ccc00b9b9c4e84482", null ]
];