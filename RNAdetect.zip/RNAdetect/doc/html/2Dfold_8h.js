var 2Dfold_8h =
[
    [ "get_TwoDfold_variables", "2Dfold_8h.html#gac9284f132cf0eaa0a2f43590eda05488", null ],
    [ "destroy_TwoDfold_variables", "2Dfold_8h.html#ga05bf4f31d216b1b160fd2d3d68e9b487", null ],
    [ "TwoDfoldList", "2Dfold_8h.html#ga47da790166020558d27323aef489703e", null ],
    [ "TwoDfold_backtrack_f5", "2Dfold_8h.html#gaf4dc05bf8fc1ea53acd7aeb798ba80c2", null ]
];