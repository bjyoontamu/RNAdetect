var structSOLUTION =
[
    [ "energy", "structSOLUTION.html#a4fe8e9027171f2dc4031587d7fab6b87", null ],
    [ "structure", "structSOLUTION.html#a89ae453dfad0509468c39a62c303a63b", null ]
];