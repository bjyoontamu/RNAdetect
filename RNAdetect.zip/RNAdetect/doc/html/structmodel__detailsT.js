var structmodel__detailsT =
[
    [ "dangles", "structmodel__detailsT.html#a89f9df217a4a7f4351a642655976376b", null ],
    [ "special_hp", "structmodel__detailsT.html#a9d73fde17b0465311a80f607faa85617", null ],
    [ "noLP", "structmodel__detailsT.html#a6fb076173d2cbc4259606ce23eedf17d", null ],
    [ "noGU", "structmodel__detailsT.html#a0f982e6904d012e4fe41e99daa797f5d", null ],
    [ "noGUclosure", "structmodel__detailsT.html#ae9cedf375cd904e5fb8e56cf3f64bcd9", null ],
    [ "logML", "structmodel__detailsT.html#a415556dc150e02d108be81ecc5c48e85", null ],
    [ "circ", "structmodel__detailsT.html#a55f083dad18c216505805a8062e63074", null ],
    [ "gquad", "structmodel__detailsT.html#aa1ecdce7bc3f375bd8a9a7b738abc0ea", null ],
    [ "canonicalBPonly", "structmodel__detailsT.html#a20e38e8e65afedb3be9c16ae03d956c0", null ]
];