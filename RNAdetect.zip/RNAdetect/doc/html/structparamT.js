var structparamT =
[
    [ "temperature", "structparamT.html#a8ed207b95868d1085bd9c197fbc6924f", null ],
    [ "model_details", "structparamT.html#aeb912822ef912705bc202b14f9d71ad9", null ]
];