var dist__vars_8h =
[
    [ "Postorder_list", "structPostorder__list.html", null ],
    [ "Tree", "structTree.html", null ],
    [ "swString", "structswString.html", null ],
    [ "edit_backtrack", "dist__vars_8h.html#aa03194c513af6b860e7b33e370b82bdb", null ],
    [ "aligned_line", "dist__vars_8h.html#ac1605fe3448ad0a0b809c4fb8f6a854a", null ],
    [ "cost_matrix", "dist__vars_8h.html#ab65d8ff14c6937612212526a60f59b3c", null ]
];