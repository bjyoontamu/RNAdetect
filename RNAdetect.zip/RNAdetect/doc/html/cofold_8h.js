var cofold_8h =
[
    [ "cofold", "cofold_8h.html#gabc8517f22cfe70595ee81fc837910d52", null ],
    [ "cofold_par", "cofold_8h.html#gafe430060533f14b11fc611f60b3f1f6f", null ],
    [ "free_co_arrays", "cofold_8h.html#gaafb33d7473eb9af9d1b168ca8761c41a", null ],
    [ "update_cofold_params", "cofold_8h.html#ga4fcbf34e77b99bfbb2333d2ab0c41a57", null ],
    [ "export_cofold_arrays_gq", "cofold_8h.html#ga5f5bf4df35d0554f6ace9579f8744c48", null ],
    [ "export_cofold_arrays", "cofold_8h.html#ga5cb6b59983f1f74ccc00b9b9c4e84482", null ],
    [ "zukersubopt", "cofold_8h.html#ga0d5104e3ecf119d8eabd40aa5fe47f90", null ],
    [ "zukersubopt_par", "cofold_8h.html#ga6d98a9450d1affadf144ac79f543da8c", null ],
    [ "get_monomere_mfes", "cofold_8h.html#a4958b517c613e4d2afd5bce6c1060a79", null ],
    [ "initialize_cofold", "cofold_8h.html#afee0c32208aa2ac97338b6e3fbad7fa5", null ]
];