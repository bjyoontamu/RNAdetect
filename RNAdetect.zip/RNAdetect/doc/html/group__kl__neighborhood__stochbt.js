var group__kl__neighborhood__stochbt =
[
    [ "TwoDpfold_pbacktrack", "group__kl__neighborhood__stochbt.html#gae251288f50dd4ae7d315af0085775f71", null ],
    [ "TwoDpfold_pbacktrack5", "group__kl__neighborhood__stochbt.html#ga13430ac6a7f90df426774f131647d2c7", null ]
];