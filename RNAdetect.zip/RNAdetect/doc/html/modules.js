var modules =
[
    [ "RNA Secondary Structure Folding", "group__folding__routines.html", "group__folding__routines" ],
    [ "Parsing and Comparing - Functions to Manipulate Structures", "group__parse.html", null ]
];