var plot__layouts_8h =
[
    [ "VRNA_PLOT_TYPE_SIMPLE", "plot__layouts_8h.html#ae6d17b9f0a53cf5205a9181e0f8422e9", null ],
    [ "VRNA_PLOT_TYPE_NAVIEW", "plot__layouts_8h.html#a94d4c863ecac2f220f76658afb92f964", null ],
    [ "VRNA_PLOT_TYPE_CIRCULAR", "plot__layouts_8h.html#a8c9eac631348da92136c8363ecdd9fb9", null ],
    [ "simple_xy_coordinates", "plot__layouts_8h.html#af4b9173e7d3fd361c3c85e6def194123", null ],
    [ "simple_circplot_coordinates", "plot__layouts_8h.html#ac4ea13d35308f09940178d2b05a248c2", null ],
    [ "rna_plot_type", "plot__layouts_8h.html#a5964c4581431b098b80027d6e14dcdd4", null ]
];