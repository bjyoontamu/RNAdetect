var structTwoDfold__solution =
[
    [ "k", "structTwoDfold__solution.html#a298767110e07490d361bf7da920fd153", null ],
    [ "l", "structTwoDfold__solution.html#a64fb28259cf925c3bba7b8d14592363a", null ],
    [ "en", "structTwoDfold__solution.html#a3f65891d0c931f88440150bb32bcf753", null ],
    [ "s", "structTwoDfold__solution.html#ac87e00bbdb13e0b6ef45c4f65608b416", null ]
];