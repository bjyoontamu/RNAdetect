var group__energy__parameters__rw =
[
    [ "Converting energy parameter files", "group__energy__parameters__convert.html", "group__energy__parameters__convert" ],
    [ "read_epars.h", "read__epars_8h.html", null ],
    [ "read_parameter_file", "group__energy__parameters__rw.html#ga165a142a3c68fb6655c69ef4ab7cd749", null ],
    [ "write_parameter_file", "group__energy__parameters__rw.html#ga8a43459be386a7489feeab68dc2c6c76", null ]
];