var inverse_8h =
[
    [ "inverse_fold", "inverse_8h.html#ga7af026de55d4babad879f2c92559cbbc", null ],
    [ "inverse_pf_fold", "inverse_8h.html#gaeef52ecbf2a2450ad585a344f9826806", null ],
    [ "symbolset", "inverse_8h.html#ga8f791e7740a5a28b9f6fafb4e60301d9", null ],
    [ "final_cost", "inverse_8h.html#ga7f17d3b169af048d32bb185039a9c09c", null ],
    [ "give_up", "inverse_8h.html#ga7ec4ba51f86e1717a1e174264e4a75ce", null ],
    [ "inv_verbose", "inverse_8h.html#gafcfc65fba01b9cca5946726ed9057a63", null ]
];