var group__subopt__zuker =
[
    [ "zukersubopt", "group__subopt__zuker.html#ga0d5104e3ecf119d8eabd40aa5fe47f90", null ],
    [ "zukersubopt_par", "group__subopt__zuker.html#ga6d98a9450d1affadf144ac79f543da8c", null ]
];