var group__consensus__mfe__fold =
[
    [ "alifold", "group__consensus__mfe__fold.html#ga4cf00f0659e5f0480335d69e797f05b1", null ],
    [ "circalifold", "group__consensus__mfe__fold.html#gadbd3b0b1c144cbfb4efe704b2b260f96", null ],
    [ "free_alifold_arrays", "group__consensus__mfe__fold.html#ga72095e4554b5d577250ea14c42acc49e", null ]
];