var group__class__fold =
[
    [ "Distance based partitioning of the Secondary Structure Space", "group__kl__neighborhood.html", "group__kl__neighborhood" ],
    [ "Compute the Density of States", "group__dos.html", "group__dos" ]
];