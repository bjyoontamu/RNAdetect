var structTwoDpfold__solution =
[
    [ "k", "structTwoDpfold__solution.html#a40ad24e311b193866111623dd1331567", null ],
    [ "l", "structTwoDpfold__solution.html#aeaad6adc35413c76a2e2f18d96a6508c", null ],
    [ "q", "structTwoDpfold__solution.html#af0bf3071502b4a4fa81eeb6dfacef94c", null ]
];