var group__kl__neighborhood__pf =
[
    [ "2Dpfold.h", "2Dpfold_8h.html", null ],
    [ "get_TwoDpfold_variables", "group__kl__neighborhood__pf.html#ga1aca740e2a75ab2b2951538266e53d64", null ],
    [ "get_TwoDpfold_variables_from_MFE", "group__kl__neighborhood__pf.html#gacc2f66da7ee62096cab629fce7112216", null ],
    [ "destroy_TwoDpfold_variables", "group__kl__neighborhood__pf.html#gafe994291458ee2ac34d3eb825ef62a15", null ],
    [ "TwoDpfoldList", "group__kl__neighborhood__pf.html#ga3e1cd3b24eb635c65181182cbb4ae3eb", null ]
];