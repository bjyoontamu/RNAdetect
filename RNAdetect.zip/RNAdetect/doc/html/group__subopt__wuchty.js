var group__subopt__wuchty =
[
    [ "subopt", "group__subopt__wuchty.html#ga700f662506a233e42dd7fda74fafd40e", null ],
    [ "subopt_par", "group__subopt__wuchty.html#ga554dedfcdb249fdf151caade58666e4d", null ],
    [ "subopt_circ", "group__subopt__wuchty.html#ga8634516e4740e0b6c9a46d2bae940340", null ],
    [ "subopt_sorted", "group__subopt__wuchty.html#ga873cf8ed69e0437f8efa8b1fec854a0e", null ],
    [ "print_energy", "group__subopt__wuchty.html#ga5e57d914bcb5feeecdf520e25313fcfe", null ]
];