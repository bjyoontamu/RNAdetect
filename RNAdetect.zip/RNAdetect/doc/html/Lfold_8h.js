var Lfold_8h =
[
    [ "Lfold", "Lfold_8h.html#ga16e5a70e60835bb969eaecbe6482f1be", null ],
    [ "Lfoldz", "Lfold_8h.html#gab6d79eecc180f586679f7b85cce5cbe9", null ],
    [ "aliLfold", "Lfold_8h.html#ga20a173a3cdb83f5d1778e36c1a6b1f2b", null ]
];