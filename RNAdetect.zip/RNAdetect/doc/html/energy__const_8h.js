var energy__const_8h =
[
    [ "GASCONST", "energy__const_8h.html#ab1e4a8d82f24ed5db01dde5f25269cf1", null ],
    [ "K0", "energy__const_8h.html#a307c72605e3713972b4f4fb2d53ea20e", null ],
    [ "INF", "energy__const_8h.html#a12c2040f25d8e3a7b9e1c2024c618cb6", null ],
    [ "FORBIDDEN", "energy__const_8h.html#a5064c29ab2d1e20c2304b3c67562774d", null ],
    [ "BONUS", "energy__const_8h.html#a96a9822fa134450197dd454b1478a193", null ],
    [ "NBPAIRS", "energy__const_8h.html#a5e75221c779d618eab81e096f37e32ce", null ],
    [ "TURN", "energy__const_8h.html#ae646250fd59311356c7e5722a81c3a96", null ],
    [ "MAXLOOP", "energy__const_8h.html#ad1bd6eabac419670ddd3c9ed82145988", null ]
];