var group__eval =
[
    [ "energy_of_structure", "group__eval.html#gaf93986cb3cb29770ec9cca69c9fab8cf", null ],
    [ "energy_of_struct_par", "group__eval.html#gab5169ea4f72f250e43811463a33f4e40", null ],
    [ "energy_of_circ_structure", "group__eval.html#gaeb14f3664aec67fc03268ac75253f0f8", null ],
    [ "energy_of_circ_struct_par", "group__eval.html#ga75dc765ee4a1177832bc817c94cf88e5", null ],
    [ "energy_of_structure_pt", "group__eval.html#ga8831445966b761417e713360791299d8", null ],
    [ "energy_of_struct_pt_par", "group__eval.html#gada4701dd7519b29da75ceac147601f4e", null ],
    [ "eos_debug", "group__eval.html#ga567530678f6260a1a649a5beca5da4c5", null ]
];