var structintermediate__t =
[
    [ "pt", "structintermediate__t.html#a9a2b6258aa1af06ea3504631de8dadba", null ],
    [ "Sen", "structintermediate__t.html#ac44e091915da58927978d54ef59234c7", null ],
    [ "curr_en", "structintermediate__t.html#af84d640df33aea99e959b2e4f61a7367", null ],
    [ "moves", "structintermediate__t.html#a94e947f18273bbfe3dd544085b025a7b", null ]
];