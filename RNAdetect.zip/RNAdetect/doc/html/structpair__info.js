var structpair__info =
[
    [ "i", "structpair__info.html#a7905e17da6a6cc48230ee6205628ed7f", null ],
    [ "j", "structpair__info.html#a35665817b5792703ff4325e1bcbe5e21", null ],
    [ "p", "structpair__info.html#af0895ea40ec0c23bfe8aa2c3babf0e80", null ],
    [ "ent", "structpair__info.html#ab3aa7a54e6976f46e69c6ffcddd0e782", null ],
    [ "bp", "structpair__info.html#a23fc316453d179474bed7f6ed2489723", null ],
    [ "comp", "structpair__info.html#a4da3d6c9042500c16c4b06e0bbc48190", null ]
];