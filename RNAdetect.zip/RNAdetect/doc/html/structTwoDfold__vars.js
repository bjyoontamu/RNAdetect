var structTwoDfold__vars =
[
    [ "P", "structTwoDfold__vars.html#ada74adef5f24b4b35c0b25da8223fe26", null ],
    [ "do_backtrack", "structTwoDfold__vars.html#ade5c7e9337a458ae20bac75abdc52d64", null ],
    [ "ptype", "structTwoDfold__vars.html#aedf60b8b26dae05ad266d3e098d18208", null ],
    [ "sequence", "structTwoDfold__vars.html#a3596f3d4d320318c4b8428e2abc7ab56", null ],
    [ "S1", "structTwoDfold__vars.html#ab9ee459ffbfb5d2c138a033516056cdc", null ],
    [ "maxD1", "structTwoDfold__vars.html#a621ed2ab02116f3f8f5e7120dec429eb", null ],
    [ "maxD2", "structTwoDfold__vars.html#a03f198a4abdb3b784486d2ba5c533aa4", null ],
    [ "mm1", "structTwoDfold__vars.html#aa11f5bcd8c4fe70a91c155c877c855d5", null ],
    [ "mm2", "structTwoDfold__vars.html#a2eaa93316b6beb17531f0c078806036c", null ],
    [ "my_iindx", "structTwoDfold__vars.html#a1a20cb06b58b75d1a3dbdbc8bc60d0a7", null ],
    [ "referenceBPs1", "structTwoDfold__vars.html#a536525b98c1b633d4c5f2da4f8d78c18", null ],
    [ "referenceBPs2", "structTwoDfold__vars.html#aa7abf73c3114cb5f0dc90e702fa9dd0f", null ],
    [ "bpdist", "structTwoDfold__vars.html#af1106e1a592e2dccc92b3452340549e0", null ]
];