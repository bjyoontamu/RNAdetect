var group__centroid__fold =
[
    [ "get_centroid_struct_pl", "group__centroid__fold.html#ga9aba0ba1433a6d259331e0fe9fc4a9a6", null ],
    [ "get_centroid_struct_pr", "group__centroid__fold.html#gacdabece4aa1e20c9eaa97acb4c4dcc38", null ]
];