var group__kl__neighborhood__mfe =
[
    [ "2Dfold.h", "2Dfold_8h.html", null ],
    [ "get_TwoDfold_variables", "group__kl__neighborhood__mfe.html#gac9284f132cf0eaa0a2f43590eda05488", null ],
    [ "destroy_TwoDfold_variables", "group__kl__neighborhood__mfe.html#ga05bf4f31d216b1b160fd2d3d68e9b487", null ],
    [ "TwoDfoldList", "group__kl__neighborhood__mfe.html#ga47da790166020558d27323aef489703e", null ],
    [ "TwoDfold_backtrack_f5", "group__kl__neighborhood__mfe.html#gaf4dc05bf8fc1ea53acd7aeb798ba80c2", null ]
];