var 2Dpfold_8h =
[
    [ "get_TwoDpfold_variables", "2Dpfold_8h.html#ga1aca740e2a75ab2b2951538266e53d64", null ],
    [ "get_TwoDpfold_variables_from_MFE", "2Dpfold_8h.html#gacc2f66da7ee62096cab629fce7112216", null ],
    [ "destroy_TwoDpfold_variables", "2Dpfold_8h.html#gafe994291458ee2ac34d3eb825ef62a15", null ],
    [ "TwoDpfoldList", "2Dpfold_8h.html#ga3e1cd3b24eb635c65181182cbb4ae3eb", null ],
    [ "TwoDpfold_pbacktrack", "2Dpfold_8h.html#gae251288f50dd4ae7d315af0085775f71", null ],
    [ "TwoDpfold_pbacktrack5", "2Dpfold_8h.html#ga13430ac6a7f90df426774f131647d2c7", null ]
];