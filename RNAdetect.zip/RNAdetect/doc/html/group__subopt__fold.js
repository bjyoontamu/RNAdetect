var group__subopt__fold =
[
    [ "Suboptimal structures according to Zuker et al. 1989", "group__subopt__zuker.html", "group__subopt__zuker" ],
    [ "Suboptimal structures within an energy band arround the MFE", "group__subopt__wuchty.html", "group__subopt__wuchty" ],
    [ "Stochastic backtracking in the Ensemble", "group__subopt__stochbt.html", "group__subopt__stochbt" ],
    [ "subopt.h", "subopt_8h.html", null ]
];