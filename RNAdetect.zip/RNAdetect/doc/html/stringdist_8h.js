var stringdist_8h =
[
    [ "Make_swString", "stringdist_8h.html#a3125991b3a403b3f89230474deb3f22e", null ],
    [ "string_edit_distance", "stringdist_8h.html#a89e3c335ef17780576d7c0e713830db9", null ]
];