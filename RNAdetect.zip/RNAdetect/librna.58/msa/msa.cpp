#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "msa.h"
#include "../structure/structure.h"
#include "../utils/file/utils.h"

#define MAX_ALN_LINE (10000)

/*
class t_msa
{
public:
	t_msa(t_msa* _msa); // Copies msa in the arguments.
	t_msa(vector<int*>* _msa, int _n_seq); // Copies msa in the arguments.
	~t_msa();

	vector<int*>* msa;
	int n_seq;
	bool* seq_exist;

	// Excludes a sequence from the alignment. (Permenantly?)
	void exclude_sequence_by_i(int i_seq_2_exclude);

	// Access to the index at column and sequence in the arguments.
	int x_i(int i_col, int i_seq);
	bool seq_exists_by_i(int i_seq_2_check);
};
*/

							// -, A, C, G, U
int pairable[5][5] = {	{ 0, 0, 0, 0, 0 },  // -
							{ 0, 0, 0, 0, 1 },  // A
							{ 0, 0, 0, 1, 0 },  // C
							{ 0, 0, 1, 0, 1 },  // G
							{ 0, 1, 0, 1, 0 }}; // U

bool _DUMP_MSA_LIB_MESSAGES_ = false;

t_msa::t_msa(char* msa_fp, char gap_symbol, int _n_seq) // Copies msa in the arguments.
{
	this->load_msa(msa_fp, gap_symbol, _n_seq);

	// Check consistency between sequence msa data and existence array.
	this->check_set_existence();
}

t_msa::t_msa(int initing_seq_i, int initing_seq_l, int _n_seq) // Copies msa in the arguments.
{
	this->init_msa(initing_seq_i, initing_seq_l, _n_seq);

	// Check consistency between sequence msa data and existence array.
	this->check_set_existence();
}

t_msa::t_msa(vector<char*>* aln_lines, char gap_symbol)
{
	this->load_msa(aln_lines, gap_symbol);

	this->check_set_existence();
}

// Copy constructor.
t_msa::t_msa(t_msa* _msa)
{
	this->n_seq = _msa->n_seq;
	this->msa = new vector<int*>();

	for(int i_col = 0; i_col < (int)_msa->msa->size(); i_col++)
	{
		// Copy the column
		int* new_column = (int*)malloc(sizeof(int) * (_msa->n_seq + 2));

		for(int i_seq = 0; i_seq < _msa->n_seq; i_seq++)
		{
			new_column[i_seq] = _msa->x_i(i_col, i_seq);
		}

		// Add this column
		this->msa->push_back(new_column);
	}

	this->seq_existence = (bool*)malloc(sizeof(bool) * (this->n_seq + 2));

	for(int i_seq = 0; i_seq < _msa->n_seq; i_seq++)
	{
		this->seq_existence[i_seq] = _msa->seq_existence[i_seq];
	}

	// Check consistency between sequence msa data and existence array.
	this->check_set_existence();
}

int t_msa::get_col_i(int i_seq, int i_nuc)
{
	for(int i_col = 0; i_col < (int)this->msa->size(); i_col++)
	{
		if(this->x_i(i_col, i_seq) == i_nuc)
		{
			return(i_col);
		}
	}

	return(INVALID_MSA_COL);
}

/*
Verify existence of sequence from sequence data.
*/
void t_msa::check_set_existence()
{
	for(int i_seq = 0; i_seq < this->n_seq; i_seq++)
	{
		bool this_seq_exists = false;

		// It is very important that only the visible columns are checked for MSA_POS_NOT_SET value.
		for(int i_col = 1; i_col <= this->n_col(); i_col++)
		{
			if(this->x_i(i_col, i_seq) != MSA_POS_NOT_SET)
			{
				this_seq_exists = true;
			}
		}

		if(!this_seq_exists)
		{
			if(this->seq_existence[i_seq])
			{
				printf("Setting existence of %d. sequence to false.\n", i_seq);
				//getc(stdin);
			}

			this->seq_existence[i_seq] = false;
		}
	}
}

/*
It is assumed that _msa_columns are complete.
*/
t_msa::t_msa(std::vector<int*>* _msa_columns, int _n_seq)
{
	this->n_seq = _n_seq;

	this->msa = new vector<int*>();

	for(int i_col = 0; i_col < (int)_msa_columns->size(); i_col++)
	{
		// Copy the column
		int* new_column = (int*)malloc(sizeof(int) * (this->n_seq + 2));

		for(int i_seq = 0; i_seq < this->n_seq; i_seq++)
		{
			new_column[i_seq] = _msa_columns->at(i_col)[i_seq];
		}

		// Add this column
		this->msa->push_back(new_column);
	}

	// Set all sequences as existing.
	this->seq_existence = (bool*)malloc(sizeof(bool) * (this->n_seq + 2));

	for(int i_seq = 0; i_seq < _n_seq; i_seq++)
	{
		this->seq_existence[i_seq] = true;
	}

	// Check consistency between sequence msa data and existence array.
	this->check_set_existence();
}

int t_msa::x_i(int i_col, int i_seq)
{
	return(this->msa->at(i_col)[i_seq]);
}

int t_msa::x_i_first_emitted_nuc(int i_right_col, int i_seq)
{
	for(int i_col = i_right_col; i_col >= 0; i_col--)
	{
		if(this->x_i(i_col, i_seq) != MSA_POS_NOT_SET)
		{
			return(this->x_i(i_col, i_seq));
		}
	}

	// Cannot be here.
	printf("Encountered the thing that should not be @ %s(%d)\n", __FILE__, __LINE__);
	return(0); // Im not sure if this is a good idea.
	//exit(0);
	//return(MSA_POS_NOT_SET);
}

bool t_msa::seq_exists_by_i(int i_seq_2_check)
{
	return(this->seq_existence[i_seq_2_check]);
}

void t_msa::exclude_sequence_by_i(int i_seq_2_exclude)
{
	// Set existence to false.
	this->seq_existence[i_seq_2_exclude] = false;

	vector<int*>* excluding_msa = new vector<int*>();

	printf("Excluding sequence %d from MSA.\n", i_seq_2_exclude);

	// Copy the msa excluding the sequence at i_seq from the columns.
	// Copies 0th column, too.
	for(int i_col = 0; i_col < (int)this->msa->size(); i_col++)
	{
		int* cur_msa_column = this->msa->at(i_col);
		int* cur_excluded_column = (int*)malloc(sizeof(int) * (this->n_seq + 2));

		bool column_empty = true;
		for(int i_seq = 0; i_seq < this->n_seq; i_seq++)
		{
			if(i_seq == i_seq_2_exclude)
			{
				// Delete entries for the sequence to exclude.
				cur_excluded_column[i_seq] = MSA_POS_NOT_SET;
			}
			else
			{
				cur_excluded_column[i_seq] = cur_msa_column[i_seq];
			}

			if(cur_excluded_column[i_seq] != MSA_POS_NOT_SET)
			{
				column_empty = false;
			}
		} // seq loop

		// If currently generated column is empty (that is, all not set) do not add this column to the 
		// excluded msa. This check ensures that there is at least one nucleotide in each of the columns of 
		// excluded msa.
		if(!column_empty)
		{
			excluding_msa->push_back(cur_excluded_column);
		}
		else
		{
			printf("Removing an all empty column!\n");
			//getc(stdin);
			free(cur_excluded_column);
		}
	} // col loop

	printf("MSA with %d. sequence excluded:\n", i_seq_2_exclude);
	for(int i_seq = 0; i_seq < this->n_seq; i_seq++)
	{
		for(int i_col = 0; i_col < (int)excluding_msa->size(); i_col++)
		{
			printf("%3d ", excluding_msa->at(i_col)[i_seq]);
		}
		printf("\n\n");
	}

	// Free the current msa and replace it with excluding msa.
	for(int i_col = 0; i_col < (int)this->msa->size(); i_col++)
	{
		// free current column
		free(this->msa->at(i_col));
	}
	this->msa->clear();
	delete(this->msa);

	// Replace.
	this->msa = excluding_msa;
}

int t_msa::n_col()
{
	return((int)this->msa->size() - 1);
}

int t_msa::l_seq(int i_seq)
{
        int seq_length = 0;
        for(int i_col = 0; i_col < (int)this->msa->size(); i_col++)
        {
                if(this->x_i(i_col, i_seq) != MSA_POS_NOT_SET)
                {
                        seq_length = this->x_i(i_col, i_seq);
                }
        }

        return(seq_length);
}


t_msa::~t_msa()
{
	free(this->seq_existence);

	// Free the current msa and replace it with excluding msa.
	for(int i_col = 0; i_col < (int)this->msa->size(); i_col++)
	{
		// free current column
		free(this->msa->at(i_col));
	}
	this->msa->clear();
	delete(this->msa);
}

/*
Load an msa from a file.
*/
void t_msa::load_msa(char* msa_fp, char gap_symbol, int _n_seq)
{
	this->n_seq = _n_seq;

	printf("Initing sequence alignment with %s\n", msa_fp);

	// Read the alignment lines from the file.
	FILE* f_msa = open_f(msa_fp, "r");

	if(f_msa == NULL)
	{
		printf("Could not open MSA file %s.\n", msa_fp);
		exit(0);
	}

	this->msa = NULL;

	char cur_msa_line[MAX_ALN_LINE];

	for(int i_seq = 0; i_seq < _n_seq; i_seq++)
	{
		fgets(cur_msa_line, MAX_ALN_LINE, f_msa);
		if(cur_msa_line[strlen(cur_msa_line) - 1] == '\n')
		{
			cur_msa_line[strlen(cur_msa_line) - 1] = 0;
		}
		int n_cols = (int)strlen(cur_msa_line);

		// Allocate columns
		if(this->msa == NULL)
		{
			this->msa = new vector<int*>();

			for(int i_col = 0; i_col <= n_cols; i_col++)
			{
				int* cur_column = (int*)malloc(sizeof(int) * (_n_seq + 2));
				this->msa->push_back(cur_column);
			}
		}

		// Process this line.
		int i_nuc = 1;
		for(int i_col = 0; i_col < n_cols; i_col++)
		{
			// Set this sequence as existing in msa.
			if(i_col == 0)
			{
				this->msa->at(i_col)[i_seq] = 0;
			}

			if(cur_msa_line[i_col] == gap_symbol)
			{
				this->msa->at(i_col+1)[i_seq] = MSA_POS_NOT_SET;
			}
			else
			{
				this->msa->at(i_col+1)[i_seq] = i_nuc;
				i_nuc++;
			}
		} // Go over all the columns in this alignment line.
	} // Go over all the sequences in MSA.

	fclose(f_msa);

	printf("Inited msa:\n");
	for(int i_seq = 0; i_seq < _n_seq; i_seq++)
	{
		for(int i_col = 1; i_col < (int)this->msa->size(); i_col++)
		{
			printf("%3d ", this->msa->at(i_col)[i_seq]);
		}
		printf("\n\n");
	}

	// Set all sequences as existing.
	this->seq_existence = (bool*)malloc(sizeof(bool) * (this->n_seq + 2));

	for(int i_seq = 0; i_seq < _n_seq; i_seq++)
	{
		this->seq_existence[i_seq] = true;
	}
}

/*
Load an msa from a file.
*/
void t_msa::load_msa(vector<char*>* aln_lines, char gap_symbol)
{
	this->n_seq = (int)aln_lines->size();

	printf("Initing msa with alignment lines.\n");

	this->msa = NULL;

	char cur_msa_line[MAX_ALN_LINE];

	for(int i_seq = 0; i_seq < n_seq; i_seq++)
	{
		strcpy(cur_msa_line, aln_lines->at(i_seq));
		int n_cols = (int)strlen(cur_msa_line);

		// Allocate columns
		if(this->msa == NULL)
		{
			this->msa = new vector<int*>();

			for(int i_col = 0; i_col <= n_cols; i_col++)
			{
				int* cur_column = (int*)malloc(sizeof(int) * (n_seq + 2));
				this->msa->push_back(cur_column);
			}
		}

		// Process this line.
		int i_nuc = 1;
		for(int i_col = 0; i_col < n_cols; i_col++)
		{
			// Set this sequence as existing in msa.
			if(i_col == 0)
			{
				this->msa->at(i_col)[i_seq] = 0;
			}

			if(cur_msa_line[i_col] == gap_symbol)
			{
				this->msa->at(i_col+1)[i_seq] = MSA_POS_NOT_SET;
			}
			else
			{
				this->msa->at(i_col+1)[i_seq] = i_nuc;
				i_nuc++;
			}
		} // Go over all the columns in this alignment line.
	} // Go over all the sequences in MSA.

	printf("Inited msa:\n");
	for(int i_seq = 0; i_seq < n_seq; i_seq++)
	{
		for(int i_col = 1; i_col < (int)this->msa->size(); i_col++)
		{
			printf("%3d ", this->msa->at(i_col)[i_seq]);
		}
		printf("\n\n");
	}

	// Set all sequences as existing.
	this->seq_existence = (bool*)malloc(sizeof(bool) * (this->n_seq + 2));

	for(int i_seq = 0; i_seq < n_seq; i_seq++)
	{
		this->seq_existence[i_seq] = true;
	}
}

void t_msa::init_msa(int initing_seq_i, int initing_seq_l, int _n_seq)
{
	printf("Initing msa with %d. sequence.\n", initing_seq_i);

	this->n_seq = _n_seq;

	this->msa = new vector<int*>();

	// Add the columns as many as the nucleotides in the msa initing sequence.
	for(int i_col = 0; i_col <= initing_seq_l; i_col++)
	{
		// Generate the current columns.
		int* cur_column = (int*)malloc(sizeof(int) * (_n_seq + 2));
		for(int i_seq = 0; i_seq < _n_seq; i_seq++)
		{
			// Do not use 0th columns as it refers to an invalid position in sequence indices.
			// Set this position to 0 if this sequence is currently not in the msa and 1 if it is in the msa.
			if(i_seq == initing_seq_i)
			{
				cur_column[i_seq] = i_col;
			}
			else
			{
				cur_column[i_seq] = MSA_POS_NOT_SET;
			}
		} // sequence loop

		this->msa->push_back(cur_column);
	} // column loop

	printf("Inited msa:\n");
	for(int i_seq = 0; i_seq < _n_seq; i_seq++)
	{
		for(int i_col = 1; i_col < (int)this->msa->size(); i_col++)
		{
			printf("%3d ", this->msa->at(i_col)[i_seq]);
		}
		printf("\n\n");
	}

	// Set all sequences as existing.
	this->seq_existence = (bool*)malloc(sizeof(bool) * (this->n_seq + 2));

	for(int i_seq = 0; i_seq < _n_seq; i_seq++)
	{
		if(i_seq == initing_seq_i)
		{
			this->seq_existence[i_seq] = true;
		}
		else
		{
			this->seq_existence[i_seq] = false;
		}
	}
	//getc(stdin);
}

void t_msa::set_pairing_mask(char* _pairing_mask, 
							 char _left_pair, 
							 char _right_pair)
{
	this->left_pair = _left_pair;
	this->right_pair = _right_pair;

	this->pairing_mask = (char*)malloc(sizeof(char) * (strlen(_pairing_mask) + 3));

	// Make pairing_mask string 1 based.
	this->pairing_mask[0] = '#';
	strcpy(&this->pairing_mask[1], _pairing_mask);
}

/*
Assume that pairing mask string is 1 based and sequence string is 1 based, that is, i is the 1 based indexing.
*/
int t_msa::get_pairing_mask_pair(int i, 
								 char* pairing_mask_str, 
								 char LEFT_PAIR, 
								 char RIGHT_PAIR)
{
	if(pairing_mask_str[i-1] == LEFT_PAIR)
	{
		int pair_sum = 0;
		for(int j = i; j <= strlen(pairing_mask_str); j++)
		{
			if(pairing_mask_str[j-1] == LEFT_PAIR)
			{
				pair_sum++;
			}
			else if(pairing_mask_str[j-1] == RIGHT_PAIR)
			{
				pair_sum--;

				if(pair_sum == 0)
				{
						return(j);
				}
			} // pairing check.

		} // pair search loop.

		printf("Could not find the pair for %d.\n", i);
		exit(0);
	}
	else if(pairing_mask_str[i-1] == RIGHT_PAIR)
	{
		int pair_sum = 0;
		for(int j = i; j >= 1; j--)
		{
			if(pairing_mask_str[j-1] == RIGHT_PAIR)
			{
				pair_sum++;
			}
			else if(pairing_mask_str[j-1] == LEFT_PAIR)
			{
				pair_sum--;

				if(pair_sum == 0)
				{
						return(j);
				}
			} // pairing check.
		} // pair search loop.

		printf("Could not find the pair for %d.\n", i);
		exit(0);
	}

    // If this is an unpaired nucleotides, return 0.
    return(0);
}

/*
consensus_str_line: 0 based.
cur_aln_line: 0 based indexing.
*/
int* t_msa::get_base_pairing(char* consensus_str_line, 
					  char* cur_aln_line, 
					  char predicted_gap_symbol, 
					  t_structure* known_str, 
					  char left_pair, 
					  char right_pair)
{
	// Determine pairs of all the nucleotides.
	int* basepr = (int*)malloc(sizeof(int) * (known_str->numofbases + 2));
	for(int i_nuc = 1; i_nuc <= known_str->numofbases; i_nuc++)
	{
		basepr[i_nuc] = 0;
	}

	// allocate aln2seq map. This is 1 based.	
	int* current_aln2seq_map = (int*)malloc(sizeof(int) * (strlen(cur_aln_line) + 2));
	
	// File aln2seq map.	
	int i_seq = 1;	
	for(int i_aln = 1; i_aln <= (int)strlen(cur_aln_line); i_aln++)	
	{		
		if(cur_aln_line[i_aln-1] != predicted_gap_symbol)		
		{		
if(_DUMP_MSA_LIB_MESSAGES_)
			printf("%d -> %d\n", i_aln, i_seq);		
			current_aln2seq_map[i_aln] = i_seq;	
			i_seq++;		
		}		
		else		
		{		
			current_aln2seq_map[i_aln] = 0;		
		}	
	}

	// Go over all the positions in the pairng mask and set the pairs in the current sequence.
	for(int i_mask = 1; i_mask <= (int)strlen(consensus_str_line); i_mask++)
	{
		// if the nucleotide has a pair in the pairing mask, map both the nucleotide and its pair
		// to current sequence's coordinates. Then check if there are valid nucleotides there.
		int i_mask_pair = get_pairing_mask_pair(i_mask, consensus_str_line, left_pair, right_pair);
		if(i_mask_pair != 0)
		{
			//printf("Mapping (%d, %d)\n", i_mask, pairing_mask[i_mask]);
			int i = current_aln2seq_map[i_mask];
			int j = current_aln2seq_map[i_mask_pair];

if(_DUMP_MSA_LIB_MESSAGES_)
			printf("Mapping (%d, %d) <-> (%d, %d)\n", i_mask, i_mask_pair, i,j);

			if(i == 0 || j == 0 || !pairable[known_str->numseq[i]][known_str->numseq[j]])
			{			
			//if(i == 0 || j == 0)
			//{

if(_DUMP_MSA_LIB_MESSAGES_)
{
				printf("Nucleotides at %d, %d are not pairable.\n", i,j);
				if(i != 0 && j != 0)
				{
					printf("Nucs: %c, %c\n", known_str->nucs[i], known_str->nucs[j]);
				}
}		
				
				//exit(0);
			}
			else
			{
				basepr[i] = j;
			} // pairing check for mapped indices in the current sequence.
		} // pairing_mask pairing check.
	} // pairing mask loop.

	return(basepr);
}

