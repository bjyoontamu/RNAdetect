#ifndef _MSA_
#define _MSA_

#include <vector>
using namespace std;

#define MSA_POS_NOT_SET (0xffffffff)
#define INVALID_MSA_COL (0xfffffffc)

class t_structure;

class t_msa
{
public:
	t_msa(t_msa* _msa); // Copies msa in the arguments.
	t_msa(vector<int*>* _msa_columns, int _n_seq); // Copies msa in the arguments.
	t_msa(char* msa_fp, char gap_symbol, int _n_seq); // Copies msa in the arguments.
	t_msa(int initing_seq_i, int initing_seq_l, int _n_seq);
	t_msa(vector<char*>* aln_lines, char gap_symbol);
	~t_msa();

	vector<int*>* msa;
	int n_seq;
	bool* seq_existence;

	char* pairing_mask;
	void set_pairing_mask(char* pairing_mask, char _left_pair, char _right_pair);
	char left_pair;
	char right_pair;

	void load_msa(char* msa_fp, char gap_symbol, int _n_seq);
	void init_msa(int initing_seq_i, int initing_seq_l, int _n_seq);
	void load_msa(vector<char*>* aln_lines, char gap_symbol);

	// Excludes a sequence from the alignment. (Permenantly?)
	void exclude_sequence_by_i(int i_seq_2_exclude);

	// Access to the index at column and sequence in the arguments.
	int x_i(int i_col, int i_seq);
	int x_i_first_emitted_nuc(int i_col, int i_seq);
	int n_col();
	int l_seq(int i_seq);
	bool seq_exists_by_i(int i_seq_2_check);

	int get_col_i(int i_seq, int i_nuc);

	void check_set_existence();

	static int* get_base_pairing(char* consensus_str_line, 
								  char* cur_aln_line, 
								  char predicted_gap_symbol, 
								  t_structure* known_str, 
								  char left_pair, 
								  char right_pair);

	static int get_pairing_mask_pair(int i, 
									char* pairing_mask_str, 
									char LEFT_PAIR, 
									char RIGHT_PAIR);
};

#endif // _MSA_

