#ifndef __CLUSTER_UTILS__
#define __CLUSTER_UTILS__

#include <vector>

using namespace std;

class t_matrix;

class t_cluster_node
{
public:
	t_cluster_node(vector<int>* _elements);
	t_cluster_node(int _init_element);
	~t_cluster_node();

	// Add a new child node.
	void add_element(int i_element);
	void add_element(vector<int>* elements);

	// Childs of this node.
	vector<int>* elements;
};

typedef vector<vector<t_cluster_node*>*> t_upgma_tree;

/*
t_obj_set represents a set of objects with predefined distances between them. The objects are irrelevant to this class. 
Generates different clusterings. The set is a metrizable set.
*/
class t_obj_set
{
public:
	t_obj_set(int _n_objs, // Looks redundant, is here for convenience.
				t_matrix* _distances);
	~t_obj_set();

	t_matrix* distances;
	int n_objs;

	// Do diana clustering based on distances.
	t_cluster_node* diana();

	// Generate upgma and return node.
	t_upgma_tree* upgma(bool closest_first);

	double get_distance(t_cluster_node* node1, 
						t_cluster_node* node2);

	void choose_upgma_clusters_to_merge(vector<t_cluster_node*>* current_clusters,
										int& i_cl1, int& i_cl2, bool closest_first);
};


#endif // __CLUSTER_UTILS__
