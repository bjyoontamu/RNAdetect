#ifndef _STRUCTURE_CLUSTERING_
#define _STRUCTURE_CLUSTERING_

#include <vector>
using namespace std;

#define MAX_N_CLUSTERS (20)

class t_structure;

class t_structure_cluster
{
public:
	t_structure_cluster(t_structure_cluster* _parent_cluster, vector<int>* _sample_indices);

	t_structure_cluster(vector<t_structure*>* _sample_set);
	~t_structure_cluster();

	t_structure_cluster* parent_cluster; // Parent of this node.

	vector<t_structure*>* sample_set;
	vector<int>* sample_indices;
	
	// Compute and return the diameter.
	double diameter();

	// Divide this cluster and generate child_cluster1 and 2.
	void divide();
	t_structure_cluster* child_cluster1;
	t_structure_cluster* child_cluster2;

	// These are computed once by the mother node, that is the head cluster.
	static double get_euc_bp_dist(t_structure* struct1, t_structure* struct2, int n_nucs);
	static double get_euc_bp_dist(int* struct1, int* struct2, int n_nucs);
	static double get_str2clust_avg_dist(int str_i, vector<int>* cluster_str_indices);

	static double** sample_dists; // Distance matrix.

	// Maximum number of possible clusters, note that this is may be smaller than the hard limit MAX_N_CLUSTERS
	// because there can be structures that are identical to each other.
	int effective_max_n_clusters;

	int optimal_clustering;

	// Following are clustering specific.
	double** compute_d_avg();
	double compute_overall_d_avg();
	double* compute_CH_index();
	vector<int>** get_best_clustering();

	vector<int>*** clusterings;
	void backtrack_clusterings();
};

#endif // _STRUCTURE_CLUSTERING_

