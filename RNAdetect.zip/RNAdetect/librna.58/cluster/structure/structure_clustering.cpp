#include <stdio.h>
#include <stdlib.h>
#include "structure_clustering.h"
#include "../../structure/structure.h"
#include <math.h>
#include <limits>

bool _DUMP_STRUCTURE_CLUSTERING_MESSAGES_ = false;

double** t_structure_cluster::sample_dists = NULL;

t_structure_cluster::t_structure_cluster(t_structure_cluster* _parent_cluster, vector<int>* _sample_indices)
{
	this->parent_cluster = _parent_cluster;
	this->sample_indices = _sample_indices;
	this->sample_set = this->parent_cluster->sample_set;
	this->sample_dists = this->parent_cluster->sample_dists;
	this->clusterings = NULL;
	this->child_cluster1 = NULL;
	this->child_cluster2 = NULL;
}

t_structure_cluster::t_structure_cluster(vector<t_structure*>* _sample_set)
{
	//this->sample_set = new vector<t_str_sample*>();
	//for(int i = 0; i < 30; i++)
	//{
	//	char cur_str_fp[200];
	//	sprintf(cur_str_fp, "cppf_stoch_samples/eubacteria_293_round_%d.ct", i);
	//	t_structure* cur_str = new t_structure(cur_str_fp);

	//	t_str_sample* cur_sample_str = new t_str_sample(cur_str);
	//	cur_sample_str->basepr = cur_str->basepr;
	//	this->sample_set->push_back(cur_sample_str);
	//}

	// Set this as the mother cluster.
	this->parent_cluster = NULL;
	this->child_cluster1 = NULL;
	this->child_cluster2 = NULL;

	this->sample_set = _sample_set;

	// Allocate and init sample_dists
	if(t_structure_cluster::sample_dists == NULL)
	{
		this->sample_dists = (double**)malloc(sizeof(double*) * ((int)this->sample_set->size() + 3));
		for(int i = 0; i < (int)this->sample_set->size(); i++)
		{
			this->sample_dists[i] = (double*)malloc(sizeof(double) * ((int)this->sample_set->size() + 3));

			for(int j = 0; j < (int)this->sample_set->size(); j++)
			{
				//this->sample_dists[i][j] = 0.0f;
				this->sample_dists[i][j] = t_structure_cluster::get_euc_bp_dist(this->sample_set->at(i)->basepr, this->sample_set->at(j)->basepr, this->sample_set->at(i)->numofbases);
				//printf("%d, %d -> %lf\n", i,j, this->sample_dists[i][j]);
			} // j loop
		} // i loop
	}

	// Push all the indices.
	this->sample_indices = new vector<int>();
	for(int i = 0; i < (int)this->sample_set->size(); i++)
	{
		this->sample_indices->push_back(i);
	}

	this->clusterings = NULL;

	// Generate and backtrack clustering at the mother node.
	this->divide();

	this->backtrack_clusterings();

	// Compute ch indices for clusterings and determine optimal clustering that maximizes CH index.
	double* ch_indices = this->compute_CH_index();
	double max_ch_index = 0.0;

	// Note that the effective number of clusters maybe 1, and there is always 1 clustering.
	this->optimal_clustering = 1;
	for(int i_clustering = 2; i_clustering <= this->effective_max_n_clusters; i_clustering++)
	{
if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
		printf("CH_index(%d) = %lf(%lf)\n", i_clustering, ch_indices[i_clustering], max_ch_index);
		if(ch_indices[i_clustering] != numeric_limits<double>::infinity() && 
			ch_indices[i_clustering] > max_ch_index)
		{
			max_ch_index = ch_indices[i_clustering];
			this->optimal_clustering = i_clustering;
		} // maximization check
	} // i_clustering loop.

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
	printf("optimal clustering is %d\n", this->optimal_clustering);
}


t_structure_cluster::~t_structure_cluster()
{
	// Allocate and init sample_dists
	if(t_structure_cluster::sample_dists != NULL)
	{
		//this->sample_dists = (double**)malloc(sizeof(double*) * (this->sample_set->size() + 3));
		for(int i = 0; i < (int)this->sample_set->size(); i++)
		{
			free(this->sample_dists[i]);
		} // i loop
		free(this->sample_dists);
	}

	t_structure_cluster::sample_dists = NULL;
}

/*
divide: Divide the set of structures independent of the MAX_N_CLUSTERS, until the granularity of the clusters
boil down to 1 structure, note that this can happen in 2 ways:
1) Diamieter of the cluster is 0, i.e., all structures are identical.
2) There is only one structure in the cluster.
*/
void t_structure_cluster::divide()
{
	if(this->sample_indices->size() == 0)
	{
		printf("Encountered a 0 size cluster while dividing @ %s(%d).\n", __FILE__, __LINE__);
		exit(0);
	}

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
	printf("Dividing a cluster with %d elements.\n", this->sample_indices->size());

	// No more division is possible for this cluster if there is only 1 element in it.
	if(this->sample_indices->size() == 1)
	{		
		return;
	}

	if(this->diameter() == 0.0f)
	{
if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
		printf("Zero diameter cluster found, will not divide it anymore.\n");
		return;
	}

	vector<int>* splinter_group_indices = new vector<int>();
	vector<int>* remainder_group_indices = new vector<int>();

	for(int i = 0; i < (int)this->sample_indices->size(); i++)
	{
		//printf("%d ", this->sample_indices->at(i));
		remainder_group_indices->push_back(this->sample_indices->at(i));
	}
	//printf("\n");

	// Find the index of structure that has highest avg distance to all the structures: This is the seed of splinter group.
	while(1)
	{
		int new_splinter_str_i = 0;
		int i_new_splinter_str_i = 0;
		double splinter_avg_dist = 0.0f;
		for(int i_str_i = 0; i_str_i < (int)remainder_group_indices->size(); i_str_i++)
		{
			int cur_str_i = remainder_group_indices->at(i_str_i);
			double Delta_i = 0.0f;

			// Add avg distance to remainder group.
			if(remainder_group_indices->size() > 1)
			{
				Delta_i = t_structure_cluster::get_str2clust_avg_dist(cur_str_i, remainder_group_indices) * (double)(remainder_group_indices->size()) / (double)(remainder_group_indices->size()-1);
			}
			else
			{
				Delta_i = 0.0f;
			}

			// Subtract average distance to splinter group generated so far.
			Delta_i -= t_structure_cluster::get_str2clust_avg_dist(cur_str_i, splinter_group_indices);

			//printf("Delta_i(%d) = %lf\n", cur_str_i, Delta_i);

			// If Delta_i is greater than 0, average distance of current structure to remainder is greater than it is to splinter group.

			// Check if current average distance is greater than current splinter average distance.
			if(Delta_i > splinter_avg_dist)
			{
				splinter_avg_dist = Delta_i;
				new_splinter_str_i = cur_str_i;
				i_new_splinter_str_i = i_str_i;
			}
		} // loop for searching for an outlier in remainder group that is close to splinter group.

		// Add to splinter group.i
		if(splinter_avg_dist > 0)
		{
			// Move the structure  closer to splinter group, 
			splinter_group_indices->push_back(new_splinter_str_i);

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
			printf("Adding str_i = %d to splinter group.\n", new_splinter_str_i);

			// Remove this index from remainder cluster.
			remainder_group_indices->erase(remainder_group_indices->begin()+i_new_splinter_str_i);
		}
		else
		{
			// All the structures are closer to remainder group.
			break;
		}
	} // infinite loop for generating splinter and remainder groups.

	// Instantiate two child clusters and add them.
	if(splinter_group_indices->size() > 0 && remainder_group_indices->size() > 0)
	{
		this->child_cluster1 = new t_structure_cluster(this, splinter_group_indices);
		this->child_cluster2 = new t_structure_cluster(this, remainder_group_indices);

		// Divide children. This call causes a recursive effect of generating all of the hierarchical clusters.
		this->child_cluster1->divide();
		this->child_cluster2->divide();
	}

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
	printf("Divided a cluster with %d elements.\n", this->sample_indices->size());
}

double t_structure_cluster::get_str2clust_avg_dist(int str_i, vector<int>* cluster_str_indices)
{
	if(cluster_str_indices->size() == 0)
	{
		return(0.0f);
	}

	double str2clust_avg_dist = 0.0f;
	for(int i_clust_str_i = 0; i_clust_str_i < (int)cluster_str_indices->size(); i_clust_str_i++)
	{
		int cur_clust_str_i = cluster_str_indices->at(i_clust_str_i);
		str2clust_avg_dist += t_structure_cluster::sample_dists[cur_clust_str_i][str_i];
	}

	return(str2clust_avg_dist / cluster_str_indices->size());
}

double t_structure_cluster::get_euc_bp_dist(t_structure* struct1, t_structure* struct2, int n_nucs)
{
        int n_bp_dist = 0;

        int* str1 = struct1->basepr;
        int* str2 = struct2->basepr;

        for(int i = 1; i <= n_nucs; i++)
        {
                // Do not count same base pairs twice.
                if(str1[i] != str2[i] && (str1[i] > i))
                {
                        n_bp_dist++;
                }

                // This counts for a second time if str2[i] is paired to a nucleotide that is further away.
                if(str1[i] != str2[i] && (str2[i] > i))
                {
                        n_bp_dist++;
                }
        }

        return(pow((double)n_bp_dist, .5));
}

double t_structure_cluster::get_euc_bp_dist(int* str1, int* str2, int n_nucs)
{
        int n_bp_dist = 0;

        for(int i = 1; i <= n_nucs; i++)
        {
                // Do not count same base pairs twice.
                if(str1[i] != str2[i] && (str1[i] > i))
                {
                        n_bp_dist++;
                }

                // This counts for a second time if str2[i] is paired to a nucleotide that is further away.
                if(str1[i] != str2[i] && (str2[i] > i))
                {
                        n_bp_dist++;
                }
        }

        return(pow((double)n_bp_dist, .5));
}

/*
backtrack_clusterings: Backtrack the clusterings that are divided by divide():
Keeps a list of current_child_clusters, which hold the diana clustered data for current_child_clusters->size() many clusters.
The cluster in the current_child_clusters with highest dimension is broken down into 2 clusters iteratively until MAX_N_CLUSTERS
many clusterings are generated or the granularity hits 0 diameter clusters. 0 diameter clusters cannot be backtracked further
since they are not divided in previous step.
*/
void t_structure_cluster::backtrack_clusterings()
{
	// Allocate clusterings.
	this->clusterings = (vector<int>***)malloc(sizeof(vector<int>**) * (MAX_N_CLUSTERS + 2));

	for(int i_cur_clustering = 0; i_cur_clustering <= MAX_N_CLUSTERS; i_cur_clustering++)
	{
		clusterings[i_cur_clustering] = (vector<int>**)malloc(sizeof(vector<int>*) * (MAX_N_CLUSTERS + 2));

		// 
		for(int i_cur_cluster = 0; i_cur_cluster < i_cur_clustering; i_cur_cluster++)
		{
			// This holds the indices of structures in i_cur_cluster of i_cur_clustering scheme.
			clusterings[i_cur_clustering][i_cur_cluster] = new vector<int>();
		} // i_cur_cluster loop
	} // i_cur_clustering loop

	// Start from the root cluster and generate all clusterings.
	vector<t_structure_cluster*>* current_child_clusters = new vector<t_structure_cluster*>();
	current_child_clusters->push_back(this);

	// Add all of the structures to clustering with 1 cluster.
	for(int i_str_i = 0; i_str_i < (int)this->sample_indices->size(); i_str_i++)
	{
		int cur_str_i = this->sample_indices->at(i_str_i);
		clusterings[1][0]->push_back(cur_str_i);
	}

	// Make sure that the effective max number of clusters is less than hard limit.
	while(current_child_clusters->size() > 0 && current_child_clusters->size() < MAX_N_CLUSTERS)
	{		
		// Set effective max to clusters in the current list.
		this->effective_max_n_clusters = (int)current_child_clusters->size();

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
		printf("backtracking %d clustering.\n", current_child_clusters->size());

		// Divide the child that has highest diameter, then update clusterings.
		double max_diameter = 0.0f;
		int i_max_diameter_child = 0;
		for(int i_child =  0; i_child < (int)current_child_clusters->size(); i_child++)
		{
			double current_diameter = current_child_clusters->at(i_child)->diameter();
			//printf("current diam = %lf\n", current_diameter);
			if(current_diameter > max_diameter)
			{
				max_diameter = current_child_clusters->at(i_child)->diameter();
				i_max_diameter_child = i_child;
			}
		} // i_child loop.

		/* 
		If the maximum diameter cluster has a diameter of 0, it is an indivisible cluster, note that the backtracking cannot 
		propagate further since the largest cluster (in terms of diameter) has 0 diameter. Therefore the backtracking is stopped.
		Keeping on with backtracking will cause wrong behaviour in the following code.
		*/
		if(max_diameter == 0.0f)
		{
			printf("The max diameter is 0.0f while backtracking effective number of clusters is %d\n", current_child_clusters->size());			
			break;
		}

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
		printf("max diameter cluster is %d. cluster (%lf)\n", i_max_diameter_child, max_diameter);

		// Divide the max diameter child and add them to current_child_cluster.
		t_structure_cluster* max_diameter_cluster = current_child_clusters->at(i_max_diameter_child);
		
		// remove max diameter cluster.
		current_child_clusters->erase(current_child_clusters->begin() + i_max_diameter_child); 

		// add the children of maximum diameter cluster.
		if(max_diameter_cluster->child_cluster1 != NULL && max_diameter_cluster->child_cluster2 != NULL)
		{
			current_child_clusters->push_back(max_diameter_cluster->child_cluster1);
			current_child_clusters->push_back(max_diameter_cluster->child_cluster2);

			// Update clustering info, note that there are 1 more clusters now.
			int cur_clustering = (int)current_child_clusters->size();
			for(int i_child = 0; i_child < (int)current_child_clusters->size(); i_child++)
			{
				t_structure_cluster* cur_str_clust = current_child_clusters->at(i_child);

				for(int i_str_i = 0; i_str_i < (int)cur_str_clust->sample_indices->size(); i_str_i++)
				{
					//printf("Adding %d to %d. child in %d clustering.\n", cur_str_clust->sample_indices->at(i_str_i), i_child, cur_clustering);
					clusterings[cur_clustering][i_child]->push_back(cur_str_clust->sample_indices->at(i_str_i));
				}
			}
		} // check for leaf nodes.
	} // go over all the child clusters.

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
	printf("effective n_clusters: %d\n", this->effective_max_n_clusters);
	for(int i_clustering = 1; i_clustering <= this->effective_max_n_clusters; i_clustering++)
	{

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
		printf("%d clustering:\n", i_clustering);

		for(int i_cluster = 0; i_cluster < i_clustering; i_cluster++)
		{

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
			printf("Cluster %d:\n", i_cluster);

			for(int i_sample = 0; i_sample < (int)clusterings[i_clustering][i_cluster]->size(); i_sample++)
			{
if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
				printf("%d ", clusterings[i_clustering][i_cluster]->at(i_sample));
			}

if(_DUMP_STRUCTURE_CLUSTERING_MESSAGES_)
			printf("\n");
		}
	}
}

/*
diameter of a cluster is the largest distance between two of its elements.
*/
double t_structure_cluster::diameter()
{
	double largest_distance = 0.0f;

	for(int i_str1_i = 0; i_str1_i < (int)this->sample_indices->size(); i_str1_i++)
	{
		for(int i_str2_i = 0; i_str2_i < (int)this->sample_indices->size(); i_str2_i++)
		{
			int str1_i = this->sample_indices->at(i_str1_i);
			int str2_i = this->sample_indices->at(i_str2_i);
			if(this->sample_dists[str1_i][str2_i] > largest_distance)
			{				
				largest_distance = this->sample_dists[str1_i][str2_i];
				//printf("Setting largest distance to %lf\n", largest_distance);
			}
		} // str2 loop
	} // str1 loop

	return(largest_distance);
}

// Compute average distance between all pairwise combinations between elements of this cluster.
double t_structure_cluster::compute_overall_d_avg()
{
	int n_samples = (int)this->sample_set->size();

	if(t_structure_cluster::sample_dists == NULL)
	{
		return(0.0f);
	}

    double overall_d_avg = 0.0;
    int n_overall_pair_cnt = 0;
    for(int i_str1_i = 0; i_str1_i < n_samples; i_str1_i++)
    {
        for(int i_str2_i = i_str1_i + 1; i_str2_i < n_samples; i_str2_i++)
        {
			int str1_i = this->sample_indices->at(i_str1_i);
			int str2_i = this->sample_indices->at(i_str2_i);

			overall_d_avg += t_structure_cluster::sample_dists[str1_i][str2_i];
            n_overall_pair_cnt++;
        }
    }

    overall_d_avg /= n_overall_pair_cnt;

	return(overall_d_avg);
}

// Compute average distance between all pairwise combinations between elements of this cluster.
double** t_structure_cluster::compute_d_avg()
{
	if(this->clusterings == NULL)
	{
		printf("Must compute clusterings before computing average distances.\n");
		exit(0);
	}

	double** d_avg = (double**)malloc(sizeof(double*) * (this->effective_max_n_clusters + 2));
    for(int i = 1; i <= this->effective_max_n_clusters; i++)
    {
        d_avg[i] = (double*)malloc(sizeof(double) * (this->effective_max_n_clusters + 2));

		for(int j = 0; j <= this->effective_max_n_clusters; j++)
		{
			d_avg[i][j] = 0.0f;
		}
    }

    for(int i_clust_scheme = 2; i_clust_scheme <= this->effective_max_n_clusters; i_clust_scheme++)
    {
        //printf("Computing average distanes in %d. clustering scheme.\n", i_clust_scheme);
        for(int i_clust = 0; i_clust < i_clust_scheme; i_clust++)
        {
            int cur_clust_avg_cnt = 0;

            // Compute the average distance for this cluster.
            d_avg[i_clust_scheme][i_clust] = 0.0;

            // If the number of samples in this cluster is 1, do not include this in avg distance computations
            // because it does not have any contribution.
            if(clusterings[i_clust_scheme][i_clust]->size() > 1)
            {
                //printf("%d samples in %d. cluster.\n", cur_clustering_scheme_clusters[i_clust_scheme][i_clust]->size(), i_clust);
                for(int i1 = 0; i1 < (int)clusterings[i_clust_scheme][i_clust]->size(); i1++)
                {
                    for(int i2 = i1+1; i2 < (int)clusterings[i_clust_scheme][i_clust]->size(); i2++)
                    {
                        int str_i1 = clusterings[i_clust_scheme][i_clust]->at(i1);
                        int str_i2 = clusterings[i_clust_scheme][i_clust]->at(i2);

						d_avg[i_clust_scheme][i_clust] += t_structure_cluster::sample_dists[str_i1][str_i2];

                        cur_clust_avg_cnt++;
                    }
                }

                d_avg[i_clust_scheme][i_clust] = d_avg[i_clust_scheme][i_clust] / cur_clust_avg_cnt;
            }
            //printf("d_avg[%d] = %.5f (%d)\n", i_clust, d_avg[i_clust_scheme][i_clust], cur_clust_avg_cnt);
        } // i_clust loop
    } // i_clust_scheme loop

    return(d_avg);
}

double* t_structure_cluster::compute_CH_index()
{
	if(this->clusterings == NULL)
	{
		printf("clusterings is not set for the cluster, must backtrack clusterings before computing CH indices.\n");
		exit(0);
	}

	int n_samples = (int)this->clusterings[1][0]->size();
    double* ch_indices = (double*)malloc(sizeof(double) * (this->effective_max_n_clusters + 2));

	for(int i_clust_scheme = 0; i_clust_scheme <= this->effective_max_n_clusters; i_clust_scheme++)
    {
		ch_indices[i_clust_scheme] = 0.0f;
	}

	// Compute the average distance for all the clusterings of elements of this cluster.
	double** d_avg = this->compute_d_avg();
	double overall_d_avg = this->compute_overall_d_avg();

    //for(int i_clust_scheme = 2; i_clust_scheme <= MAX_N_CLUSTERS; i_clust_scheme++)
	for(int i_clust_scheme = 2; i_clust_scheme <= this->effective_max_n_clusters; i_clust_scheme++)
    {
        double WGSS = 0.0;

        // Compute WGSS
        for(int i_clust = 0; i_clust < i_clust_scheme; i_clust++)
        {
            // Process ith cluster in the clustering scheme.
            int n_i = (int)this->clusterings[i_clust_scheme][i_clust]->size();

			//printf("i_clust = %d, WGSS_term = %.5f = %d x %.5f\n", i_clust, (n_i - 1) * d_avg[i_clust_scheme][i_clust], (n_i - 1), d_avg[i_clust_scheme][i_clust]); 

            WGSS += (n_i - 1) * d_avg[i_clust_scheme][i_clust];
        }

        WGSS = WGSS / 2;

        // Compute BGSS.
        double A_k = 0.0;
        int k = i_clust_scheme;
        for(int i_clust = 0; i_clust < i_clust_scheme; i_clust++)
        {
            // Process ith cluster in the clustering scheme.
			int n_i = (int)this->clusterings[i_clust_scheme][i_clust]->size();

            A_k += (n_i - 1) * (overall_d_avg - d_avg[i_clust_scheme][i_clust]);
        }
        A_k = A_k / (n_samples - k);

        double BGSS = (k - 1) * overall_d_avg + (n_samples - k) * A_k;
        BGSS = BGSS / 2;

        //printf("WGSS = %.5f\nBGSS = %.5f\n", WGSS, BGSS);

        ch_indices[i_clust_scheme] = (BGSS / (k-1)) / (WGSS / (n_samples - k));
		//printf("ch_index[%d] = %.lf\n", i_clust_scheme, ch_indices[i_clust_scheme]);
    }


    return(ch_indices);
}

