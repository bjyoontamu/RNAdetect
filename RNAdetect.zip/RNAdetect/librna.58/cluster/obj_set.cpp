#include <stdio.h>
#include <stdlib.h>
#include "obj_set.h"
#include "../utils/xmath/matrix/matrix.h"

/*
class t_cluster_node
{
public:
	t_cluster_node(vector<t_cluster_node*>* _childs);
	~t_cluster_node();

	// Add a new child node.
	void add_child();

	// Hold a data.
	int data;
};
*/

t_cluster_node::t_cluster_node(vector<int>* _elements)
{
	// Copy the children.
	this->elements = new vector<int>();

	for(int i_element = 0; i_element < _elements->size(); i_element++)
	{
		// Copy the children.
		this->elements->push_back(_elements->at(i_element));
	} // i_child loop.
}

t_cluster_node::t_cluster_node(int _init_element)
{
	// Copy the children.
	this->elements = new vector<int>();
	this->elements->push_back(_init_element);
}

t_cluster_node::~t_cluster_node()
{
	delete(this->elements);
}

void t_cluster_node::add_element(int i_element)
{
	// do not reallocate the child. This is for decreasing unnecessary recursive memory allocation.
	//this->childs->push_back(new t_cluster_node(_child));
	this->elements->push_back(i_element);
}

void t_cluster_node::add_element(vector<int>* elements)
{
	// do not reallocate the child. This is for decreasing unnecessary recursive memory allocation.
	//this->childs->push_back(new t_cluster_node(_child));
	for(int i_el = 0; i_el < elements->size(); i_el++)
	{
		this->elements->push_back(elements->at(i_el));
	}
}

t_obj_set::t_obj_set(int _n_objs, // Looks redundant, is here for convenience.
					t_matrix* _distances)
{
	this->n_objs = _n_objs;	

	if(this->n_objs != _distances->width ||
		this->n_objs != _distances->height)
	{
		printf("Number of objects is not same as the dimensions of distance matrix.\n");
		exit(0);
	}
	else
	{
		this->distances = new t_matrix(_distances);
	}
}

t_obj_set::~t_obj_set()
{
	delete(this->distances);
}

t_upgma_tree* t_obj_set::upgma(bool closest_first)
{
	//vector<vector<t_cluster_node*>*>* tree_root = new vector<vector<t_cluster_node*>*>();
	t_upgma_tree* tree_root = new t_upgma_tree();

/*
tree->at(depth) corresponds to the clustering at depth. depth <= n_objs. 
*/

	// Initialize 
	for(int i_obj = 0; i_obj < n_objs; i_obj++)
	{
		tree_root->push_back(new vector<t_cluster_node*>());
	}

	// Do division for each depth.
	for(int i_depth = 0; i_depth < this->n_objs; i_depth++)
	{
		if(i_depth == 0)
		{
			printf("Depth: 0\n", i_depth);
			// If this is the first depth, add all the objects. Note that these are going to be used to refer to
			// distance matrix and therefore must be 1 based.
			for(int i_obj = 1; i_obj <= this->n_objs; i_obj++)
			{
				tree_root->at(0)->push_back(new t_cluster_node(i_obj));
			}
		}
		else
		{
			printf("Depth: %d: ", i_depth);
			// If this is a higher level depth, find the clusters in previous depth that are closest/farthest and merge them in to a new
			// cluster node.
			vector<t_cluster_node*>* prev_clusters = tree_root->at(i_depth-1);

			// Choose the clusters that are closest/farthest.
			int i_m1;
			int i_m2;
			this->choose_upgma_clusters_to_merge(prev_clusters, i_m1, i_m2, closest_first);

			//printf("Merging %d, %d\n", i_m1, i_m2);

			// Generate the new cluster.
			t_cluster_node* merged_cluster = new t_cluster_node(prev_clusters->at(i_m1)->elements);
			merged_cluster->add_element(prev_clusters->at(i_m2)->elements);

			// Generate the current depth of clusters.
			for(int i_cl = 0; i_cl < prev_clusters->size(); i_cl++)
			{
				if(i_cl != i_m1 && i_cl != i_m2)
				{
					tree_root->at(i_depth)->push_back(prev_clusters->at(i_cl));
				}
			}

			// Add the merged cluster to current depth.
			tree_root->at(i_depth)->push_back(merged_cluster);

			for(int i_cl = 0; i_cl < tree_root->at(i_depth)->size(); i_cl++)
			{
				printf("(");
				t_cluster_node* current_node = tree_root->at(i_depth)->at(i_cl);

				for(int i_el = 0; i_el < current_node->elements->size(); i_el++)
				{
					if(i_el < current_node->elements->size()-1)
					{
						printf("%d ", current_node->elements->at(i_el));
					}
					else
					{
						printf("%d", current_node->elements->at(i_el));
					}
				} // i_el loop

				printf(") ");
			} // i_cl loop
			printf("\n");

			// Dump the elements of each cluster in the new depth.
		} // i_depth check.
	}// i_depth loop

	return(tree_root);
}

double t_obj_set::get_distance(t_cluster_node* node1, 
							   t_cluster_node* node2)
{
	double total_dist = 0.0f;
	int n_pw = 0;

	for(int i_e1 = 0; i_e1 < node1->elements->size(); i_e1++)
	{
		for(int i_e2 = 0; i_e2 < node2->elements->size(); i_e2++)
		{
			// This is the only place the distances are accessed. It is very important to make sure that the indices utilized to
			// access the distances to be 1 based.
			total_dist += this->distances->x(node1->elements->at(i_e1), node2->elements->at(i_e2));
			n_pw++;
		} // i_e2 loop.
	} // i_e1 loop.

	return(total_dist / n_pw);
}

void t_obj_set::choose_upgma_clusters_to_merge(vector<t_cluster_node*>* current_clusters,
												int& i_cl1, int& i_cl2, bool closest_first)
{
	double conc_dist = 0.0f;
	if(closest_first)
	{
		conc_dist = 100000.0f;
	}

	for(int i_e1 = 0; i_e1 < current_clusters->size(); i_e1++)
	{
		for(int i_e2 = i_e1+1; i_e2 < current_clusters->size(); i_e2++)
		{
			double current_inter_dist = this->get_distance(current_clusters->at(i_e1), current_clusters->at(i_e2));
			if(closest_first)
			{				
				if(current_inter_dist < conc_dist)
				{
					conc_dist = current_inter_dist;
					i_cl1 = i_e1;
					i_cl2 = i_e2;
				}
			} // closest_first check.
			else // farthest first?
			{
				if(current_inter_dist > conc_dist)
				{
					conc_dist = current_inter_dist;
					i_cl1 = i_e1;
					i_cl2 = i_e2;
				}
			}
		} // i_e2 loop
	} // i_e1 loop
}
