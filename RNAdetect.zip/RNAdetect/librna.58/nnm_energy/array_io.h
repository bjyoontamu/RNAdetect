#ifndef _ARRAY_IO_
#define _ARRAY_IO_

#define ARRAY_IP_PATH "array_io/ip"
#define ARRAY_OP_PATH "array_io/op"

enum{Vio, WLio, Wio, WMBLio, WMBio, WCOAXio, WOUTio, N_ARRAYS};

static char array_io_fn[N_ARRAYS][50] = {"V",
										"WL",
										"W",
										"WMBL",
										"WMB", 
										"WCOAX",
										"WOUT"};

class t_energy_loops;
class t_energy_array;

class t_array_io
{
public:
	t_array_io(t_energy_loops* _energy_loops);
	~t_array_io();

	t_energy_loops* energy_loops;

	// Read all arrays.
	void ip_arrays();

	// Write all arrays.
	void op_arrays();

	t_energy_array* get_energy_array_by_id(int array_id);
};

#endif // _ARRAY_IO_



