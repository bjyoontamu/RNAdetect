#include <stdio.h>
#include <stdlib.h>
#include "v.h"
#include "wl.h"
#include "wmbl.h"
#include "wcoax.h"
#include "energy_array.h"
#include "energy_loops.h"
#include "nnm_math.h"
#include "tb_stack.h"
#include "sampling_math.h"
#include "../structure/structure.h"
#include "thermo_parameters.h"
#include "../structure/folding_constraints.h"
#include "nnm_energy_compilation_directives.h"

bool _DUMP_WMBL_MESSAGES_ = false;

t_WMBL::t_WMBL(t_energy_loops* _energy_loops)
{
	this->energy_loops = _energy_loops;

	// Allocate energy array.
	this->energy_array = new t_energy_array(energy_loops->rna_seq);
	this->ext_energy_array = new t_energy_array(energy_loops->rna_seq);

	// Copy rna sequence pointer for later use.
	this->rna_seq = this->energy_loops->rna_seq;

	this->MAX_SUM = this->energy_loops->MAX_SUM;
}

// Free the energy array.
t_WMBL::~t_WMBL()
{
	delete(this->energy_array);
	delete(this->ext_energy_array);
}

void t_WMBL::compute(int i, int j)
{	
	if(!this->energy_loops->folding_constraints->str_coinc_map[i][j])
	{
		this->x(i,j) = ZERO;
		return;
	}

	////printf("Computing WMBL(%d, %d)\n", i,j);
	//if(this->energy_loops->const_bp_i == i ||
	//	this->energy_loops->const_bp_j == j)
	//{
	//	this->x(i,j) = ZERO;
	//	return;
	//}

	t_WL* WL = this->energy_loops->WL;
	t_Wcoax* Wcoax = this->energy_loops->Wcoax;

	// Get dangling and unpaired nucleotide energies.
	double i_dangle_energy = ZERO;
	double j_dangle_energy = ZERO;
	double i_unpaired_in_MBL_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;

	// WMBL branching loop.
#ifdef _TRANS_Wcoax_2_WMBL_
	this->x(i,j) = Wcoax->x(i,j);
#endif // _TRANS_Wcoax_WMBL_

if(_DUMP_WMBL_MESSAGES_)
	printf("WMBL(%d, %d) inited as %lf (%lf)\n", i,j, this->x(i,j), Wcoax->x(i,j));

	// 5' extension of wmbl(i+1, j) is handled in wl computations. It should not be handled here.
	// Note that other way is not possible, that is, it cannot be handled here since V depends on WL
	// so the extension has to be handled in WL. ||
#ifdef _TRANS_WMBL_5p_EXT_2_WMBL_
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
	{
		this->x(i,j) = MAX_SUM(this->x(i,j), MUL(this->x(i+1, j), i_unpaired_in_MBL_energy));
	}
#endif // _TRANS_WMBL_5p_EXT_2_WMBL_

	//for(int ip = i + MIN_LOOP; ip < j - MIN_LOOP; ip++)
#ifdef _TRANS_fp_WL_branchized_Wcoax_CONCAT_tp_WL_WMBL_2_WMBL_
	for(int ip = i + 1; ip < j; ip++)
	{
		double current_concatenation_energy = MUL(MAX_SUM(Wcoax->x(i,ip), WL->x_branchized(i,ip)), MAX_SUM(WL->x(ip+1, j), this->x(ip+1, j)));
		//double current_concatenation_energy = MUL(WL->x_branchized(i,ip), MAX_SUM(WL->x(ip+1, j), this->x(ip+1, j)));

		//_DUMP_WMBL_MESSAGES_
if(_DUMP_WMBL_MESSAGES_ && i == 19 && j == 31)
		printf("WMBL(%d, %d): (%d,%d)-(%d,%d): %lf\n", i,j, i, ip, ip+1, j, current_concatenation_energy);

		this->x(i,j) = MAX_SUM(this->x(i,j), current_concatenation_energy);
	}
#endif // _TRANS_fp_WL_branchized_Wcoax_CONCAT_tp_WL_WMBL_2_WMBL_
} // t_WMBL::compute

double& t_WMBL::x(int i, int j)
{
	return(this->energy_array->x(i,j));
}

void t_WMBL::min_energy_tb(int i, int j)
{
	t_WL* WL = this->energy_loops->WL;
	t_Wcoax* Wcoax = this->energy_loops->Wcoax;

	// Get dangling and unpaired nucleotide energies.
	double i_dangle_energy = ZERO;
	double j_dangle_energy = ZERO;
	double i_unpaired_in_MBL_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	bool pushed = false;

	// Generate the random cumulative.
	double current_max = ZERO;

	// WMBL branching loop.
#ifdef _TRANS_Wcoax_2_WMBL_
	current_max = Wcoax->x(i,j);

	if(!pushed && COMPARE(current_max, this->x(i,j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_Wcoax, i, j);
		pushed = true;
	}
#endif // _TRANS_Wcoax_2_WMBL_

#ifdef _TRANS_WMBL_5p_EXT_2_WMBL_
	//this->x(i,j) = MAX_SUM(this->x(i,j), MUL(this->x(i+1, j), i_unpaired_in_MBL_energy));
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
	{
		current_max = MAX_SUM(current_max, MUL(this->x(i+1, j), i_unpaired_in_MBL_energy));
	}

	if(!pushed && COMPARE(current_max, this->x(i,j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_WMBL, i+1, j);
		pushed = true;
	}
#endif // _TRANS_WMBL_5p_EXT_2_WMBL_

#ifdef _TRANS_fp_WL_branchized_Wcoax_CONCAT_tp_WL_WMBL_2_WMBL_
	//for(int ip = i + MIN_LOOP; ip < j - MIN_LOOP; ip++)
	for(int ip = i + 1; ip < j; ip++)
	{
		double current_concatenation_energy = MUL(MAX_SUM(Wcoax->x(i,ip), WL->x_branchized(i,ip)), MAX_SUM(WL->x(ip+1, j), this->x(ip+1, j)));

		// Update current_cumulative.
		current_max = MAX_SUM(current_max, current_concatenation_energy);

		if(!pushed && COMPARE(current_max, this->x(i,j)))
		{
			// Resolve left side between Wcoax and WLclosed and right side between WL and WMBL.
			double wcoax_branchized_max = MAX_SUM(Wcoax->x(i,ip), WL->x_branchized(i,ip));
			if(COMPARE(Wcoax->x(i,ip), wcoax_branchized_max))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wcoax, i, ip);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_branchized_V, i, ip);
			}

			double wmbl_wl_max = MAX_SUM(WL->x(ip+1, j), this->x(ip+1, j));
			if(COMPARE(WL->x(ip+1, j), wmbl_wl_max))
			{
				this->energy_loops->tb_stack->push_substr(tb_WL, ip+1, j);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMBL, ip+1, j);
			}

			pushed = true;
		}
	}
#endif // _TRANS_fp_WL_branchized_Wcoax_CONCAT_tp_WL_WMBL_2_WMBL_

	if(!COMPARE(current_max, this->x(i,j)))
	{
		printf("Stochastic Traceback error in WMBL stoch energy traceback @ %s(%d)\n", __FILE__, __LINE__);
		exit(0);
	}
}

void t_WMBL::stoch_energy_tb(int i, int j)
{
	t_WL* WL = this->energy_loops->WL;
	t_Wcoax* Wcoax = this->energy_loops->Wcoax;

	// Get dangling and unpaired nucleotide energies.
	double i_dangle_energy = ZERO;
	double j_dangle_energy = ZERO;
	double i_unpaired_in_MBL_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;

	// Generate the random cumulative.
	double random_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), this->x(i,j));
	double current_cumulative = ZERO;
	bool pushed = false;

#ifdef _TRANS_Wcoax_2_WMBL_
	// WMBL branching loop.
	current_cumulative = Wcoax->x(i,j);

	if(!pushed && GEQ(current_cumulative, random_cumulative))
	{
		//printf("Pushing Wcoax in WMBL(%d, %d) (%.15f, %.15f)\n", i, j, log(Wcoax->x(i,j)), log(random_cumulative));
		this->energy_loops->tb_stack->push_substr(tb_Wcoax, i, j);
		pushed = true;
	}
#endif // _TRANS_Wcoax_2_WMBL_

#ifdef _TRANS_WMBL_5p_EXT_2_WMBL_
	//this->x(i,j) = MAX_SUM(this->x(i,j), MUL(this->x(i+1, j), i_unpaired_in_MBL_energy));
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
	{
		current_cumulative = MAX_SUM(current_cumulative, MUL(this->x(i+1, j), i_unpaired_in_MBL_energy));
		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_WMBL, i+1, j);
			pushed = true;
		}
	}
#endif // _TRANS_WMBL_5p_EXT_2_WMBL_

#ifdef _TRANS_fp_WL_branchized_Wcoax_CONCAT_tp_WL_WMBL_2_WMBL_
	//for(int ip = i + MIN_LOOP; ip < j - MIN_LOOP; ip++)
	for(int ip = i + 1; ip < j; ip++)
	{
		double current_concatenation_energy = MUL(MAX_SUM(Wcoax->x(i,ip), WL->x_branchized(i,ip)), MAX_SUM(WL->x(ip+1, j), this->x(ip+1, j)));

		// Update current_cumulative.
		current_cumulative = MAX_SUM(current_cumulative, current_concatenation_energy);

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			// Resolve left side between Wcoax and WLclosed and right side between WL and WMBL.
			double wcoax_branchized_cumulative = MAX_SUM(Wcoax->x(i,ip), WL->x_branchized(i,ip));
			double random_wl_coax_w_closed_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), wcoax_branchized_cumulative);
			if(GEQ(Wcoax->x(i,ip), random_wl_coax_w_closed_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wcoax, i, ip);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_branchized_V, i, ip);
			}

			double wmbl_wl_cumulative = MAX_SUM(WL->x(ip+1, j), this->x(ip+1, j));
			double random_wmbl_wl_closed_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), wmbl_wl_cumulative);
			if(GEQ(WL->x(ip+1, j), random_wmbl_wl_closed_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_WL, ip+1, j);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMBL, ip+1, j);
			}

			pushed = true;
		}
	}
#endif // _TRANS_fp_WL_branchized_Wcoax_CONCAT_tp_WL_WMBL_2_WMBL_

	if(!COMPARE(current_cumulative, this->x(i,j)))
	{
		printf("Stochastic Traceback error in WMBL stoch energy traceback @ %s(%d)\n", __FILE__, __LINE__);
		exit(0);
	}
}


