#ifndef _NNM_ENERGY_COMPILATION_DIRECTIVES_
#define _NNM_ENERGY_COMPILATION_DIRECTIVES_

#define _LINEAR_NNM_COMPUTATIONS_
//#define _LOG_NNM_COMPUTATIONS_

#undef _INSTANT_BACKTRACKING_
	
#define _HANDLE_DOMINS_ARRAYS_

// The flag for setting all energies to 1 so that number of structural alignments
// can be counted.
#define _UNIFORM_ENERGIES_

// Transitions into V
#define _TRANS_HP_LOOP_2_V_
#define _TRANS_V_INT_LOOP_2_V_
#define _TRANS_WMB_DANGLE_STACK_2_V_
#define _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_ // ip enumerations
#define _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_ // jp enumerations

// Transitions into WMBL
#define _TRANS_Wcoax_2_WMBL_
#define _TRANS_WMBL_5p_EXT_2_WMBL_
#define _TRANS_fp_WL_branchized_Wcoax_CONCAT_tp_WL_WMBL_2_WMBL_

// Transitions into WMB
#define _TRANS_WMBL_2_WMB_
#define _TRANS_WMB_5p_EXT_2_WMB_

// Transitions into WL_branchized
#define _TRANS_V_DANGLE_STACK_2_WL_branchized_

// Transitions into WL
#define _TRANS_WL_branchized_2_WL_
#define _TRANS_WL_5p_EXT_2_WL_

// Transitions into W
#define _TRANS_WL_2_W_
#define _TRANS_W_3p_EXT_2_W_

// Transitions into Wcoax
#define _TRANS_V_COAX_STACK_2_Wcoax_

// Transitions into Wout
#define _TRANS_V_DANGLE_STACK_CONCAT_Wout_2_Wout_
#define _TRANS_V_COAX_STACK_V_CONCAT_Wout_2_Wout_

#endif // _NNM_ENERGY_COMPILATION_DIRECTIVES_



