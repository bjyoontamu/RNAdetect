#include <stdio.h>
#include <stdlib.h>
#include "array_io.h"
#include "energy_loops.h"
#include "energy_array.h"
#include "v.h"
#include "wl.h"
#include "w.h"
#include "wmbl.h"
#include "wmb.h"
#include "wcoax.h"
#include "wout.h"
#include "nnm_math.h"

#include "../structure/structure.h"
#include "../utils/ansi_string/ansi_string.h"
#include "../utils/file/utils.h"

t_array_io::t_array_io(t_energy_loops* _energy_loops)
{
	this->energy_loops = _energy_loops;
}

t_array_io::~t_array_io()
{}

// Assuming that the arrays are allocated.
void t_array_io::op_arrays()
{
	// The order of writing does not matter because indices will be output.
	// File format is very simple: i j [array value], all in binary format.
	for(int i_array = Vio; i_array < N_ARRAYS; i_array++)
	{
		// Open the op file for current array.
		t_string* cur_array_op_fp = new t_string();
//		cur_array_op_fp->sprintf("%s/%s", ARRAY_OP_PATH, array_io_fn[i_array]);
  		cur_array_op_fp->sprintf("./%s",  array_io_fn[i_array]);  

		FILE* f_op = open_f(cur_array_op_fp->str(), "wb");
		if(f_op == NULL)
		{
			printf("Could not open %s for writing.\n", cur_array_op_fp->str());
			exit(0);
		}

		if(i_array != WOUTio)
		{
			// Get current array.
			t_energy_array* cur_energy_array = get_energy_array_by_id(i_array);
			if(cur_energy_array == NULL)
			{
				printf("Could not resolve array with id %d\n", i_array);
				exit(0);
			}
			
			// Write the length of sequences at the beginning of each file.
			short n_nucs = (short)this->energy_loops->rna_seq->numofbases;
			fwrite((void*)&n_nucs, sizeof(short), 1, f_op);
			for(short i = 1; i <= this->energy_loops->rna_seq->numofbases; i++)
			{
				for(short j = i+1; j <= this->energy_loops->rna_seq->numofbases; j++)
				{
					if(cur_energy_array->x(i, j) != CONVERT_FROM_LIN(0.0f))
					{
						double current_val = cur_energy_array->x(i, j);
						fwrite((void*)&i, sizeof(short), 1, f_op);
						fwrite((void*)&j, sizeof(short), 1, f_op);
						fwrite((void*)&current_val, sizeof(double), 1, f_op);
					}
				} // j loop
			} // i loop
		}
		else
		{
			// Wout file format is different: [index] [value]
			for(short i = 0; i <= this->energy_loops->rna_seq->numofbases; i++)
			{
				if(this->energy_loops->Wout->x(i) != CONVERT_FROM_LIN(0.0f))
				{
					double current_val = this->energy_loops->Wout->x(i);
					fwrite((void*)&i, sizeof(short), 1, f_op);
					fwrite((void*)&current_val, sizeof(double), 1, f_op);
				}
			} // i loop for Wout op.
		}

		// Clean up for this array.
		printf("[%s ok]", array_io_fn[i_array]);
		delete(cur_array_op_fp);
		fclose(f_op);
	} // i_array loop.
}

void t_array_io::ip_arrays()
{
	// The order of writing does not matter because indices will be output.
	// File format is very simple: i j [array value], all in binary format.
	for(int i_array = Vio; i_array < N_ARRAYS; i_array++)
	{
		// Open the op file for current array.
		t_string* cur_array_ip_fp = new t_string();
		cur_array_ip_fp->sprintf("%s/%s", ARRAY_IP_PATH, array_io_fn[i_array]);
		FILE* f_ip = open_f(cur_array_ip_fp->str(), "rb");
		if(f_ip == NULL)
		{
			printf("Could not open %s for reading.\n", cur_array_ip_fp->str());
			exit(0);
		}

		// Check for WOUTio, 
		if(i_array != WOUTio)
		{
			// Get current array.
			t_energy_array* cur_energy_array = get_energy_array_by_id(i_array);
			if(cur_energy_array == NULL)
			{
				printf("Could not resolve array with id %d\n", i_array);
				exit(0);
			}

			// Read the length of sequence from file, must match with the current input.
			short n_nucs_from_file = 0;
			fread((void*)&n_nucs_from_file, sizeof(short), 1, f_ip);
			if(n_nucs_from_file != (short)this->energy_loops->rna_seq->numofbases)
			{
				printf("Lengths from file and sequence data are not matching (%d, %d), different sequences?\n", 
					n_nucs_from_file, this->energy_loops->rna_seq->numofbases);

				exit(0);
			}

			// Read the current file.
			while(1)
			{
				double current_val = 0.0f;
				short i = 0;
				short j = 0;
				if(fread((void*)&i, sizeof(short), 1, f_ip) != 1)
				{
					// If the file has ended here, that is a valid ending, break.
					break;
				}

				if(fread((void*)&j, sizeof(short), 1, f_ip) != 1)
				{
					printf("Could not read index j for i = %d in %s\n", i, cur_array_ip_fp->str());
					exit(0);
				}

				if(fread((void*)&current_val, sizeof(double), 1, f_ip) != 1)
				{
					printf("Could not value for (i, j)=(%d, %d) in %s\n", i,j, cur_array_ip_fp->str());
					exit(0);
				}
				else
				{
					// Save current value.
					printf("%s(%d, %d) = %.15f\n", cur_array_ip_fp->str(), i,j, current_val);
					cur_energy_array->x(i,j) = current_val;
				}
			} // file reading loop.
		}
		else
		{
			short i = 0;
			while(1)
			{
				double current_val = 0.0f;				
				if(fread((void*)&i, sizeof(short), 1, f_ip) != 1)
				{
					// If the file has ended here, that is a valid ending, break.
					break;
				}

				if(fread((void*)&current_val, sizeof(double), 1, f_ip) != 1)
				{
					printf("Could not value for i=%d in %s\n", i, cur_array_ip_fp->str());
					exit(0);
				}
				else
				{
					this->energy_loops->Wout->x(i) = current_val;
					printf("Wout(%d) = %.15f\n", i, current_val);
				}
			} // file reading loop.

			if(i != this->energy_loops->rna_seq->numofbases)
			{
				printf("Error loading Wout, read i = %d last\n", i);
				exit(0);
			}
		}

		// Clean up for this array.
		printf("[%s ok]", array_io_fn[i_array]);
		delete(cur_array_ip_fp);
		fclose(f_ip);
	} // i_array loop.

	printf("\n");
}

// enum{Vio, WLio, Wio, WMBLio, WMBio, WCOAXio, WOUTio, N_ARRAYS};
t_energy_array* t_array_io::get_energy_array_by_id(int array_id)
{
	switch(array_id)
	{
		case Vio:
			return(this->energy_loops->V->energy_array);
			break;

		case WLio:
			return(this->energy_loops->WL->energy_array);
			break;

		case Wio:
			return(this->energy_loops->W->energy_array);
			break;

		case WMBLio:
			return(this->energy_loops->WMBL->energy_array);
			break;

		case WMBio:
			return(this->energy_loops->WMB->energy_array);
			break;

		case WCOAXio:
			return(this->energy_loops->Wcoax->energy_array);

			break;
		default:
			printf("Could not resolve array id %d\n", array_id);
			exit(0);
	} // array_id check.
}

