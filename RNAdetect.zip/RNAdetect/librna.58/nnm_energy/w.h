#ifndef _W_
#define _W_

class t_structure;
class t_energy_array;
class t_energy_loops;

class t_W
{
public:
	t_W(t_energy_loops* _energy_loops);
	~t_W();

	// This is the energy storage.
	t_energy_array* energy_array;
	t_energy_array* ext_energy_array;

	// RNA sequence.
	t_structure* rna_seq;

	// Minimum energy loops that this W array belongs to.
	// By gaining access to this class, W has access to all other arrays.
	t_energy_loops* energy_loops;

	double (*MAX_SUM)(double,double);

	// Compute V for a subsequence.
	void compute(int i, int j);
	void compute_ext_dependencies(int i, int j);

	// Accession function.
	double& x(int i, int j);
	double& x_ext(int i, int j);

	void min_energy_tb(int i, int j);
	void stoch_energy_tb(int i, int j);
};

#endif // _W_


