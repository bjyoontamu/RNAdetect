#include <stdio.h>
#include <stdlib.h>
#include "v.h"
#include "wl.h"
#include "wmbl.h"
#include "wmb.h"
#include "wout.h"
#include "energy_array.h"
#include "energy_loops.h"
#include "nnm_math.h"
#include "../structure/structure.h"
#include "thermo_parameters.h"
#include "tb_stack.h"
#include "sampling_math.h"
#include "nnm_energy_compilation_directives.h"
#include "stoch_energy_structures.h"
#include "cli.h"
#include "../structure/folding_constraints.h"

#include "../utils/xmath/log/xlog_math.h"
#include "../utils/console_ui/console_progress_bar.h"

#include "coinc_info.h"

bool _DUMP_WOUT_MESSAGES_ = false;

t_Wout::t_Wout(t_energy_loops* _energy_loops)
{
	this->energy_loops = _energy_loops;

	// Copy rna sequence pointer for later use.
	this->rna_seq = this->energy_loops->rna_seq;

	this->MAX_SUM = this->energy_loops->MAX_SUM;

	this->mem_usage = 0.0f;

	// Allocate energy array.
	// Just need a linear array for W_out, not the usual energy array.
	this->energy_array = (double*)malloc(sizeof(double) * (this->energy_loops->rna_seq->numofbases + 3));
	this->mem_usage += (sizeof(double) * (this->energy_loops->rna_seq->numofbases + 3));

	// Allocate and set external Wout array.
	this->ext_energy_array = (double*)malloc(sizeof(double) * (this->energy_loops->rna_seq->numofbases + 3));
	this->mem_usage += (sizeof(double) * (this->energy_loops->rna_seq->numofbases + 3));

	for(int i = this->energy_loops->rna_seq->numofbases; i >= 1; i--)
	{
		this->energy_array[i] = ZERO;
		this->ext_energy_array[i] = ZERO;
	}
}

// Free the energy array.
t_Wout::~t_Wout()
{
	free(this->energy_array);
	free(this->ext_energy_array);
}

// Computes all Wout.
// This array models the external loop energy model on RNA structure.
// There is no energies assigned to unpaired nucleotides but dangling
// energies next to helices are the same as mbl loops.
// Consequently everything boils down to determining the most stable
// V combination considering the danglings.
void t_Wout::compute()
{	
	// Initialize Wout.
	this->energy_array[0] = CONVERT_FROM_LIN(1.0f);
	for(int i = 1; i <= this->energy_loops->rna_seq->numofbases; i++)
	{
		// These are not set to INFINITY, unlike other arrays.
		// This is because Wout represents external loop where the unpaired case in assumed as ground energy of 0.0.
		// Wout[0] represents a boundary condition for Wout with unpaired nucleotides on 5' side.

		if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i) &&
			this->energy_loops->folding_constraints->same_loop_map[1][i])
		{
			this->energy_array[i] = MUL(this->x(i-1), this->energy_loops->thermo_pars->unpaired_nuc_in_ext_penalty); 
		}
		else
		{
			this->energy_array[i] = ZERO;
		}
	} // i loop.

	t_console_progress_bar* prog_bar = NULL;

if(_DUMP_WOUT_MESSAGES_)
	prog_bar = new t_console_progress_bar('>', true, this->rna_seq->numofbases);

	t_V* V = this->energy_loops->V;

	for(int j = 1; j <= this->energy_loops->rna_seq->numofbases; j++)
	{
if(_DUMP_WOUT_MESSAGES_)
{
		printf("---------------------------\n");
		printf("Computing Wout(%d)\n", j);
}

if(_DUMP_WOUT_MESSAGES_)
		prog_bar->update_bar(j);

		// 1 and j must be in the same loop for valid computation of this index pair.
		if(this->energy_loops->folding_constraints->same_loop_map[1][j])
		{
#ifdef _LINEAR_NNM_COMPUTATIONS_
			do
#endif // _LINEAR_NNM_COMPUTATIONS_
			{
				double unpaired_nuc_in_ext_loop_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_ext_penalty;
				double two_unpaired_nuc_in_ext_loop_energy = MUL(unpaired_nuc_in_ext_loop_energy, unpaired_nuc_in_ext_loop_energy);
				// Extend on 3' with unpaired nucleotide.

				if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
				{
					this->x(j) = MUL(this->x(j-1), unpaired_nuc_in_ext_loop_energy);
				}

				// Extend on 3' with a V(i, j) and possible 4 danglings.
				//for(int i = 1; i < MAX(1, j - MIN_LOOP); i++)
				for(int i = 1; i <= j - MIN_LOOP; i++)
				{
					if(this->energy_loops->folding_constraints->same_loop_map[1][i])
					{
#ifdef _TRANS_V_DANGLE_STACK_CONCAT_Wout_2_Wout_
					double i_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(j,i+1,i);
					double j_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(j-1,i,j);
					double ij_dangle_energy = this->energy_loops->thermo_pars->ext_loop_mismatch_energy(j-1, i+1, i, j);

					// Include the contributions of unpaired nucs in external loop.
					if(j - i <= this->energy_loops->cli->n_max_separation)
					{
						double current_concat_energy_no_dangle =  MUL3(this->x(i-1), V->x(i, j), 
							this->energy_loops->thermo_pars->terminal_pair_penalty(i, j));

						double current_concat_energy_i_dangle = ZERO;
						if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
						{
							current_concat_energy_i_dangle = MUL5(this->x(i-1), 
								V->x(i+1, j), 
								unpaired_nuc_in_ext_loop_energy, 
								i_dangle_energy, 
								this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, j));
						}

						double current_concat_energy_j_dangle = ZERO;
						if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
						{
							current_concat_energy_j_dangle = MUL5(this->x(i-1), 
								V->x(i, j-1), 
								unpaired_nuc_in_ext_loop_energy, 
								j_dangle_energy, 
								this->energy_loops->thermo_pars->terminal_pair_penalty(i, j-1));
						}

						double current_concat_energy_ij_dangle = ZERO;
						if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i, j))
						{
							current_concat_energy_ij_dangle = MUL5(this->x(i-1), 
								V->x(i+1, j-1), 
								two_unpaired_nuc_in_ext_loop_energy, 
								ij_dangle_energy, 
								this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, j-1));
						}

if(_DUMP_WOUT_MESSAGES_)
{
#ifdef _LINEAR_NNM_COMPUTATIONS_
						double log_correction = log(POW(this->energy_loops->thermo_pars->unpaired_nuc_in_ext_penalty, j-i+1));
						if(current_concat_energy_no_dangle != ZERO)
							printf("No dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i, j, log(current_concat_energy_no_dangle)-log_correction);

						if(current_concat_energy_i_dangle != ZERO)
							printf("i dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i+1, j, log(current_concat_energy_i_dangle)-log_correction);

						if(current_concat_energy_j_dangle != ZERO)
							printf("j dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i, j-1, log(current_concat_energy_j_dangle)-log_correction);

						//if(current_concat_energy_ij_dangle != ZERO)
						//	printf("i & j dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i+1, j-1, log(current_concat_energy_ij_dangle)-log_correction);
#endif // _LINEAR_NNM_COMPUTATIONS_

#ifdef _LOG_NNM_COMPUTATIONS_
						printf("No dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i, j, current_concat_energy_no_dangle);
						printf("i dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i+1, j, current_concat_energy_i_dangle);
						printf("j dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i, j-1, current_concat_energy_j_dangle);
						printf("i & j dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i+1, j-1, current_concat_energy_ij_dangle);
#endif // _LINEAR_NNM_COMPUTATIONS_

}
						this->x(j) = MAX_SUM(this->x(j), current_concat_energy_no_dangle);
						this->x(j) = MAX_SUM(this->x(j), current_concat_energy_i_dangle);
						this->x(j) = MAX_SUM(this->x(j), current_concat_energy_j_dangle);
						this->x(j) = MAX_SUM(this->x(j), current_concat_energy_ij_dangle);
					}
#endif // _TRANS_V_DANGLE_STACK_Wout_

#ifdef _TRANS_V_COAX_STACK_V_CONCAT_Wout_2_Wout_
					// Consider all cases of coaxial stacking of two helices 
					// at i-ip and (ip+1)-j
					for(int ip = i + MIN_LOOP; 
						(ip - i) <= this->energy_loops->cli->n_max_separation && 
						(j - (ip+1)) <= this->energy_loops->cli->n_max_separation && 
						(ip <= j - MIN_LOOP); 
						ip++)
					{
						double current_coax_stack_energy = ZERO;

						// Consider all 3 cases of coaxial stacking.
						// 1: Perfect stacking between i-ip and ip-(j-1).
						double perfect_stacking_energy = MUL6(this->x(i-1), 
															V->x(i, ip),
															V->x(ip+1, j),
															this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1), 
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
															this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));

						// 2: 
						// This is the energy of stacking of mismatched pair on (i, ip-1)
						double stack_on_i_p_ip_n_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(ip-1, i+1, i, ip);

						// This is the energy of coaxial stacking.
						double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);

						double imperfect_stacking_energy1 = ZERO;	

						if(j > ip+1)
						{
							imperfect_stacking_energy1 = MUL8(this->x(i-1), 
																V->x(i+1, ip-1), V->x(ip+1, j),
																stack_on_i_p_ip_n_in_coax_stack_energy, 
																energy_imperfect_coaxial_stack1,
																two_unpaired_nuc_in_ext_loop_energy,
																this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
																this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));
						}

						// 3
						// This is the energy of stacking of mismatched pair on (i, ip-1)
						double stack_on_ipj_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-1, ip+2, ip+1, j);

						// This is the energy of coaxial stacking.
						double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);

						double imperfect_stacking_energy2 = ZERO;
						if(ip > i && j-1 > ip+2)
						{
							imperfect_stacking_energy2 = MUL8(this->x(i-1), 
																V->x(i, ip), V->x(ip+2, j-1),
																stack_on_ipj_in_coax_stack_energy, 
																energy_imperfect_coaxial_stack2,
																two_unpaired_nuc_in_ext_loop_energy, 
																this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
																this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1));
						}

						// Set new energy.
						this->x(j) = MAX_SUM(this->x(j), perfect_stacking_energy);

						if(this->energy_loops->folding_constraints->str_coinc_map[i][ip] &&
							!this->energy_loops->folding_constraints->forbid_non_v_emission(i, ip))
						{
							this->x(j) = MAX_SUM(this->x(j), imperfect_stacking_energy1);
						}

						if(this->energy_loops->folding_constraints->str_coinc_map[ip+1][j] &&
							!this->energy_loops->folding_constraints->forbid_non_v_emission(ip+1, j))
						{
							this->x(j) = MAX_SUM(this->x(j), imperfect_stacking_energy2);
						}
					} // ip loop
#endif //_TRANS_V_COAX_STACK_V_Wout_
					} // 1-i same loop check.
				} // i loop for searching for a closing branch.
			} // overflow check.
#ifdef _LINEAR_NNM_COMPUTATIONS_
			while(this->energy_loops->internal_off_diagonal_indexed_arrays_out_of_bounds(1, j));
#endif // _LINEAR_NNM_COMPUTATIONS_
		} // 1-j same loop check

if(_DUMP_WOUT_MESSAGES_)
		printf("Wout(%d) = %.10f\n", j, log(this->x(j)));
	} // j loop.

if(_DUMP_WOUT_MESSAGES_)
	delete(prog_bar);
} // t_Wout::compute

double& t_Wout::x(int j)
{
	return(this->energy_array[j]);
}

// Baktrack and push all the branches in the external loop onto stack.
// Wout computation and traceback is different from all arrays.
void t_Wout::min_energy_tb(int j)
{
	// This is the boundary condition for starting computations.
	// Do not do anything.
	if(j == 0)
	{
		return;
	}

	// Generate the random cumulative.
	double current_max = ZERO;

	bool pushed = false;

	t_V* V = this->energy_loops->V;

	double unpaired_nuc_in_ext_loop_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_ext_penalty;
	double two_unpaired_nuc_in_ext_loop_energy = MUL(unpaired_nuc_in_ext_loop_energy, unpaired_nuc_in_ext_loop_energy);

	// Extend on 3' with unpaired nucleotide.
	if(this->energy_loops->folding_constraints->same_loop_map[1][j])
	{
		if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
		{
			current_max = MAX_SUM(current_max, MUL(this->x(j-1), unpaired_nuc_in_ext_loop_energy));
		}
	}

	if(!pushed && COMPARE(current_max, this->x(j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_Wout, 1, j-1);
		pushed = true;
	}
//
//if(_DUMP_WOUT_MESSAGES_)
//{
//#ifdef _LINEAR_NNM_COMPUTATIONS_
//	printf("Wout(%d) MAP traceback j extension recursing on Wout(%d): %.5f\n", j, j-1, 
//#endif
//}

	// Extend on 3' with a V(i, j) and possible 4 danglings.
	for(int i = 1; i <= j - MIN_LOOP; i++)
	{
		if(this->energy_loops->folding_constraints->same_loop_map[1][i])
		{
#ifdef _TRANS_V_DANGLE_STACK_CONCAT_Wout_2_Wout_
		double i_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(j,i+1,i);
		double j_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(j-1,i,j);
		double ij_dangle_energy = this->energy_loops->thermo_pars->ext_loop_mismatch_energy(j-1, i+1, i, j);

		double unpaired_nuc_in_ext_loop_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_ext_penalty;
		double two_unpaired_nuc_in_ext_loop_energy = MUL(unpaired_nuc_in_ext_loop_energy, unpaired_nuc_in_ext_loop_energy);

		double current_concat_energy_no_dangle = current_concat_energy_no_dangle = MUL3(this->x(i-1), V->x(i, j), this->energy_loops->thermo_pars->terminal_pair_penalty(i, j));

		double current_concat_energy_i_dangle = ZERO;
		if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
		{
			current_concat_energy_i_dangle = MUL5(this->x(i-1), 
				V->x(i+1, j), 
				unpaired_nuc_in_ext_loop_energy, 
				i_dangle_energy, 
				this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, j));
		}

		double current_concat_energy_j_dangle = ZERO;
		if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
		{
			current_concat_energy_j_dangle = MUL5(this->x(i-1), 
				V->x(i, j-1), 
				unpaired_nuc_in_ext_loop_energy, 
				j_dangle_energy, 
				this->energy_loops->thermo_pars->terminal_pair_penalty(i, j-1));
		}

		double current_concat_energy_ij_dangle = ZERO;
		if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i,j))
		{
			current_concat_energy_ij_dangle =  MUL5(this->x(i-1), 
				V->x(i+1, j-1), 
				two_unpaired_nuc_in_ext_loop_energy, 
				ij_dangle_energy, 
				this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, j-1));
		}

if(_DUMP_WOUT_MESSAGES_)
{
#ifdef _LINEAR_NNM_COMPUTATIONS_
						double log_correction = log(POW(this->energy_loops->thermo_pars->unpaired_nuc_in_ext_penalty, j-i+1));
						if(current_concat_energy_no_dangle != ZERO)
							printf("No dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i, j, log(current_concat_energy_no_dangle)-log_correction);

						if(current_concat_energy_i_dangle != ZERO)
							printf("i dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i+1, j, log(current_concat_energy_i_dangle)-log_correction);

						if(current_concat_energy_j_dangle != ZERO)
							printf("j dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i, j-1, log(current_concat_energy_j_dangle)-log_correction);

						//if(current_concat_energy_ij_dangle != ZERO)
						//	printf("i & j dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i+1, j-1, log(current_concat_energy_ij_dangle)-log_correction);
#endif // _LINEAR_NNM_COMPUTATIONS_

#ifdef _LOG_NNM_COMPUTATIONS_
						printf("No dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i, j, current_concat_energy_no_dangle);
						printf("i dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i+1, j, current_concat_energy_i_dangle);
						printf("j dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i, j-1, current_concat_energy_j_dangle);
						printf("i & j dangle: (1-%d) + V(%d, %d) = %.5f\n", i-1, i+1, j-1, current_concat_energy_ij_dangle);
#endif // _LINEAR_NNM_COMPUTATIONS_

}

		// Include the contributions of unpaired nucs in external loop.
		if(j - i <= this->energy_loops->cli->n_max_separation)
		{
			current_max = MAX_SUM(current_max, current_concat_energy_no_dangle);
			if(!pushed && COMPARE(current_max, this->x(j)))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i, j);
				pushed = true;
			}

			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
			{
				current_max = MAX_SUM(current_max, current_concat_energy_i_dangle);
			}

			if(!pushed && COMPARE(current_max, this->x(j)))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i+1, j);
				pushed = true;
			}

			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
			{
				current_max = MAX_SUM(current_max, current_concat_energy_j_dangle);
			}

			if(!pushed && COMPARE(current_max, this->x(j)))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i, j-1);
				pushed = true;
			}

			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i, j))
			{
				current_max = MAX_SUM(current_max, current_concat_energy_ij_dangle);
			}

			if(!pushed && COMPARE(current_max, this->x(j)))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i+1, j-1);
				pushed = true;
			}
		}
#endif // _TRANS_V_DANGLE_STACK_Wout_

#ifdef _TRANS_V_COAX_STACK_V_CONCAT_Wout_2_Wout_
		// Consider all cases of coaxial stacking of two helices 
		// at i-ip and (ip+1)-j
		for(int ip = i + MIN_LOOP; 
			(ip - i) <= this->energy_loops->cli->n_max_separation && 
			(j - (ip+1)) <= this->energy_loops->cli->n_max_separation && 
			(ip <= j - MIN_LOOP); 
			ip++)
		{
			double current_coax_stack_energy = ZERO;

			// Consider all 3 cases of coaxial stacking.
			// 1: Perfect stacking between i-ip and ip-(j-1).
			double perfect_stacking_energy = MUL6(this->x(i-1), 
												V->x(i, ip),
												V->x(ip+1, j),
												this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1), 
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));


			//current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);
			current_max = MAX_SUM(current_max, perfect_stacking_energy);
			if(!pushed && COMPARE(current_max, this->x(j)))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i, ip);
				this->energy_loops->tb_stack->push_substr(tb_V, ip+1, j);
				pushed = true;
			}

			// 2: 
			// This is the energy of stacking of mismatched pair on (i, ip-1)
			double stack_on_i_p_ip_n_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(ip-1, i+1, i, ip);

			// This is the energy of coaxial stacking.
			double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);

			double imperfect_stacking_energy1 = ZERO;	

			if(j > ip+1)
			{
				imperfect_stacking_energy1 = MUL8(this->x(i-1), 
													V->x(i+1, ip-1), V->x(ip+1, j),
													stack_on_i_p_ip_n_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack1,
													two_unpaired_nuc_in_ext_loop_energy,
													this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
													this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));
			}

			if(this->energy_loops->folding_constraints->str_coinc_map[i][ip] &&
				!this->energy_loops->folding_constraints->forbid_non_v_emission(i, ip))
			{
				current_max = MAX_SUM(current_max, imperfect_stacking_energy1);
			}

			if(!pushed && COMPARE(current_max, this->x(j)))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i+1, ip-1);
				this->energy_loops->tb_stack->push_substr(tb_V, ip+1, j);
				pushed = true;
			}

			// 3
			// This is the energy of stacking of mismatched pair on (i, ip-1)
			double stack_on_ipj_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-1, ip+2, ip+1, j);

			// This is the energy of coaxial stacking.
			double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);

			double imperfect_stacking_energy2 = ZERO;
			if(ip > i && j-1 > ip+2)
			{
				imperfect_stacking_energy2 = MUL8(this->x(i-1), 
													V->x(i, ip), V->x(ip+2, j-1),
													stack_on_ipj_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack2,
													two_unpaired_nuc_in_ext_loop_energy, 
													this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
													this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1));
			}

			if(this->energy_loops->folding_constraints->str_coinc_map[ip+1][j] &&
				!this->energy_loops->folding_constraints->forbid_non_v_emission(ip+1, j))
			{
				current_max = MAX_SUM(current_max, imperfect_stacking_energy2);
			}

			if(!pushed && COMPARE(current_max, this->x(j)))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i, ip);
				this->energy_loops->tb_stack->push_substr(tb_V, ip+2, j-1);
				pushed = true;
			}

			//// Set new energy.
			//this->x(j) = MAX_SUM(this->x(j), perfect_stacking_energy);
			//this->x(j) = MAX_SUM(this->x(j), imperfect_stacking_energy1);
			//this->x(j) = MAX_SUM(this->x(j), imperfect_stacking_energy2);
		} // ip loop			
#endif // _TRANS_V_COAX_STACK_V_CONCAT_Wout_2_Wout_
		} // 1-i same loop check.
	} // i loop for searching for a closing branch.

	if(!pushed || !COMPARE(this->x(j), current_max))
	{
		printf("Traceback error in Wout(%d) @ %s(%d): (%lf, %lf)\n", j, __FILE__, __LINE__, log(current_max), log(this->x(j)));
		exit(0);
	}
}

// Baktrack and push all the branches in the external loop onto stack.
// Wout computation and traceback is different from all arrays.
void t_Wout::stoch_energy_tb(int j)
{
	// This is the boundary condition for starting computations.
	// Do not do anything.
	if(j == 0)
	{
		return;
	}

	// Generate the random cumulative.
	double random_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), this->x(j));

	double current_cumulative = ZERO;

	bool pushed = false;

	double unpaired_nuc_in_ext_loop_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_ext_penalty;
	double two_unpaired_nuc_in_ext_loop_energy = MUL(unpaired_nuc_in_ext_loop_energy, unpaired_nuc_in_ext_loop_energy);

	t_V* V = this->energy_loops->V;

	// Extend on 3' with unpaired nucleotide.
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
	{
		//printf("%s(%d)\n", __FILE__, __LINE__);
		current_cumulative = MAX_SUM(current_cumulative, MUL(this->x(j-1), unpaired_nuc_in_ext_loop_energy));
	}

	if(!pushed && GEQ(current_cumulative, random_cumulative))
	{
		this->energy_loops->tb_stack->push_substr(tb_Wout, 1, j-1);
		pushed = true;
	}

	// Extend on 3' with a V(i, j) and possible 4 danglings.
	for(int i = 1; i <= j - MIN_LOOP; i++)
	{
		if(this->energy_loops->folding_constraints->same_loop_map[1][i])
		{
		double i_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(j,i+1,i);
		double j_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(j-1,i,j);
		double ij_dangle_energy = this->energy_loops->thermo_pars->ext_loop_mismatch_energy(j-1, i+1, i, j);

		// Include the contributions of unpaired nucs in external loop.
#ifdef _TRANS_V_DANGLE_STACK_CONCAT_Wout_2_Wout_
		if(j - i <= this->energy_loops->cli->n_max_separation)
		{
			double current_concat_energy_no_dangle =  MUL3(this->x(i-1), 
															V->x(i, j), 
															this->energy_loops->thermo_pars->terminal_pair_penalty(i, j));

			double current_concat_energy_i_dangle = ZERO;
			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
			{
				current_concat_energy_i_dangle =  MUL5(this->x(i-1), 
															V->x(i+1, j), 
															i_dangle_energy, 
															unpaired_nuc_in_ext_loop_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, j));
			}

			double current_concat_energy_j_dangle = ZERO; 
			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
			{
				current_concat_energy_j_dangle =  MUL5(this->x(i-1), 
															V->x(i, j-1), 
															j_dangle_energy, 
															unpaired_nuc_in_ext_loop_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i, j-1));
			}

			double current_concat_energy_ij_dangle = ZERO; 
			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i, j))
			{
				current_concat_energy_ij_dangle =  MUL5(this->x(i-1), 
															V->x(i+1, j-1), 
															ij_dangle_energy, 
															two_unpaired_nuc_in_ext_loop_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, j-1));
			}

			current_cumulative = MAX_SUM(current_cumulative, current_concat_energy_no_dangle);
			if(!pushed && GEQ(current_cumulative, random_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i, j);
				pushed = true;
			}

			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
			{
				current_cumulative = MAX_SUM(current_cumulative, current_concat_energy_i_dangle);
			}
			if(!pushed && GEQ(current_cumulative, random_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->stoch_energy_strs->add_fp_nuc_dangling_on_branch(i);
				this->energy_loops->tb_stack->push_substr(tb_V, i+1, j);
				pushed = true;
			}

			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
			{
				current_cumulative = MAX_SUM(current_cumulative, current_concat_energy_j_dangle);
			}
			if(!pushed && GEQ(current_cumulative, random_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->stoch_energy_strs->add_tp_nuc_dangling_on_branch(j);
				this->energy_loops->tb_stack->push_substr(tb_V, i, j-1);
				pushed = true;
			}

			if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i,j))
			{
				current_cumulative = MAX_SUM(current_cumulative, current_concat_energy_ij_dangle);
			}
			if(!pushed && GEQ(current_cumulative, random_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->stoch_energy_strs->add_mm_pair_on_branch(i,j);
				this->energy_loops->tb_stack->push_substr(tb_V, i+1, j-1);
				pushed = true;
			}
		} // n_max_sep check for i and j.
#endif // _TRANS_V_DANGLE_STACK_2_Wout_

#ifdef _TRANS_V_COAX_STACK_V_CONCAT_Wout_2_Wout_
		// Consider all cases of coaxial stacking of two helices 
		// at i-ip and (ip+1)-j
		for(int ip = i + MIN_LOOP; 
			(ip - i) <= this->energy_loops->cli->n_max_separation && 
			(j - (ip+1)) <= this->energy_loops->cli->n_max_separation && 
			(ip <= j - MIN_LOOP); 
		ip++)
		{
			double current_coax_stack_energy = ZERO;

			// Consider all 3 cases of coaxial stacking.
			// 1: Perfect stacking between i-ip and ip-(j-1).
			double perfect_stacking_energy = MUL6(this->x(i-1), 
												V->x(i, ip),
												V->x(ip+1, j),
												this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1), 
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));


			current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);
			if(!pushed && GEQ(current_cumulative, random_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i, ip);
				this->energy_loops->tb_stack->push_substr(tb_V, ip+1, j);
				pushed = true;
			}

			// 2: 
			// This is the energy of stacking of mismatched pair on (i, ip-1)
			double stack_on_i_p_ip_n_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(ip-1, i+1, i, ip);

			// This is the energy of coaxial stacking.
			double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);

			double imperfect_stacking_energy1 = ZERO;	

			if(j > ip+1)
			{
				imperfect_stacking_energy1 = MUL8(this->x(i-1), 
													V->x(i+1, ip-1), V->x(ip+1, j),
													stack_on_i_p_ip_n_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack1,
													two_unpaired_nuc_in_ext_loop_energy,
													this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
													this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));
			}

			if(this->energy_loops->folding_constraints->str_coinc_map[i][ip] &&
				!this->energy_loops->folding_constraints->forbid_non_v_emission(i, ip))
			{
				current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy1);
			}

			if(!pushed && GEQ(current_cumulative, random_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i+1, ip-1);
				this->energy_loops->tb_stack->push_substr(tb_V, ip+1, j);
				pushed = true;
			}

			// 3
			// This is the energy of stacking of mismatched pair on (i, ip-1)
			double stack_on_ipj_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-1, ip+2, ip+1, j);

			// This is the energy of coaxial stacking.
			double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);

			double imperfect_stacking_energy2 = ZERO;
			if(ip>i && j-1 > ip+2)
			{
				imperfect_stacking_energy2 = MUL8(this->x(i-1), 
													V->x(i, ip), V->x(ip+2, j-1),
													stack_on_ipj_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack2,
													two_unpaired_nuc_in_ext_loop_energy, 
													this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
													this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1));
			}

			if(this->energy_loops->folding_constraints->str_coinc_map[ip+1][j] &&
				!this->energy_loops->folding_constraints->forbid_non_v_emission(ip+1, j))
			{
				current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy2);
			}

			if(!pushed && GEQ(current_cumulative, random_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_Wout, 1, i-1);
				this->energy_loops->tb_stack->push_substr(tb_V, i, ip);
				this->energy_loops->tb_stack->push_substr(tb_V, ip+2, j-1);
				pushed = true;
			}

		} // ip loop
#endif // _TRANS_V_COAX_STACK_V_2_Wout_
		} 
	}// i loop for searching for a closing branch.

	if(!pushed || !COMPARE(this->x(j), current_cumulative))
	{
		printf("Traceback error in Wout(%d) @ %s(%d): %.15f(%.15f), %.15f (%d)\n", j, __FILE__, __LINE__, current_cumulative, random_cumulative, this->x(j), pushed);
		printf("%.15f <-> %.15f (%d)\n", this->x(j), current_cumulative, COMPARE(this->x(j), current_cumulative));
		double log1 = this->x(j);
		double log2 = current_cumulative;

		printf("abs(%.15f - %.15f) = %.15f (%.15f)\n", fabs(log1 - log2), XLOG_EPSILON);

		exit(0);
	}

} // t_Wout::stoch_energy_tb


