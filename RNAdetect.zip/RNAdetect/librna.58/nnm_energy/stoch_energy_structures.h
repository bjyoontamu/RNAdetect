#ifndef _STOCH_ENERGY_STRUCTURES_
#define _STOCH_ENERGY_STRUCTURES_

#include <vector>
using namespace::std;

class t_energy_loops;

//// Following structure keeps track of stacking and dangling unpaired nucleotides, which are necessary
//// for constrained sampling to set exact structure for second sequence.
//struct t_sampled_structure
//{
//	int* bps; // base pairs of all the nucleotides.
//
//	// Stacking and dangling states of unpaired nucleotides.
//	int* stackings_on_branch;
//	int* danglings_on_branch; 
//
//	int* stackings_on_mb_closure;
//	int* danglings_on_mb_closure; 
//};

class t_structure;

class t_stoch_energy_structures
{
public:
	t_stoch_energy_structures(t_energy_loops* _energy_loops);
	~t_stoch_energy_structures();

	t_energy_loops* energy_loops;

	// Base pairs. Defines the complete pairing of all the nucleotides.
	vector<t_structure*>* structures;

	// Initializes a structure.
	void add_structure();

	// Adds a base pair to the current structure.
	void add_bp(int i, int j);

	// Enter the indices of base pair that nuc(s) are stacked on in the following functions.
	void add_fp_nuc_dangling_on_branch(int dangling_nuc_index); 
	void add_tp_nuc_dangling_on_branch(int dangling_nuc_index); 

	void add_fp_nuc_dangling_on_mb_closure(int dangling_nuc_index);
	void add_tp_nuc_dangling_on_mb_closure(int dangling_nuc_index);

	void add_mm_pair_on_branch(int fp_pair_index, int tp_pair_index); 
	void add_mm_pair_on_mb_closure(int fp_pair_index, int tp_pair_index);

	// Dumps all the sampled structures.
	void dump();
};

#endif // _STOCH_ENERGY_STRUCTURES


