#include <stdio.h>
#include <stdlib.h>

#include "../sampling_math.h"

#include "../wcoax.h"
#include "../v.h"
#include "../wl.h"
#include "../wmbl.h"
#include "../wmb.h"
#include "../wout.h"
#include "../energy_array.h"
#include "../energy_loops.h"

#include "../nnm_math.h"
#include "../thermo_parameters.h"
#include "../tb_stack.h"
#include "../min_energy_structure.h"
#include "../stoch_energy_structures.h"

#include "../../structure/structure.h"
#include "../../structure/folding_constraints.h"

bool _DUMP_EXT_WCOAX_MESSAGES_ = false;

double& t_Wcoax::x_ext(int i, int j)
{
	return(this->ext_energy_array->x(i,j));
}


void t_Wcoax::compute_ext_dependencies(int i, int j)
{	
	if(!this->energy_loops->folding_constraints->str_coinc_map[i][j])
	{
		return;
	}

	t_V* V = this->energy_loops->V;

	double multibranch_helix_init_energy = this->energy_loops->thermo_pars->per_helix_penalty;
	double two_multibranch_helix_init_energy = MUL(multibranch_helix_init_energy, multibranch_helix_init_energy);
	double unpaired_nuc_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	double two_unpaired_nuc_in_mbl_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_V_COAX_STACK_2_Wcoax_
	for(int ip = i + MIN_LOOP+1; ip < j-MIN_LOOP-1; ip++)
	{
		// Find minimum coaxially stacked configuration:
		// 1) Immediate stacking of helices: Coaxial stacking of V arrays.
		// 2) Stacking of (i+1, ip-1) and (ip+2, j) by non-canonical base pair at (i,ip+1).
		// 3) Stacking of (i,ip) and (ip+2, j-1) by non-canonical base pair at (ip+1, j).

		V->x_ext(i, ip) = MAX_SUM(V->x_ext(i, ip), 
										MUL6(this->x_ext(i, j),
										this->energy_loops->V->x(ip+1,j),
										this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1),
										two_multibranch_helix_init_energy, 
										this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
										this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j)));

		V->x_ext(ip+1, j) = MAX_SUM(V->x_ext(ip+1, j), 
										MUL6(this->x_ext(i, j),
										this->energy_loops->V->x(i,ip),
										this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1),
										two_multibranch_helix_init_energy, 
										this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
										this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j)));

		// One of the imperfect coax. stacking is by noncanonical pairing of i and ip.
		double stack_i_p_ip_n_in_coax_stack_energy = ZERO;
		double energy_imperfect_coaxial_stack1 = ZERO;
		if(ip+1 <= this->energy_loops->rna_seq->numofbases)
		{
			stack_i_p_ip_n_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(ip-1, i+1, i, ip);

			// This is the energy of coaxial stacking.
			energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);
		}

		double imperfect_stacking_energy1 = ZERO;

		//imperfect_stacking_energy1 = MUL8(V->x(i+1,ip-1), 
		//										V->x(ip+1,j),
		//										stack_i_p_ip_n_in_coax_stack_energy, 
		//										energy_imperfect_coaxial_stack1, 
		//										two_multibranch_helix_init_energy, 
		//										two_unpaired_nuc_in_mbl_energy,
		//										this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
		//										this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));

		if(this->energy_loops->folding_constraints->str_coinc_map[i][ip] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i, ip))
		{
			V->x_ext(i+1, ip-1) = MAX_SUM(V->x_ext(i+1, ip-1), 
											MUL8(this->x_ext(i,j), 
													V->x(ip+1,j),
													stack_i_p_ip_n_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack1, 
													two_multibranch_helix_init_energy, 
													two_unpaired_nuc_in_mbl_energy,
													this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
													this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j)));


			V->x_ext(ip+1, j) = MAX_SUM(V->x_ext(ip+1, j), 
											MUL8(this->x_ext(i,j), 
													V->x(i+1,ip-1),
													stack_i_p_ip_n_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack1, 
													two_multibranch_helix_init_energy, 
													two_unpaired_nuc_in_mbl_energy,
													this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
													this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j)));
		}

		// Other imperfect stacking is by noncanonical pairing of ip+1 and j.
		double stack_ipp_j_in_coax_stack_energy = ZERO;
		double energy_imperfect_coaxial_stack2 = ZERO;

		if(j-1 > ip+2)
		{
			energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);
			stack_ipp_j_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-1, ip+2, ip+1, j);
		}

		//double imperfect_stacking_energy2 = MUL8(V->x(i,ip), 
		//										V->x(ip+2,j-1), 
		//										stack_ipp_j_in_coax_stack_energy, 
		//										energy_imperfect_coaxial_stack2,
		//										two_multibranch_helix_init_energy, 
		//										two_unpaired_nuc_in_mbl_energy,
		//										this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
		//										this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1));

		if(this->energy_loops->folding_constraints->str_coinc_map[ip+1][j] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip+1, j))
		{
			V->x_ext(i,ip) = MAX_SUM(V->x_ext(i, ip), 
										MUL8(this->x_ext(i, j), 
												V->x(ip+2, j-1), 
												stack_ipp_j_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2,
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1)));

			V->x_ext(ip+2, j-1) = MAX_SUM(V->x_ext(ip+2, j-1), 
										MUL8(this->x_ext(i, j), 
												V->x(i, ip), 
												stack_ipp_j_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2,
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1)));
		}
	} // ip loop for enumerating all 
#endif // _TRANS_V_COAX_STACK_2_Wcoax_
}




