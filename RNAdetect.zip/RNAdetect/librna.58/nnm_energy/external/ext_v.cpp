#include <stdio.h>
#include <stdlib.h>
#include "../v.h"
#include "../wl.h"
#include "../w.h"
#include "../wcoax.h"
#include "../wmb.h"
#include "../wout.h"
#include "../energy_array.h"
#include "../energy_loops.h"
#include "../nnm_math.h"
#include "../thermo_parameters.h"
#include "../tb_stack.h"
#include "../min_energy_structure.h"
#include "../stoch_energy_structures.h"
#include "../sampling_math.h"
#include "../nnm_energy_compilation_directives.h"
#include "../../structure/structure.h"
#include "../../structure/folding_constraints.h"
#include "../cli.h"

bool _DUMP_EXT_V_MESSAGES_ = false;

double& t_V::x_ext(int i, int j)
{
	return(this->ext_energy_array->x(i,j));
}

// Go over all computations and 
void t_V::compute_ext_dependencies(int i, int j)
{
	if(!this->energy_loops->folding_constraints->pairing_map[i][j])
	{
		return;
	}

	// Check MIN_LOOP constraint.
	// If the nucleotides are not pairable, do not bother computation, assign infinity to
	// current array value and return.
	if((j-i-1) < MIN_LOOP || 
		!pairable[rna_seq->numseq[i]][rna_seq->numseq[j]])
	{
		//printf("%d and %d are not pairable\n", i,j);
		return;
	}
	else
	{
		//printf("Computing!!!\n");
		//printf("%d and %d are pairable: %c-%c\n", i,j, rna_seq->nucs[i], rna_seq->nucs[j]);
	}

	// Following code is borrowed from pfunction.
	int before = 0;
	if (i>1 && j < rna_seq->numofbases)
	{
		before = pairable[rna_seq->numseq[i-1]][rna_seq->numseq[j+1]];
	}

	int after = 0;
	if((((j-i) > MIN_LOOP + 2)&&(j<=rna_seq->numofbases))&&(i < rna_seq->numofbases)) {
		after = pairable[rna_seq->numseq[i+1]][rna_seq->numseq[j-1]];

	}
	else after = 0;

	//if there are no stackable pairs to i.j then don't allow a pair i,j
	if ((before==0)&&(after==0)) 
	{
		return;
	}

	t_WMB* WMB = this->energy_loops->WMB;
	t_W* W = this->energy_loops->W;
	t_Wcoax* Wcoax = this->energy_loops->Wcoax;

if(_DUMP_EXT_V_MESSAGES_)
{
			printf("---------------------------\n");
			printf("Computing V[ext](%d, %d)\n", i, j);
}

//	// Hairpin.
//	double current_cumulative = ZERO;
//	//double energy_closing_hairpin = ZERO;
//#ifdef _TRANS_HP_LOOP_2_V_
//	if(this->energy_loops->folding_constraints->check_hairpin_loop(i,j))
//	{
//		double energy_closing_hairpin = this->energy_loops->thermo_pars->hairpin_energy(i, j);
//
//		// Make sure the loop is interior to the constrained base pair.
//		current_cumulative = MAX_SUM(current_cumulative, this->energy_loops->thermo_pars->hairpin_energy(i, j));
//
//if(_DUMP_EXT_V_MESSAGES_)
//{
//		printf("---------------------------\n");
//		printf("Hairpin -> V(%d, %d): %.10f\n", i, j, current_cumulative);
//}
//	}
//	else
//	{
//if(_DUMP_EXT_V_MESSAGES_)
//{
//	printf("Forbidden hairpin %d-%d\n", i,j);
//}
//	}
//#endif // _TRANS_HP_LOOP_2_V_

#ifdef _TRANS_V_INT_LOOP_2_V_
	// Internal.
	// Need a double loop for searching for internal loops.
	double energy_closing_interior = ZERO;

	for(int inner_i = i+1; inner_i < j; inner_i++)
	{
		for(int inner_j = j-1; inner_j > inner_i; inner_j--)
		{
			// Exclude the internal loop where loop is just stacking of this base pair on next base pair.
			if(!(inner_i == i+1 && inner_j == j-1))
			{
				int fp_size = abs(i - inner_i) - 1;
				int tp_size = abs(j - inner_j) - 1;
				int size = fp_size + tp_size;

				if(size <= MAX_INT_LOOP_SIZE && 
					(inner_j - inner_i) > MIN_LOOP && 
					this->energy_loops->folding_constraints->pairing_map[inner_i][inner_j])
				{
					if(this->energy_loops->folding_constraints->check_internal_loop(i, j, inner_i, inner_j))
					{
						//current_cumulative = MAX_SUM(current_cumulative, energy_closing_current_interior);
						this->x_ext(inner_i, inner_j) = MAX_SUM(this->x_ext(inner_i, inner_j), 
																MUL(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)), 
																	this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j)));
					} // same loop check for nucleotides in the internal loop.
				} // pairing and max int loop size checks.
			} // Exclude stacked pairs as a consideration for interior loops.
		} // inner_j loop.
	} // inner_i loop.

	// Stacked base pair.
	//current_cumulative = MAX_SUM(current_cumulative, MUL(this->x(i+1, j-1), this->energy_loops->thermo_pars->bp_stack_energy(i,j, j-1, i+1)));
	this->x_ext(i+1, j-1) = MAX_SUM(this->x_ext(i+1, j-1), 
									MUL(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)), this->energy_loops->thermo_pars->bp_stack_energy(i,j, j-1, i+1)));

#endif // _TRANS_V_INT_LOOP_2_V_

	// Multibranch.
	// Consider the stacking on top of closing i-j base pair.
	double multibranch_closing_penalty = this->energy_loops->thermo_pars->MBL_closure_penalty;
	double multibranch_helix_init_energy = this->energy_loops->thermo_pars->per_helix_penalty;
	double two_multibranch_helix_init_energy = MUL(multibranch_helix_init_energy, multibranch_helix_init_energy);
	double unpaired_nuc_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	double two_unpaired_nuc_in_mbl_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_WMB_DANGLE_STACK_2_V_
	// Consider the dangling ends here. i+1 and j-1 can dangle. Consider all 4 cases.
	double i_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(i,j,i+1);
	double j_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(i,j,j-1);
	double ij_dangle_energy = this->energy_loops->thermo_pars->mbl_mismatch_energy(i,j,j-1,i+1);

	// Choose min of 4 cases
	// Add the scaling parameters for closing bp.

	// no dangle
	//current_cumulative = MAX_SUM(current_cumulative, MUL4(this->energy_loops->WMB->x(i+1, j-1),
	//													this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
	//													multibranch_helix_init_energy,
	//													multibranch_closing_penalty));
	WMB->x_ext(i+1, j-1) = MAX_SUM(WMB->x_ext(i+1, j-1), 
									MUL4(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)), 
										this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
										multibranch_helix_init_energy,
										multibranch_closing_penalty));
	
	// i dangle
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1))
	{
		//current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+2, j-1),
		//													i_dangle_energy,
		//													unpaired_nuc_in_mbl_energy,
		//													this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
		//													multibranch_helix_init_energy,
		//													multibranch_closing_penalty));

		WMB->x_ext(i+2, j-1) = MAX_SUM(WMB->x_ext(i+2, j-1), 
			MUL6(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
				i_dangle_energy,
				unpaired_nuc_in_mbl_energy,
				this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
				multibranch_helix_init_energy,
				multibranch_closing_penalty));
	}

	// j dangle
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(j-1))
	{
		//current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+1, j-2),
		//													j_dangle_energy,
		//													unpaired_nuc_in_mbl_energy,
		//													this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
		//													multibranch_helix_init_energy,
		//													multibranch_closing_penalty));
		WMB->x_ext(i+1, j-2) = MAX_SUM(WMB->x_ext(i+1, j-2), MUL6(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
															j_dangle_energy,
															unpaired_nuc_in_mbl_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
															multibranch_helix_init_energy,
															multibranch_closing_penalty));
	}

	// ij mismatch:
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
	{
		//current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+2, j-2),
		//													ij_dangle_energy,
		//													two_unpaired_nuc_in_mbl_energy,
		//													this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
		//													multibranch_helix_init_energy,
		//													multibranch_closing_penalty));
		WMB->x_ext(i+2, j-2) = MAX_SUM(WMB->x_ext(i+2, j-2), MUL6(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
															ij_dangle_energy,
															two_unpaired_nuc_in_mbl_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
															multibranch_helix_init_energy,
															multibranch_closing_penalty));
	}

#endif // _TRANS_WMB_DANGLE_STACK_2_V_

#ifdef _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_
if(_DUMP_EXT_V_MESSAGES_)
	printf("Nonbroken j cases:\n");
	// Add 6 coaxial stacking cases: 3 for breakage between i and ip, 3 for breakage between jp and j.
	for(int ip = i + MIN_LOOP + 1; ip < j - MIN_LOOP; ip++)
	{
		// 1: Perfect stacking between i-j and ip-(j-1).
		double perfect_stacking_energy = ZERO;

		if(ip < j-1 && i+1 < ip-1)
		{
			perfect_stacking_energy = MUL3(this->x(ip,j-1),
											this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(j-1, ip, i, j),
											MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)));

			// Add unpaired nuc and helix init penalties.
			perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-1));
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			perfect_stacking_energy = MUL(perfect_stacking_energy, multibranch_closing_penalty);
			//current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);

			this->x_ext(ip, j-1) = MAX_SUM(this->x_ext(ip, j-1),
				MUL7(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
					this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(j-1, ip, i, j),
					two_multibranch_helix_init_energy,
					this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-1),
					this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
					multibranch_closing_penalty,
					MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1))));

			W->x_ext(i+1, ip-1) = MAX_SUM(W->x_ext(i+1, ip-1),
				MUL7(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
					this->x(ip, j-1),
					this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(j-1, ip, i, j),
					two_multibranch_helix_init_energy,
					this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-1),
					this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
					multibranch_closing_penalty));

			WMB->x_ext(i+1, ip-1) = MAX_SUM(WMB->x_ext(i+1, ip-1),
				MUL7(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
					this->x(ip, j-1),
					this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(j-1, ip, i, j),
					two_multibranch_helix_init_energy,
					this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-1),
					this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
					multibranch_closing_penalty));
		}

		// 2: 
		// This is the energy of stacking of mismatched pair (i+1, j-1) on (i,j)
		double stack_on_ij_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(i, j, j-1, i+1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(j-2, ip, i+1, j-1);

		double imperfect_stacking_energy1 = ZERO;
		if(j-2 > ip && i+2 < ip-1)
		{
			imperfect_stacking_energy1 = MUL4(this->x(ip,j-2), 
												MAX_SUM(W->x(i+2, ip-1), WMB->x(i+2, ip-1)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-2));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, multibranch_closing_penalty);
		}

		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
		{
			//current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy1);
			this->x_ext(ip, j-2) = MAX_SUM(this->x_ext(ip, j-2), 
										MUL9(MAX_SUM(W->x(i+2, ip-1), WMB->x(i+2, ip-1)),
											MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
											stack_on_ij_in_coax_stack_energy, 
											energy_imperfect_coaxial_stack1,
											this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-2),
											this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
											two_multibranch_helix_init_energy, 
											two_unpaired_nuc_in_mbl_energy,
											multibranch_closing_penalty));

			W->x_ext(i+2, ip-1) = MAX_SUM(W->x_ext(i+2, ip-1), 
										MUL9(this->x(ip, j-2),
											MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
											stack_on_ij_in_coax_stack_energy, 
											energy_imperfect_coaxial_stack1,
											two_multibranch_helix_init_energy, 
											two_unpaired_nuc_in_mbl_energy,
											this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-2),
											this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
											multibranch_closing_penalty));

			WMB->x_ext(i+2, ip-1) = MAX_SUM(WMB->x_ext(i+2, ip-1), 
										MUL9(this->x(ip, j-2),
											MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
											stack_on_ij_in_coax_stack_energy, 
											energy_imperfect_coaxial_stack1,
											two_multibranch_helix_init_energy, 
											two_unpaired_nuc_in_mbl_energy,
											this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-2),
											this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
											multibranch_closing_penalty));
		}

		// 3
		// This is the energy of stacking of mismatched pair (ip, j-1) on (ip+1, j-2)                           
		double stack_on_ip_p_j_nn_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-2, ip+1, ip, j-1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(j-1, ip, i, j);

		double imperfect_stacking_energy2 = ZERO;
		if(j-2 > ip+1 && ip-1 > i+1)
		{
			imperfect_stacking_energy2 = MUL(this->x(ip+1,j-2), 
												MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)));
		}

		// Add unpaired nuc and helix init penalties.
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j-2));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, multibranch_closing_penalty);

		if(this->energy_loops->folding_constraints->str_coinc_map[ip][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip, j-1))
		{
			//current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy2);
			this->x_ext(ip+1, j-2) = MAX_SUM(this->x_ext(ip+1, j-2), 
											MUL9(two_multibranch_helix_init_energy, 
												MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)),
												MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j-2),
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
												multibranch_closing_penalty,
												stack_on_ip_p_j_nn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2));

			WMB->x_ext(i+1, ip-1) = MAX_SUM(WMB->x_ext(i+1, ip-1),
											MUL9(two_multibranch_helix_init_energy, 
												this->x(ip+1, j-2),
												MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j-2),
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
												multibranch_closing_penalty,
												stack_on_ip_p_j_nn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2));

			W->x_ext(i+1, ip-1) = MAX_SUM(W->x_ext(i+1, ip-1),
											MUL9(two_multibranch_helix_init_energy, 
												this->x(ip+1, j-2),
												MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j-2),
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
												multibranch_closing_penalty,
												stack_on_ip_p_j_nn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2));
		}

	}
#endif // _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_

#ifdef _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_
if(_DUMP_EXT_V_MESSAGES_)
	printf("Nonbroken i cases:\n");

	// Breakage between j and jp.
	for(int jp = i + MIN_LOOP + 1; jp < j - MIN_LOOP; jp++)
	{
		// 1: Perfect stacking between (i+1, jp) and (i,j).
		double perfect_stacking_energy = ZERO;

		if(i+1 < jp && jp+1 < j-1)
		{
			perfect_stacking_energy = MUL3(this->x(i+1, jp),
											this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(i, j, jp, i+1),
											MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)));

			perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, jp));
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			perfect_stacking_energy = MUL(perfect_stacking_energy, multibranch_closing_penalty);
			//current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);

			this->x_ext(i+1, jp) = MAX_SUM(this->x_ext(i+1, jp), 
											MUL7(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
												this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(i, j, jp, i+1),
												MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)),
												two_multibranch_helix_init_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, jp),
												this->energy_loops->thermo_pars->terminal_pair_penalty(i, j),
												multibranch_closing_penalty));

			W->x_ext(jp+1, j-1) = MAX_SUM(W->x_ext(jp+1, j-1),
											MUL7(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
												this->x(i+1, jp), 
												this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(i, j, jp, i+1),
												two_multibranch_helix_init_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, jp),
												this->energy_loops->thermo_pars->terminal_pair_penalty(i, j),
												multibranch_closing_penalty));

			WMB->x_ext(jp+1, j-1) = MAX_SUM(WMB->x_ext(jp+1, j-1),
											MUL7(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
												this->x(i+1, jp), 
												this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(i, j, jp, i+1),
												two_multibranch_helix_init_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, jp),
												this->energy_loops->thermo_pars->terminal_pair_penalty(i, j),
												multibranch_closing_penalty));
		}

		// 2: Mismatching between
		double stack_on_ij_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(i, j, j-1, i+1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(i+1, j-1, jp, i+2);

		double imperfect_stacking_energy1 = ZERO;

		if(jp > i+2 && j-2 > jp+1)
		{
			imperfect_stacking_energy1 = MUL4(this->x(i+2,jp), 
												MAX_SUM(W->x(jp+1, j-2), WMB->x(jp+1, j-2)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1);


			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, multibranch_closing_penalty);
		}

		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
		{
			//current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy1);
			this->x_ext(i+2, jp) = MAX_SUM(this->x_ext(i+2, jp), 
											MUL9(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)), 
												MAX_SUM(W->x(jp+1, j-2), WMB->x(jp+1, j-2)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1,
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp),
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
												multibranch_closing_penalty));

			W->x_ext(jp+1, j-2) = MAX_SUM(W->x_ext(jp+1, j-2), 
											MUL9(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)), 
												this->x(i+2, jp),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1,
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp),
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
												multibranch_closing_penalty));

			WMB->x_ext(jp+1, j-2) = MAX_SUM(WMB->x_ext(jp+1, j-2), 
												MUL9(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)), 
													this->x(i+2, jp),
													stack_on_ij_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack1,
													two_multibranch_helix_init_energy, 
													two_unpaired_nuc_in_mbl_energy,
													this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp),
													this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
													multibranch_closing_penalty));
		}

		// 3
		// This is the energy of stacking of mismatched pair on (i, ip-1)
		double stack_on_ipjn_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(jp-1, i+2, i+1, jp);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(i, j, jp, i+1);

		double imperfect_stacking_energy2 = ZERO;
		if(i+2 < jp-1 && jp+1 < j-1)
		{
			imperfect_stacking_energy2 = MUL4(this->x(i+2,jp-1), 
												MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)),
												stack_on_ipjn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2);
		}

		// Add unpaired nuc and helix init penalties.
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp-1));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, multibranch_closing_penalty);

		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][jp] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, jp))
		{
			//current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy2);
			this->x_ext(i+2, jp-1) = MAX_SUM(this->x_ext(i+2, jp-1), 
												MUL9(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
													MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)),
													stack_on_ipjn_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack2,
													two_multibranch_helix_init_energy, 
													two_unpaired_nuc_in_mbl_energy,
													this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp-1),
													this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
													multibranch_closing_penalty));

			W->x_ext(jp+1, j-1) = MAX_SUM(W->x_ext(jp+1, j-1), 
												MUL9(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
													this->x(i+2, jp-1),
													stack_on_ipjn_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack2,
													two_multibranch_helix_init_energy, 
													two_unpaired_nuc_in_mbl_energy,
													this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp-1),
													this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
													multibranch_closing_penalty));

			WMB->x_ext(jp+1, j-1) = MAX_SUM(WMB->x_ext(jp+1, j-1), 
												MUL9(MUL(this->energy_loops->bp_prior(i,j), this->x_ext(i,j)),
													this->x(i+2, jp-1),
													stack_on_ipjn_in_coax_stack_energy, 
													energy_imperfect_coaxial_stack2,
													two_multibranch_helix_init_energy, 
													two_unpaired_nuc_in_mbl_energy,
													this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp-1),
													this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
													multibranch_closing_penalty));
		}

	}
	// End of coaxial stacking cases.

#endif // _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_

}
