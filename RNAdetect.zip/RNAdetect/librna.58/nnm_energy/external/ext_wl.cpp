#include <stdio.h>
#include <stdlib.h>
#include "../v.h"
#include "../wl.h"
#include "../w.h"
#include "../wmbl.h"
#include "../wcoax.h"
#include "../energy_array.h"
#include "../energy_loops.h"
#include "../nnm_math.h"
#include "../thermo_parameters.h"
#include "../tb_stack.h"
#include "../sampling_math.h"
#include "../stoch_energy_structures.h"
#include "../../structure/structure.h"
#include "../../structure/folding_constraints.h"

bool _DUMP_EXT_WL_MESSAGES_ = false;

double& t_WL::x_ext(int i, int j)
{
	return(this->ext_energy_array->x(i,j));
}

double& t_WL::x_branchized_ext(int i, int j)
{
	return(this->ext_branchized_energy_array->x(i,j));
}


void t_WL::compute_branchized_ext_dependencies(int i, int j)
{	
	if(!this->energy_loops->folding_constraints->str_coinc_map[i][j])
	{
		return;
	}

	t_V* V = this->energy_loops->V;

	double wl_closed_energy = ZERO;

#ifdef _TRANS_V_DANGLE_STACK_2_WL_branchized_
	// Get dangling and unpaired nucleotide energies.
	double i_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(j,i+1,i);
	double j_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(j-1,i,j);
	double ij_dangle_energy = this->energy_loops->thermo_pars->mbl_mismatch_energy(j-1, i+1, i, j);
	double unpaired_nuc_in_MBL_energy = (this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);
	double two_unpaired_nuc_in_MBL_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);
	double new_helix_penalty = (this->energy_loops->thermo_pars->per_helix_penalty);	

	// Choose minimum energy case.
	//wl_closed_energy = MUL(V->x(i,j), MUL(new_helix_penalty, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j)));
	V->x_ext(i,j) = MAX_SUM(V->x_ext(i,j), 
							MUL3(this->x_branchized_ext(i,j), 
								new_helix_penalty, 
								this->energy_loops->thermo_pars->terminal_pair_penalty(i,j)));

	// Do not handle the dangling/stacking of forced base pair.
	if(i+1 < j)
	{
		if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
		{
			//wl_closed_energy = MAX_SUM(wl_closed_energy, MUL5(V->x(i+1,j), i_dangle_energy, unpaired_nuc_in_MBL_energy, new_helix_penalty, this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,j))); // 5' dangle.
			V->x_ext(i+1,j) = MAX_SUM(V->x_ext(i+1,j), 
									MUL5(this->x_branchized_ext(i,j), 
										unpaired_nuc_in_MBL_energy,
										new_helix_penalty, 
										i_dangle_energy,
										this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,j)));
		}

		if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
		{
			//wl_closed_energy = MAX_SUM(wl_closed_energy, MUL5(V->x(i,j-1), j_dangle_energy, unpaired_nuc_in_MBL_energy, new_helix_penalty, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j-1))); // 3' dangle.
			V->x_ext(i,j-1) = MAX_SUM(V->x_ext(i,j-1), 
									MUL5(this->x_branchized_ext(i,j), 
										unpaired_nuc_in_MBL_energy,
										new_helix_penalty, 
										j_dangle_energy,
										this->energy_loops->thermo_pars->terminal_pair_penalty(i,j-1)));
		}
	}

	if(i+1 < j-1)
	{
		if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i, j))
		{
			//wl_closed_energy = MAX_SUM(wl_closed_energy, MUL5(V->x(i+1,j-1), ij_dangle_energy, two_unpaired_nuc_in_MBL_energy, new_helix_penalty, this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,j-1)));
			V->x_ext(i+1,j-1) = MAX_SUM(V->x_ext(i+1,j-1), 
									MUL5(this->x_branchized_ext(i,j), 
										two_unpaired_nuc_in_MBL_energy,
										new_helix_penalty, 
										ij_dangle_energy,
										this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,j-1)));


		}
	}
#endif // _TRANS_V_DANGLE_STACK_2_WL_branchized_
}

void t_WL::compute_ext_dependencies(int i, int j)
{
	if(!this->energy_loops->folding_constraints->str_coinc_map[i][j])
	{
		return;
	}

	t_V* V = this->energy_loops->V;

	// Get dangling and unpaired nucleotide energies.
	double i_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(j,i+1,i);
	double j_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(j-1,i,j);
	//double ij_dangle_energy = MUL(this->energy_loops->thermo_pars->dangle_fp_energy(i+1,j-1,i), this->energy_loops->thermo_pars->dangle_tp_energy(i+1,j-1,j));
	double ij_dangle_energy = this->energy_loops->thermo_pars->mbl_mismatch_energy(j-1, i+1, i, j);
	double unpaired_nuc_in_MBL_energy = (this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);
	double two_unpaired_nuc_in_MBL_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);
	double new_helix_penalty = (this->energy_loops->thermo_pars->per_helix_penalty);

	// Choose minimum energy case.
#ifdef _TRANS_WL_branchized_2_WL_
	//this->x(i, j) = this->x_branchized(i, j);
	this->x_branchized_ext(i, j) = MAX_SUM(this->x_branchized_ext(i, j), this->x_ext(i,j));
#endif // _TRANS_WL_branchized_WL_

#ifdef _TRANS_WL_5p_EXT_2_WL_
	//this->x(i, j) = MAX_SUM(this->x(i, j), MUL(this->x(i+1,j), unpaired_nuc_in_MBL_energy)); // The left extension is handled here.
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(i))
	{
		this->x_ext(i+1, j) = MAX_SUM(this->x_ext(i+1, j), 
										MUL(this->x_ext(i,j), 
											unpaired_nuc_in_MBL_energy));
	}
#endif // _TRANS_WL_5p_EXT_WL_
}

