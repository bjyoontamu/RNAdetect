#include <stdio.h>
#include <stdlib.h>
#include "../v.h"
#include "../wl.h"
#include "../w.h"
#include "../energy_array.h"
#include "../energy_loops.h"
#include "../nnm_math.h"
#include "../thermo_parameters.h"
#include "../tb_stack.h"
#include "../sampling_math.h"

#include "../../structure/structure.h"
#include "../../structure/folding_constraints.h"

double& t_W::x_ext(int i, int j)
{
	return(this->ext_energy_array->x(i,j));
}

void t_W::compute_ext_dependencies(int i, int j)
{	
	if(!this->energy_loops->folding_constraints->str_coinc_map[i][j])
	{
		return;
	}

	t_WL* WL = this->energy_loops->WL;

	// Get dangling and unpaired nucleotide energies.
	double unpaired_nuc_in_MBL_energy = (this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

	// Choose minimum energy case.
#ifdef _TRANS_WL_2_W_
	//this->x(i, j) = WL->x(i,j);
	WL->x_ext(i,j) = MAX_SUM(WL->x_ext(i,j), MUL(this->x_ext(i,j), this->energy_loops->w_coinc_prior(i,j)));
	//WL->x_ext(i,j) = MAX_SUM(WL->x_ext(i,j), this->x_ext(i,j));
#endif // _TRANS_WL_2_W_

#ifdef _TRANS_W_3p_EXT_2_W_
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
	{
		//this->x(i, j) = MAX_SUM(this->x(i, j), MUL(this->x(i, j-1), unpaired_nuc_in_MBL_energy));
		this->x_ext(i,j-1) = MAX_SUM(this->x_ext(i,j-1), MUL(unpaired_nuc_in_MBL_energy, MUL(this->x_ext(i,j), this->energy_loops->w_coinc_prior(i,j))));
	}
#endif // _TRANS_W_3p_EXT_2_W_
} // t_W::compute

