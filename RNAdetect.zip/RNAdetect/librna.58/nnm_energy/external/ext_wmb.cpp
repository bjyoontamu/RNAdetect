#include <stdio.h>
#include <stdlib.h>
#include "../v.h"
#include "../wl.h"
#include "../wmbl.h"
#include "../wout.h"
#include "../wmb.h"
#include "../wcoax.h"
#include "../energy_array.h"
#include "../energy_loops.h"
#include "../thermo_parameters.h"
#include "../nnm_math.h"
#include "../../structure/structure.h"
#include "../../structure/folding_constraints.h"
#include "../tb_stack.h"
#include "../sampling_math.h"

bool _DUMP_EXT_WMB_MESSAGES_ = false;

double& t_WMB::x_ext(int i, int j)
{
	return(this->ext_energy_array->x(i,j));
}

void t_WMB::compute_ext_dependencies(int i, int j)
{	
	if(!this->energy_loops->folding_constraints->str_coinc_map[i][j])
	{
		return;
	}

	t_WMBL* WMBL = this->energy_loops->WMBL;

	// j extension energy in mbl array.
	double unpaired_j_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;

	// WMB branching loop.
	// Extend on 3' side, ie on j.
#ifdef _TRANS_WMBL_2_WMB_
	//WMBL->x_ext(i,j) = MAX_SUM(WMBL->x_ext(i,j), this->x_ext(i,j));
	WMBL->x_ext(i,j) = MAX_SUM(WMBL->x_ext(i,j), MUL(this->energy_loops->wmb_coinc_prior(i,j), this->x_ext(i,j)));
#endif // _TRANS_WMBL_WMB_

#ifdef _TRANS_WMB_5p_EXT_2_WMB_
	// Extend.
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
	{
		//this->x(i,j) = MAX_SUM(this->x(i,j), MUL(this->x(i,j-1), unpaired_j_in_mbl_energy));
		this->x_ext(i,j-1) = MAX_SUM(this->x_ext(i,j-1), MUL(
																MUL(this->energy_loops->wmb_coinc_prior(i,j), this->x_ext(i,j)), 
																unpaired_j_in_mbl_energy)
															);
	}
#endif // _TRANS_WMB_5p_EXT_WMB_
} // t_WMB::compute




