#ifndef _CLI_
#define _CLI_

enum{MODE_MAP, MODE_PP, MODE_PPSTRCOINC, MODE_SAMPLE};

#define DEFAULT_PP_OP_FP "pp"
#define DEFAULT_STR_COINC_OP_FP "str_coinc"
#define DEFAULT_FORCED_BPP_THRESHOLD (1.0f)

class t_structure;

class t_cli
{
public:
	t_cli(int argc, char* argv[]);
	t_cli(char* seq_fp, int _mode);
	t_cli(t_structure* _rna_seq, int _mode);
	t_cli(t_cli* _cli); // Copy constructor.
	~t_cli();

	t_structure* rna_seq;

	int mode;
	//char* seq_fp; // File path to the sequence.
	char* seq_id; // This is the id of sequence.

	char* str_coinc_op_fp;
	char* pp_op_fp;

	bool array_io_read; // Read arrays from a previous computation?
	bool array_io_write; // Dump arrays after computing?

	int n_max_separation;

	double str_coinc_pp_threshold;

	int n_samples;

	char* SHAPE_fp;
};

#endif // _CLI_


