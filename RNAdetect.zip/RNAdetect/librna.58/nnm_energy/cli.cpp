#include "cli.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../structure/structure.h"
#include "../utils/ansi_string/ansi_string.h"

t_cli::t_cli(char* _seq_fp, int _mode)
{
	// Copy sequence file path.
	this->rna_seq = new t_structure(_seq_fp);

	this->n_max_separation = 0x1ffffff;
	this->str_coinc_pp_threshold = DEFAULT_FORCED_BPP_THRESHOLD;

	this->seq_id = (char*)malloc(sizeof(char) * (strlen(this->rna_seq->ctlabel) + 2));
	strcpy(this->seq_id, this->rna_seq->ctlabel);

	this->SHAPE_fp = NULL;
	this->pp_op_fp = NULL;
	this->str_coinc_op_fp = NULL;

	// Set the mode.
	this->mode = _mode;

	this->array_io_read = false;
	this->array_io_write = false; 
}

t_cli::t_cli(t_cli* _cli)
{
	// Copy sequence file path.
	this->rna_seq = new t_structure(_cli->rna_seq);

	this->n_max_separation = _cli->n_max_separation;
	this->str_coinc_pp_threshold = _cli->str_coinc_pp_threshold;

	this->seq_id = (char*)malloc(sizeof(char) * (strlen(this->rna_seq->ctlabel) + 2));
	strcpy(this->seq_id, this->rna_seq->ctlabel);

	if(_cli->SHAPE_fp != NULL)
	{
		this->SHAPE_fp = (char*)malloc(sizeof(char) * (strlen(_cli->SHAPE_fp) + 2));
		strcpy(this->SHAPE_fp, _cli->SHAPE_fp);
	}
	else
	{
		this->SHAPE_fp = NULL;
	}

	if(_cli->pp_op_fp != NULL)
	{
		this->pp_op_fp = (char*)malloc(sizeof(char) * (strlen(_cli->pp_op_fp) + 2));
		strcpy(this->pp_op_fp, _cli->pp_op_fp);	
	}
	else
	{
		this->pp_op_fp = NULL;
	}

	if(_cli->str_coinc_op_fp != NULL)
	{
		this->str_coinc_op_fp = (char*)malloc(sizeof(char) * (strlen(_cli->str_coinc_op_fp) + 2));
		strcpy(this->str_coinc_op_fp, _cli->str_coinc_op_fp);	
	}
	else
	{	
		this->str_coinc_op_fp = NULL;
	}

	// Set the mode.
	this->mode = _cli->mode;

	// Copy n samples.
	this->n_samples = _cli->n_samples;

	this->array_io_read = _cli->array_io_read;
	this->array_io_write = _cli->array_io_write; 
}

t_cli::t_cli(t_structure* _rna_seq, int _mode)
{
	this->rna_seq = new t_structure(_rna_seq);
	this->mode = _mode;
	this->n_max_separation = 0x1ffffff;
	this->str_coinc_pp_threshold = DEFAULT_FORCED_BPP_THRESHOLD;

	this->SHAPE_fp = NULL;
	this->pp_op_fp = NULL;
	this->str_coinc_op_fp = NULL;

	this->seq_id = (char*)malloc(sizeof(char) * (strlen(_rna_seq->ctlabel) + 2));
	strcpy(this->seq_id, _rna_seq->ctlabel);

	this->array_io_read = false;
	this->array_io_write = false; 
}

// Automatic parsing of the command line interfaces to use partition function with a command line interface.
// This function defines a calling interface for the program.
t_cli::t_cli(int argc, char* argv[])
{
	if(argc < 3)
	{
		printf("USAGE: [exec] [sequence file path] [-map/-pp/-ppstrcoinc/-sample] \n \
								-nsamp [# of samples for sampling] \n\
								-nmaxsep [max separation]\n\
								-io_ip [Read arrays from a previous computation]\n \
								-io_op [Write arrays for a later computation]\n\
								-pp_op_fp [pp file op path]\n\
								-str_coinc_op_fp [str. coinc. op path]\n\
								-SHAPE_fp [SHAPE data file path for sequence]\n");
		exit(0);
	}

	// Copy sequence file path.
	this->rna_seq = new t_structure(argv[1]);

	this->n_max_separation = 0x1ffffff;
	this->str_coinc_pp_threshold = DEFAULT_FORCED_BPP_THRESHOLD;

	// By default, do nor read or write any files.
	this->array_io_read = false;
	this->array_io_write = false; 

	this->SHAPE_fp = NULL;
	this->pp_op_fp = NULL;
	this->str_coinc_op_fp = NULL;

	this->seq_id = (char*)malloc(sizeof(char) * (strlen(this->rna_seq->ctlabel) + 2));
	strcpy(this->seq_id, this->rna_seq->ctlabel);

	if(strcmp(argv[2], "-map") == 0)
	{
		this->mode = MODE_MAP;
	}
	else if(strcmp(argv[2], "-pp") == 0)
	{
		this->mode = MODE_PP;
	}
	else if(strcmp(argv[2], "-ppstrcoinc") == 0)
	{
		this->mode = MODE_PPSTRCOINC;
	}
	else if(strcmp(argv[2], "-sample") == 0)
	{
		this->mode = MODE_SAMPLE;
	}
	else
	{
		printf("Could not understand the option %s.\n", argv[2]);
		exit(0);
	}

	// Go over optional arguments
	this->n_samples = 1; // 1 sample by default.
	int i_arg = 3;
	while(i_arg < argc)
	{
		// Read number of samples.
		if(strcmp(argv[i_arg], "-nsamp") == 0)
		{
			i_arg++;
			if(i_arg < argc)
			{
				this->n_samples = atoi(argv[i_arg]);
				printf("Read n_samp = %d\n", n_samples);
			}
			else
			{
				printf("Enter a number after -nsamp option to specify number of samples.");
			}

			// Jump over number of samples argument.
			i_arg++;
		}
		// Read number of samples.
		else if(strcmp(argv[i_arg], "-nmaxsep") == 0)
		{
			i_arg++;
			if(i_arg < argc)
			{
				this->n_max_separation = atoi(argv[i_arg]);
				printf("Read n_max_separation = %d\n", n_max_separation);
			}
			else
			{
				printf("Enter a number after -nmaxsep option to specify number of samples.");
				i_arg++;
			}

			// Jump over number of samples argument.
			i_arg++;
		}
		else if(strcmp(argv[i_arg], "-SHAPE_fp") == 0)
		{
			i_arg++;
			this->SHAPE_fp = (char*)malloc(sizeof(char) * (strlen(argv[i_arg])));
			strcpy(this->SHAPE_fp, argv[i_arg]);
			printf("Found SHAPE data file argument %s\n", this->SHAPE_fp);
			i_arg++;
		}
		else if(strcmp(argv[i_arg], "-pp_threshold") == 0)
		{
			i_arg++;
			this->str_coinc_pp_threshold = atof(argv[i_arg]);
			if(this->str_coinc_pp_threshold <= 0.50f)
			{
				this->str_coinc_pp_threshold = 0.51f;
			}
			else
			{
				printf("Resetting pp threshold to %lf (Input threshold is < 0.50f)\n", this->str_coinc_pp_threshold);
			}
			i_arg++;
		}
		else if(strcmp(argv[i_arg], "-io_op") == 0)
		{
			this->array_io_write = true;
			i_arg++;
		}
		else if(strcmp(argv[i_arg], "-io_ip") == 0)
		{
			this->array_io_read = true;
			i_arg++;
		}
		else if(strcmp(argv[i_arg], "-pp_op_fp") == 0)
		{
			i_arg++;
			this->pp_op_fp = (char*)malloc(sizeof(char) * (strlen(argv[i_arg]) + 2));
			strcpy(this->pp_op_fp, argv[i_arg]);

			i_arg++;
		}
		else if(strcmp(argv[i_arg], "-str_coinc_op_fp") == 0)
		{
			i_arg++;
			this->str_coinc_op_fp = (char*)malloc(sizeof(char) * (strlen(argv[i_arg]) + 2));
			strcpy(this->str_coinc_op_fp, argv[i_arg]);
			i_arg++;
		}
		else
		{
			printf("found argument: %s\n", argv[i_arg]);
		}
	}

	if(this->pp_op_fp == NULL)
	{
		this->pp_op_fp = (char*)malloc(sizeof(char) * (strlen(DEFAULT_PP_OP_FP) + 2));
		strcpy(this->pp_op_fp, DEFAULT_PP_OP_FP);
	}

	if(this->str_coinc_op_fp == NULL)
	{
		this->str_coinc_op_fp = (char*)malloc(sizeof(char) * (strlen(DEFAULT_STR_COINC_OP_FP) + 2));
		strcpy(this->str_coinc_op_fp, DEFAULT_STR_COINC_OP_FP);
	}
}

t_cli::~t_cli()
{
	// 	char* seq_id; // This is the id of sequence.
	if(this->seq_id != NULL)
	{
		free(this->seq_id);
	}

	//t_structure* rna_seq;
	delete(this->rna_seq);

	// char* str_coinc_op_fp;
	if(this->str_coinc_op_fp != NULL)
	{
		free(this->str_coinc_op_fp);
	}
	
	//char* pp_op_fp;
	if(this->pp_op_fp != NULL)
	{
		free(this->pp_op_fp);
	}

	if(this->SHAPE_fp != NULL)
	{
		free(this->SHAPE_fp);
	}
}

