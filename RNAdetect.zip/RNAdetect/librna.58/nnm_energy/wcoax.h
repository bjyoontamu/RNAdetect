#ifndef _WCOAX_
#define _WCOAX_

class t_structure;
class t_energy_array;
class t_energy_loops;

// V: The class that stores the minimum free energy structure of a sequences where the structure is closed by a base pair
class t_Wcoax
{
public:
	t_Wcoax(t_energy_loops* _energy_loops);
	~t_Wcoax();

	// This is the energy storage.
	t_energy_array* energy_array;
	t_energy_array* ext_energy_array;

	// RNA sequence.
	t_structure* rna_seq;

	// Minimum energy loops that this V array belongs to.
	// By gaining access to this class, V has access to all other arrays.
	t_energy_loops* energy_loops;

	double (*MAX_SUM)(double,double);

	// Compute V for a subsequence.
	void compute(int i, int j);
	void compute_ext_dependencies(int i, int j);

	// Accession function.
	double& x(int i, int j);
	double& x_ext(int i, int j);

	// Backtracking functions.
	void min_energy_tb(int i, int j);
	void stoch_energy_tb(int i, int j);
};

#endif // _WCOAX_


