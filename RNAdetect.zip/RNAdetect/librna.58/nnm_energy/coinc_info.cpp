#include <stdio.h>
#include <stdlib.h>
#include "coinc_info.h"
#include "../utils/xmath/matrix/matrix.h"
#include "../structure/structure.h"
#include "energy_loops.h"

#include "v.h"
#include "wl.h"
#include "w.h"
#include "wmbl.h"
#include "wmb.h"
#include "wcoax.h"
#include "wout.h"

t_coinc_info::t_coinc_info(t_energy_loops* _energy_loops)
{
	this->energy_loops = _energy_loops;

	this->v_coinc_info = new t_matrix(this->energy_loops->rna_seq->numofbases, energy_loops->rna_seq->numofbases, true);
	//this->wl_coinc_info = new t_matrix(this->energy_loops->rna_seq->numofbases, energy_loops->rna_seq->numofbases, false);
	this->wl_coinc_info = NULL;

	//this->branchized_v_coinc_info = new t_matrix(this->energy_loops->rna_seq->numofbases, energy_loops->rna_seq->numofbases, false);
	this->branchized_v_coinc_info = NULL;

	//this->w_coinc_info = new t_matrix(this->energy_loops->rna_seq->numofbases, energy_loops->rna_seq->numofbases, true);
	//this->wmb_coinc_info = new t_matrix(this->energy_loops->rna_seq->numofbases, energy_loops->rna_seq->numofbases, true);	
	this->w_coinc_info = NULL;
	this->wmb_coinc_info = NULL;

	//this->wmbl_coinc_info = new t_matrix(this->energy_loops->rna_seq->numofbases, energy_loops->rna_seq->numofbases, false);
	this->wmbl_coinc_info = NULL;

	//this->wout_coinc_info = new t_matrix(this->energy_loops->rna_seq->numofbases, energy_loops->rna_seq->numofbases, false);
	this->wout_coinc_info = NULL;
}

t_coinc_info::t_coinc_info(t_structure* _rna_seq)
{
	this->energy_loops = NULL;

	this->v_coinc_info = new t_matrix(_rna_seq->numofbases, _rna_seq->numofbases, true);
	//this->wl_coinc_info = new t_matrix(_rna_seq->numofbases, _rna_seq->numofbases, false);
	this->wl_coinc_info = NULL;

	//this->branchized_v_coinc_info = new t_matrix(_rna_seq->numofbases, _rna_seq->numofbases, false);
	this->branchized_v_coinc_info = NULL;

	//this->w_coinc_info = new t_matrix(_rna_seq->numofbases, _rna_seq->numofbases, true);
	//this->wmb_coinc_info = new t_matrix(_rna_seq->numofbases, _rna_seq->numofbases, true);
	this->w_coinc_info = NULL;
	this->wmb_coinc_info = NULL;

	//this->wmbl_coinc_info = new t_matrix(_rna_seq->numofbases, _rna_seq->numofbases, false);
	this->wmbl_coinc_info = NULL;

	//this->wout_coinc_info = new t_matrix(_rna_seq->numofbases, _rna_seq->numofbases, false);
	this->wout_coinc_info = NULL;
}

// Copy the coincidence information.
t_coinc_info::t_coinc_info(t_coinc_info* _coinc_info)
{
	this->energy_loops = _coinc_info->energy_loops;

	this->v_coinc_info = new t_matrix(_coinc_info->v_coinc_info);
	//this->wl_coinc_info = new t_matrix(_coinc_info->wl_coinc_info);
	this->wl_coinc_info = NULL;

	//this->branchized_v_coinc_info = new t_matrix(_coinc_info->branchized_v_coinc_info);
	this->branchized_v_coinc_info = NULL;

	//this->w_coinc_info = new t_matrix(_coinc_info->w_coinc_info);
	//this->wmb_coinc_info = new t_matrix(_coinc_info->wmb_coinc_info);
	this->w_coinc_info = NULL;
	this->wmb_coinc_info = NULL;

	//this->wmbl_coinc_info = new t_matrix(_coinc_info->wmbl_coinc_info);
	this->wmbl_coinc_info = NULL;
	//this->wout_coinc_info = new t_matrix(_coinc_info->wout_coinc_info);
	this->wout_coinc_info = NULL;
}

t_coinc_info::~t_coinc_info()
{
	if(this->v_coinc_info != NULL)
	{
		delete(this->v_coinc_info);
	}

	if(this->wl_coinc_info != NULL)
	{
		delete(this->wl_coinc_info);
	}

	if(this->branchized_v_coinc_info != NULL)
	{
		delete(this->branchized_v_coinc_info);
	}

	if(this->w_coinc_info != NULL)
	{
		delete(this->w_coinc_info);
	}

	if(this->wmb_coinc_info != NULL)
	{
		delete(this->wmb_coinc_info);
	}

	if(this->wmbl_coinc_info != NULL)
	{
		delete(this->wmbl_coinc_info);
	}

	if(this->wout_coinc_info != NULL)
	{
		delete(this->wout_coinc_info);
	}
}

