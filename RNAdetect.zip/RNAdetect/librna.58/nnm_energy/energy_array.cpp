#include <stdio.h>
#include <stdlib.h>
#include "energy_array.h"
#include "../structure/structure.h"
#include "nnm_math.h"

t_energy_array::t_energy_array(t_structure* _rna_seq)
{
	this->rna_seq = _rna_seq;
	
	this->mem_usage = 0.0f;

	// Allocate energy array.
	this->energy_array = (double**)malloc(sizeof(double*) * (rna_seq->numofbases + 3));
	this->mem_usage += sizeof(double*) * (rna_seq->numofbases + 3);
	for(int i = 0; i <= rna_seq->numofbases; i++)
	{
		this->energy_array[i] = (double*)malloc(sizeof(double) * (rna_seq->numofbases + 3 - i));
		this->mem_usage += sizeof(double) * (rna_seq->numofbases + 3 - i);
		this->energy_array[i] -= i; // Translate to access this array with sequence indices.

		for(int j = i; j <= rna_seq->numofbases; j++)
		{
			// The energy of any subsequence is set to 0, i.e., negative infinity.
			this->energy_array[i][j] = ZERO;
		}
	}
}

t_energy_array::~t_energy_array()
{
	// Free energy array
	//this->energy_array = (double**)malloc(sizeof(double*) * (rna_seq->numofbases + 3));
	for(int i = 0; i <= rna_seq->numofbases; i++)
	{
		//this->energy_array[i] = (double*)malloc(sizeof(double) * (rna_seq->numofbases + 3 - i));
		this->energy_array[i] += i; // Translate to access this array with sequence indices.
		free(this->energy_array[i]);
	}
	free(this->energy_array);
}

//double& t_energy_array::x(int i, int j)
//{
//	//if(i > j)
//	//{
//	//	double* p = NULL;
//	//	*p = 1;
//	//	printf("Problematic indices in accession to arrays (%d, %d) @ %s(%d)\n", i,j, __FILE__, __LINE__);
//	//	exit(0);
//	//}
//
//	//if(i > this->rna_seq->numofbases || i == 0 || j > this->rna_seq->numofbases || j == 0)
//	//{
//	//	double* p = NULL;
//	//	*p = 1;
//	//	printf("Problematic indices in accession to arrays (%d, %d) @ %s(%d)\n", i,j, __FILE__, __LINE__);
//	//	exit(0);
//
//	//}
//	return(this->energy_array[i][j]);
//}


