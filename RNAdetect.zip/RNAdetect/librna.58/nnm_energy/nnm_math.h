#ifndef _NNM_MATH_
#define _NNM_MATH_

#include "nnm_energy_compilation_directives.h"

#ifdef _LINEAR_NNM_COMPUTATIONS_
#include "math.h"
#include "../utils/xmath/linear/linear_math.h"

#define INFINITI (4294967296.0f)
#define ZERO (0.0f)
// Define log maths, linear maths??
// Defining macros in any case where I might want to go into log space for some reason in future.
//#define SUM(x,y) ((x == INFINITY || y == INFINITY) ? INFINITY : (x + y))
//#define SUM3(x,y,z) ((x == INFINITY || y == INFINITY || z == INFINITY) ? INFINITY : (x + y + z))
//#define SUM4(x,y,z,k) ((x == INFINITY || y == INFINITY || z == INFINITY || k == INFINITY) ? INFINITY : (x + y + z + k))
//#define SUM5(x,y,z,k,l) ((x == INFINITY || y == INFINITY || z == INFINITY || k == INFINITY || l == INFINITY) ? INFINITY : (x + y + z + k + l))
//#define SUM6(x,y,z,k,l,m) ((x == INFINITY || y == INFINITY || z == INFINITY || k == INFINITY || l == INFINITY || m == INFINITY) ? INFINITY : (x + y + z + k + l + m))
//#define MUL(x,y) ((x == INFINITY || y == INFINITY) ? INFINITY : (x * y))
//#define MUL3(x,y,z) ((x == INFINITY || y == INFINITY || z == INFINITY) ? INFINITY : (x * y * z))
//#define MUL4(x,y,z,k) ((x == INFINITY || y == INFINITY || z == INFINITY || k == INFINITY) ? INFINITY : (x * y * z * k))
//#define DIV(x,y) ((x == INFINITY) ? INFINITY : (x / y))
//#define SUB(x,y) ((x == INFINITY) ? INFINIFITY : ((y == INFINITY) ? -1 * INFINITY : (x - y)))

#define SUM(x,y) ((x + y))
#define SUM3(x,y,z) ((x + y + z))
#define SUM4(x,y,z,k) ((x + y + z + k))
#define SUM5(x,y,z,k,l) ((x + y + z + k + l))
#define SUM6(x,y,z,k,l,m) ((x + y + z + k + l + m))
#define SUM7(x,y,z,k,l,m,n) (SUM(SUM6(x,y,z,k,l,m),n))
#define SUM8(x,y,z,k,l,m,n,a) (SUM(SUM7(x,y,z,k,l,m,n),a))
#define SUM9(x,y,z,k,l,m,n,a,b) (SUM(SUM8(x,y,z,k,l,m,n,a),b))
#define SUM10(x,y,z,k,l,m,n,a,b,c) (SUM(SUM9(x,y,z,k,l,m,n,a,b),c))
#define MUL(x,y) ((x * y))
#define MUL3(x,y,z) ((x * y * z))
#define MUL4(x,y,z,k) ((x * y * z * k))
#define MUL5(x,y,z,k,l) (MUL(MUL4(x,y,z,k),l))
#define MUL6(x,y,z,k,l,m) (MUL(MUL5(x,y,z,k,l),m))
#define MUL7(x,y,z,k,l,m,n) (MUL(MUL6(x,y,z,k,l,m),n))
#define MUL8(x,y,z,k,l,m,n,a) (MUL(MUL7(x,y,z,k,l,m,n),a))
#define MUL9(x,y,z,k,l,m,n,a,b) (MUL(MUL8(x,y,z,k,l,m,n,a),b))
#define MUL10(x,y,z,k,l,m,n,a,b,c) (MUL(MUL9(x,y,z,k,l,m,n,a,b),c))
#define DIV(x,y) ((x / y))
#define SUB(x,y) ((x - y))

#define COMPARE(x,y) (lin_compare(x,y))
#define GEQ(x,y) (lin_geq(x,y))
#define GT(x,y) (lin_gt(x,y))
#define POW(x,y) (lin_pow(x, y))

#define CONVERT_FROM_LIN(x) (x)
#define CONVERT_FROM_LOG(x) (exp(x))
#define CONVERT_TO_LOG(x) (log(x))
#define CONVERT_TO_LIN(x) (x)

#define COMP_PREC() (get_linear_comp_prec())

#endif

#ifdef _LOG_NNM_COMPUTATIONS_
#include "../utils/xmath/log/xlog_math.h"
#define INFINITI (4294967296.0f)
#define ZERO (xlog(0.0f))

// Define log maths, linear maths??
// Defining macros in any case where I might want to go into log space for some reason in future.
#define SUM(x,y) (xlog_sum(x,y))
#define SUM3(x,y,z) (xlog_sum(SUM(x,y),z))
#define SUM4(x,y,z,k) (xlog_sum(SUM3(x,y,z),k))
#define SUM5(x,y,z,k,l) (xlog_sum(SUM4(x,y,z,k),l))
#define SUM6(x,y,z,k,l,m) (xlog_sum(SUM5(x,y,z,k,l),m))
#define SUM7(x,y,z,k,l,m,n) (xlog_sum(SUM6(x,y,z,k,l,m),n))
#define SUM8(x,y,z,k,l,m,n,a) (xlog_sum(SUM7(x,y,z,k,l,m,n),a))
#define SUM9(x,y,z,k,l,m,n,a,b) (xlog_sum(SUM8(x,y,z,k,l,m,n,a),b))
#define SUM10(x,y,z,k,l,m,n,a,b,c) (xlog_sum(SUM9(x,y,z,k,l,m,n,a,a,b),c))
#define MUL(x,y) (xlog_mul(x,y))
#define MUL3(x,y,z) (MUL(MUL(x,y), z))
#define MUL4(x,y,z,k) (MUL(MUL3(x,y,z), k))
#define MUL5(x,y,z,k,l) (MUL(MUL3(x,y,z), MUL(k,l)))
#define MUL6(x,y,z,k,l,m) (MUL(MUL3(x,y,z), MUL3(k,l,m)))
#define MUL7(x,y,z,k,l,m,n) (MUL(MUL3(x,y,z), MUL4(k,l,m,n)))
#define MUL8(x,y,z,k,l,m,n,a) (MUL(MUL7(x,y,z,k,l,m,n),a))
#define MUL9(x,y,z,k,l,m,n,a,b) (MUL(MUL8(x,y,z,k,l,m,n,a),b))
#define MUL10(x,y,z,k,l,m,n,a,b,c) (MUL(MUL9(x,y,z,k,l,m,n,a,a,b),c))
#define DIV(x,y) (xlog_div(x,y))
#define SUB(x,y) (xlog_sub(x,y))
#define COMPARE(x,y) (xlog_comp(x,y))
#define GEQ(x,y) (xlog_geq(x,y))
#define GT(x,y) (xlog_gt(x,y))
#define POW(x,y) (xlog_pow(x,y))

#define CONVERT_FROM_LIN(x) (xlog(x))
#define CONVERT_FROM_LOG(x) (x)
#define CONVERT_TO_LOG(x) (x)
#define CONVERT_TO_LIN(x) (xexp(x))	

#define COMP_PREC() (get_xlog_comp_prec())

#endif

#endif // _NNM_MATH_



