#ifndef _SAMPLING_MATH_
#define _SAMPLING_MATH_

#include <vector>
//#include <iostream>

using namespace::std;

class t_rng;

/*
t_sampling_math: encapsulates t_rng, nothing else also handles the domain conversion for the randomly generated number
in random_double_1_0() function used in sampling.
*/
class t_sampling_math
{
public:
	t_sampling_math();
	~t_sampling_math();

	// ran3 random number generator based on numerical recipes book.
	t_rng* prn_gen; 

	// Return a double in (0, 1].
	double random_double_exc_0_inc_1();
};


#endif // _SAMPLING_MATH_



