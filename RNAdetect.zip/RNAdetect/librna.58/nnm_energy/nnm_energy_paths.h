#ifndef _NNM_ENERGY_PATHS_
#define _NNM_ENERGY_PATHS_

#define STOCH_SAMPLES_DIR "stoch_samples"
#define MIN_ENERGY_STRS_DIR "min_energy_strs"

#define THERMO_PARS_DIR "."

#define SVG_OP_DIR "svgs"

#endif // _NNM_ENERGY_PATHS_



