#ifndef _THERMO_PARAMETERS_
#define _THERMO_PARAMETERS_

#include <vector>

using namespace std;

class t_structure;

// It is extremely important to make sure that units are in consistency!
// exp(-DeltaG/RT) should be unitless!
#define GAS_CONST (1.987213 * 0.001) //gas constant in Kcal/mol
#define TEMP (310.15) // In kelvins
#define NEG_OVER_RT ((-1.0f) / (GAS_CONST * TEMP)) // Unitless

#define DEFAULT_SHAPE_SLOPE (2.6f)
#define DEFAULT_SHAPE_INTERCEPT (-0.8f)

// Scaling constants for scaling in linear computations.
enum{INTERIOR_LOOP, BULGE_LOOP, HAIRPIN_LOOP};
enum{BASE_X, BASE_A, BASE_C, BASE_G, BASE_U, BASE_I};

// Following is for indexing 2x2 internal loop energy parameters. (read from int22.dat)
// These are for indexing the mismatched pairs on both sides.
// The indexing of closing pairs are different from int11 and int21 because of the way that int22.dat
// file is created.
enum{AA_mm, AC_mm, AG_mm, AU_mm, CA_mm, CC_mm, CG_mm, CU_mm, GA_mm, GC_mm, GG_mm, GU_mm, UA_mm, UC_mm, UG_mm, UU_mm};
enum{int22_AU_pair, int22_CG_pair, int22_GC_pair, int22_GU_pair, int22_UA_pair, int22_UG_pair};

// Following is for indexing the base pair that closes the internal loop.
// It is used ONLY IN int11 and int12 for indexing the base pairs that closes
// internal loop.
enum{AU_pair, CG_pair, GC_pair, UA_pair, GU_pair, UG_pair};

class t_energy_loops;

/*
The class that handles all of the thermodynamic parameter files.
*/
class t_thermo_parameters
{
public:
	// Construct, destruct.
	t_thermo_parameters(char* _thermo_data_dir, t_energy_loops* _energy_loops);
	~t_thermo_parameters();

	double scaling_per_nuc;
	double two_scaling_per_nuc;

	double INIT_SCALING_PER_NUC;
	double RESCALING_UPDATE_PER_NUC;

	// Note that this is loaded for the sequence that this thermo parameter is dealing with.
	void load_SHAPE_data(char* SHAPE_fp);
	double** exp_DG_SHAPE_per_loop;
	double* exp_DG_SHAPE_per_nuc;

	void load_thermo_files();

	// rna sequence to compute the energies.
	t_structure* rna_seq;

	// Data structures for holding thermodynamic parameter data.
	char* thermo_data_dir;

	// Min energy loops that is associated with these thermodynamic free energy parameters.
	//t_energy_loops* energy_loops;

	// Initialization functions.
	void load_loop();
	double** loop_dat;

	void load_tstackh();
	double**** tstackh_dat;

	void load_tstacki1n();
	double**** tstacki_dat;

	void load_tstacki23();
	double**** tstacki23_dat;

	void load_tstacki();
	double**** tstacki1n_dat;

	// This is the terminal mismatching parameters for MB loops.
	void load_tstackm();
	double**** tstackm_dat;

	// This is the terminal mismatch parameters for external loops??
	void load_tstack();
	double**** tstack_dat;

	// Coaxial stacking data files below.
	void load_coaxial();
	double**** coaxial_dat;

	void load_tstackcoax();
	double**** tstackcoax_dat;

	void load_coaxstack();
	double**** coaxstack_dat;

	// Store the different hexaloops for comparison.
	vector<char*>* hexaloops;
	vector<double>* hexaloop_energies;
	vector<int>* hexaloop_hashes;

	// Store the different tetra loops for comparison.
	vector<char*>* tetra_loops;
	vector<double>* tetra_loops_energies;
	vector<int>* tetra_loop_hashes;

	// Store the different triloops for comparison.
	vector<char*>* triloops;
	vector<double>* triloop_energies;
	vector<int>* triloop_hashes;

	int compute_hp_hash(int i, int j);
	int compute_hp_hash(char* loop_nucs);

	void load_triloop();
	void load_tloop();
	void load_hexaloop();

	void load_miscloop();

	// Do not know the number of parameters in miscloop data so use a vector to store this.
	vector<vector<double>*>* miscloop_dat; 

	void load_stack();
	double**** stack_dat;

	// Interior loop files for interior loops smaller than size 4.
	void load_int11();
	double**** int11_dat;
		
	void load_int21();
	double***** int21_dat;

	void load_int22();
	double**** int22_dat;

	// Multibranch loop files.
	void load_dangle();
	double*** fp_dangle_dat;
	double*** tp_dangle_dat;
	double per_helix_penalty;
	double unpaired_nuc_in_MBL_penalty;
	double unpaired_nuc_in_ext_penalty;
	double MBL_closure_penalty;
	double terminal_AU_penalty;
	double GGG_loop_bonus;
	double C3_hp_bonus;
	double C_hp_intercept;
	double C_hp_slope;
	double single_C_bulge;
	double large_loop_scale;

	double max_asym_penalty;
	double poppen[5];

	// Loop energy functions, higher level, makes use of the below array accession functions
	// to determine free energy of a loop.
	double hairpin_energy(int i, int j); // Energy of a hairpin.
	double interior_energy(int outer_i, int outer_j, int inner_i, int inner_j); // Energy of an interior loop.

	// These are the array accession functions.
	// These functions take indices as parameters.
	double loop_energy_by_size(int loop_type, int loop_size);
	double hairpin_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker); // [5' pair][3' pair][5' stacker][3' stacker]
	double bp_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker); // [5' pair][3' pair][5' stacker][3' stacker]
	double interior_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker); // [5' pair][3' pair][5' stacker][3' stacker]
	double interior_stack23_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker); // [5' pair][3' pair][5' stacker][3' stacker]
	double interior_stack1n_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker); // [5' pair][3' pair][5' stacker][3' stacker]
	double interior_1x1_loop_energy(int outer_i, int outer_j, int inner_i, int inner_j); // int11_dat[inner_pair_index][outer_pair_index][5' nuc in internal loop][3' nuc in internal loop]
	double interior_2x1_loop_energy(int outer_i, int outer_j, int inner_i, int inner_j);
	double interior_2x2_loop_energy(int outer_i, int outer_j, int inner_i, int inner_j);
	double dangle_tp_energy(int fp_bp, int tp_bp, int tp_dangler);
	double dangle_fp_energy(int fp_bp, int tp_bp, int fp_dangler);
	double terminal_pair_penalty(int i, int j);

	// Use tstackm and tstack for ml loop and external loop mismatch energies.
	double mbl_mismatch_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker);
	double ext_loop_mismatch_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker);

	// Accession to coaxial stacking functions.
	double mm_stack_coax_helix_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker);
	double perfect_coaxial_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker);
	double imperfect_coaxial_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker);
	double coaxial_stacking_energy(int i, int ip, int j);

	// These are for getting indices to access the arrays since the pair indexing is different for
	// 1x1 and 2x2 internal loop arrays. 1x1 and 2x1 arrays use same indexing scheme.
	int int11_pair_index(int i_nuc, int j_nuc);
	int int22_pair_index(int i_nuc, int j_nuc);
	int int22_MM_index(int i, int j);

	int base2num(char _nuc);

	// MAX_SUM is the function that chooses between MAX and SUM, i.e., between min energy structure prediction and partition function
	// computations.
	double (*MAX_SUM)(double, double);

	// Rescale the required parameters, including per nuc scaling factor.
	//void rescale_thermo_pars(bool up_scale);
	void rescale_thermo_pars(bool up_scale, double _scaling_per_nuc);
	void rescale_thermo_pars(bool up_scale);
};

#endif // _THERMO_PARAMETERS_



