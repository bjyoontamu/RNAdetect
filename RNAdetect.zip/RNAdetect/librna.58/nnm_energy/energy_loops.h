#ifndef _ENERGY_LOOPS_
#define _ENERGY_LOOPS_

#include <climits>

#define DEFAULT_STR_COINC_PROB_THRESH (0.0005)
#define DEFAULT_PAIRING_PROB_THRESH (0.0005)

class t_structure;
class t_V;
class t_WL;
class t_W;
class t_WMBL;
class t_WMB;
class t_Wcoax;
class t_Wout;
class t_thermo_parameters;
class t_tb_stack;
class t_min_energy_structure;
class t_stoch_energy_structures;
class t_cli;
class t_array_sampler;
class t_folding_constraints;
struct t_sampled_structure;
class t_coinc_info;
class t_matrix;

class t_ansi_mutex;
class t_energy_loop_thread;

class t_xmath;

class t_sampling_math;

// This is the main object that handles the energy minimization 
// loops. 
class t_energy_loops
{
public:
	t_energy_loops(t_cli* _cli, t_folding_constraints* folding_constraints = NULL);

	// Feeds the posteriors in the arguments as priors into this computations.
	t_energy_loops(t_cli* _cli, t_coinc_info* _coinc_priors);
	~t_energy_loops();

	t_structure* rna_seq;

	// PF operators.
	t_xmath* xmath;

	// Coincidence priors and getter functions.
	t_coinc_info* coinc_priors;
	double bp_prior(int i, int j);
	double w_coinc_prior(int i, int j);
	double wmb_coinc_prior(int i, int j);
	double wout_coinc_prior(int i, int j);

	// Folding constraints object is used for applying constraints to energy_loops computations.
	t_folding_constraints* folding_constraints;	

	//// The pointer relocation maps.
	//void compute_ptr_reloc_maps();
	//void compute_ptr_reloc_maps(double forced_bp_prob_threshold);

	t_cli* cli;

	// MAX_SUM is the function that chooses between MAX and SUM, i.e., between min energy structure prediction and partition function
	// computations.
	double (*MAX_SUM)(double, double);
	double (*EXCLUDE)(double, double);

	// Thermodynamic parameters.
	t_thermo_parameters* thermo_pars;

	void mallocate_arrays();
	void delete_arrays();

	// Following are the variables for maintaining multithreaded computations.
	int cur_comp_i;
	int cur_comp_j;
	int cur_ij_dist;

	// These are the indices to be computed next.
	int next_i;
	int next_j;
	int next_ij_dist;

	// Get the next index and updates the new indices.
	void get_next_int_comp_indices_by_thread(t_energy_loop_thread* _energy_loop_thread);
	void get_next_ext_comp_indices_by_thread(t_energy_loop_thread* _energy_loop_thread);

	t_ansi_mutex* index_mutex; // Mutex object for regulating access to indices and index updates.
	//vector<t_energy_loop_thread*>* energy_loop_threads; // The list of threads.
	t_energy_loop_thread** energy_loop_threads; // The list of threads.
	int n_threads;

	double compute_internal_loops_row_indexing();
	double compute_internal_loops_off_diagonal_indexing();
	double compute_internal_loops_multithreaded();

	double compute_external_loops_row_indexing();
	double compute_external_loops_off_diagonal_indexing();
	double compute_external_loops_multithreaded();

	void instant_backtrack(int i, int j);

	bool is_rescaling; 
	bool last_index_returned;
	void update_next_int_comp_indices();
	void update_next_ext_comp_indices();

	int cur_base_ext_index;

	// The array objects.
	t_V* V;
	t_WL* WL;
	t_W* W;
	t_WMBL* WMBL;
	t_WMB* WMB;
	t_Wcoax* Wcoax;
	t_Wout* Wout;

	char* sequence_id();

	// Main loops for energy minimization.
	void compute_energy_loops();	

	// Declare the stack for traceback.
	t_tb_stack* tb_stack;
	t_sampling_math* sampling_math; // For stochastic sampling.

	// Trace back method.
	void backtrack_min_energy_structure();
	void backtrack_stoch_energy_structures();

	// backtrack the stack is parameter.
	void backtrack_stoch_energy_custom_stack(t_tb_stack* custom_stack);

	double** linear_pp;
	void compute_linear_pp();

	// Coincidence posterior probabilities and computing function.
	t_coinc_info* coinc_posteriors;
	void estimate_str_coinc_posteriors(); // Estimate linear probabilities of structural co-incidences.

	// Following compute the probabilities of being unpaired, which are usually needed for MEA computations.
	t_matrix* linear_up;
	void compute_linear_up();

	// Minimum energy structure.
	t_min_energy_structure* min_energy_str;
	t_stoch_energy_structures* stoch_energy_strs;

	// Scaling checker.
	bool internal_off_diagonal_indexed_arrays_out_of_bounds(int i, int j);
	bool external_off_diagonal_indexed_arrays_out_of_bounds(int i, int j);

	bool internal_multithreaded_arrays_out_of_bounds(int i, int j);
	bool external_multithreaded_arrays_out_of_bounds(int i, int j);

	double max_bound;
	double min_bound;
	void rescale_internal_row_indexing(bool up_scale, int lim_i, int lim_j);
	void rescale_internal_off_diagonal_indexing(bool up_scale, int lim_i, int lim_j);
	void rescale_internal_multithreaded(bool up_scale, int lim_i, int lim_j);

	void rescale_external_row_indexing(bool up_scale, int lim_i, int lim_j);
	void rescale_external_off_diagonal_indexing(bool up_scale, int lim_i, int lim_j);
	void rescale_external_multithreaded(bool up_scale, int lim_i, int lim_j);
};

#endif // _ENERGY_LOOPS_



