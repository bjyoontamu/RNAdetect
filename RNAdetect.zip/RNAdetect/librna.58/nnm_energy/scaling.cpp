#include <stdio.h>
#include <stdlib.h>
#include "energy_loops.h"
#include "v.h"
#include "wl.h"
#include "w.h"
#include "wmbl.h"
#include "wmb.h"
#include "wcoax.h"
#include "wout.h"
#include "../structure/structure.h"
#include "thermo_parameters.h"
#include "nnm_math.h"
#include "tb_stack.h"
#include "min_energy_structure.h"
#include "stoch_energy_structures.h"
#include "cli.h"
#include "sampling_math.h"
#include "nnm_energy_compilation_directives.h"
#include <limits.h>
#include <float.h>
#include <math.h>
#include <iostream>

#include "../utils/mutex/ansi_mutex.h"
#include "thread/energy_loop_thread.h"

#include "nnm_energy_paths.h"

using namespace std;

bool _DUMP_SCALING_MESSAGES_ = false;

bool one_time_scaling = false;

bool t_energy_loops::internal_multithreaded_arrays_out_of_bounds(int i, int j)
{
	printf("internal_multithreaded_arrays_out_of_bounds not implemented, yet.\n");
	exit(0);
}

bool t_energy_loops::external_multithreaded_arrays_out_of_bounds(int i, int j)
{
	printf("external_multithreaded_arrays_out_of_bounds not implemented, yet.\n");
	exit(0);
}

bool t_energy_loops::internal_off_diagonal_indexed_arrays_out_of_bounds(int i, int j)
{
	//if(!one_time_scaling && (j-i) > 240)
	//{
	//	printf("Spurious rescaling!\n");
	//	one_time_scaling = true;
	//	this->rescale_internal_off_diagonal_indexing(true,i,j);
	//	this->thermo_pars->rescale_thermo_pars(true);
	//	return(true);
	//}

	if(this->V->x(i,j) > 0 && this->V->x(i,j) <= this->min_bound)
	{
		printf("V needs rescaling: %lf\n", this->V->x(i,j));
		this->rescale_internal_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->V->x(i,j) > 0 && this->V->x(i,j) >= this->max_bound)
	{
		printf("V needs rescaling: %lf\n", this->V->x(i,j));
		this->rescale_internal_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	// WL depends on V, V should be computed before WL.
	if(this->WL->x(i,j) > 0 && this->WL->x(i,j) <= this->min_bound)
	{
		printf("WL needs rescaling: %lf\n", this->WL->x(i,j));
		this->rescale_internal_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	// WL depends on V, V should be computed before WL.
	if(this->WL->x(i,j) > 0 && this->WL->x(i,j) >= this->max_bound)
	{
		printf("WL needs rescaling: %lf\n", this->WL->x(i,j));
		this->rescale_internal_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	if(this->W->x(i,j) > 0 && this->W->x(i,j) <= this->min_bound)
	{
		printf("W needs rescaling: %lf\n", this->W->x(i,j));
		this->rescale_internal_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->W->x(i,j) > 0 && this->W->x(i,j) >= this->max_bound)
	{
		printf("W needs rescaling: %lf\n", this->W->x(i,j));
		this->rescale_internal_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	if(this->Wcoax->x(i,j) > 0 && this->Wcoax->x(i,j) <= this->min_bound)
	{
		this->rescale_internal_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->Wcoax->x(i,j) > 0 && this->Wcoax->x(i,j) >= this->max_bound)
	{
		printf("Wcoax needs rescaling: %lf\n", this->Wcoax->x(i,j));
		this->rescale_internal_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	if(this->WMBL->x(i,j) > 0 && this->WMBL->x(i,j) <= this->min_bound)
	{
		printf("WMBL needs rescaling: %lf\n", this->WMBL->x(i,j));
		this->rescale_internal_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->WMBL->x(i,j) > 0 && this->WMBL->x(i,j) >= this->max_bound)
	{
		printf("WMBL needs rescaling: %lf\n", this->WMBL->x(i,j));
		this->rescale_internal_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	// WMB depends on WMBL and Wcoax.
	if(this->WMB->x(i,j) > 0 && this->WMB->x(i,j) <= this->min_bound)
	{
		printf("WMB(%d, %d) needs rescaling: %lf\n", i,j,this->WMB->x(i,j));
		this->rescale_internal_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->WMB->x(i,j) > 0 && this->WMB->x(i,j) >= this->max_bound)
	{
		printf("WMB(%d, %d) needs rescaling: %lf\n", i,j,this->WMB->x(i,j));
		this->rescale_internal_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	// Check Wout too.
	if(this->Wout->x(j) > 0 && this->Wout->x(j) <= this->min_bound)
	{
		printf("Wout needs rescaling: %lf\n", this->Wout->x(j));
		this->rescale_internal_off_diagonal_indexing(true,1,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->Wout->x(j) > 0 && this->Wout->x(j) >= this->max_bound)
	{
		printf("Wout needs rescaling: %lf\n", this->Wout->x(j));
		this->rescale_internal_off_diagonal_indexing(false,1,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	// No rescaling was needed and none done.
	return(false);
}

bool artificial_scalings_done = false;
int n_art_scales = 0;
bool t_energy_loops::external_off_diagonal_indexed_arrays_out_of_bounds(int i, int j)
{	
	
	if(this->V->x_ext(i,j) > 0 && this->V->x_ext(i,j) <= this->min_bound)
	{
		printf("V[ext] needs rescaling: %lf\n", this->V->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	//if((!artificial_scalings_done && j <= 73) || 
	//	this->V->x_ext(i,j) > 0 && this->V->x_ext(i,j) >= this->max_bound)
	if(this->V->x_ext(i,j) > 0 && this->V->x_ext(i,j) >= this->max_bound)
	{
		//n_art_scales++;
		//if(n_art_scales >= 1)
		//{
		//	printf("Artifical rescaling (%d, %d)\n", i,j);
		//	getc(stdin);
		//	artificial_scalings_done = true;
		//}

		printf("V[ext] needs rescaling: %lf\n", this->V->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	// WL depends on V, V should be computed before WL.
	if(this->WL->x_ext(i,j) > 0 && this->WL->x_ext(i,j) <= this->min_bound)
	{
		printf("WL[ext] needs rescaling: %lf\n", this->WL->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	// WL depends on V, V should be computed before WL.
	if(this->WL->x_ext(i,j) > 0 && this->WL->x_ext(i,j) >= this->max_bound)
	{
		printf("WL[ext] needs rescaling: %lf\n", this->WL->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(false, 1, this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(false, i, j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	if(this->W->x_ext(i,j) > 0 && this->W->x_ext(i,j) <= this->min_bound)
	{
		printf("W[ext] needs rescaling: %lf\n", this->W->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->W->x_ext(i,j) > 0 && this->W->x_ext(i,j) >= this->max_bound)
	{
		printf("W[ext] needs rescaling: %lf\n", this->W->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(false,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);	
	}

	if(this->Wcoax->x_ext(i,j) > 0 && this->Wcoax->x_ext(i,j) <= this->min_bound)
	{
		printf("Wcoax[ext] needs rescaling: %lf\n", this->Wcoax->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->Wcoax->x_ext(i,j) > 0 && this->Wcoax->x_ext(i,j) >= this->max_bound)
	{
		printf("Wcoax[ext] needs rescaling: %lf\n", this->Wcoax->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(false,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	if(this->WMBL->x_ext(i,j) > 0 && this->WMBL->x_ext(i,j) <= this->min_bound)
	{
		printf("WMBL[ext] needs rescaling: %lf\n", this->WMBL->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->WMBL->x_ext(i,j) > 0 && this->WMBL->x_ext(i,j) >= this->max_bound)
	{
		printf("WMBL[ext] needs rescaling: %lf\n", this->WMBL->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(false,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);	
	}

	// WMB depends on WMBL and Wcoax.
	if(this->WMB->x_ext(i,j) > 0 && this->WMB->x_ext(i,j) <= this->min_bound)
	{
		printf("WMB[ext] needs rescaling: %lf\n", this->WMB->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(true,i,j);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);	
	}

	if(this->WMB->x_ext(i,j) > 0 && this->WMB->x_ext(i,j) >= this->max_bound)
	{
		printf("WMB[ext] needs rescaling: %lf\n", this->WMB->x_ext(i,j));
		this->rescale_internal_off_diagonal_indexing(false,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(false,i,j);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);	
	}

	// Check Wout too.
	if(this->Wout->x_ext(j) > 0 && this->Wout->x_ext(j) <= this->min_bound)
	{
		printf("Wout needs rescaling: %lf\n", this->Wout->x(j));
		this->rescale_internal_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(true,1,this->rna_seq->numofbases);
		this->thermo_pars->rescale_thermo_pars(true);
		return(true);
	}

	if(this->Wout->x_ext(j) > 0 && this->Wout->x_ext(j) >= this->max_bound)
	{
		printf("Wout[Ext] needs rescaling: %lf\n", this->Wout->x(j));
		this->rescale_internal_off_diagonal_indexing(false,1,this->rna_seq->numofbases);
		this->rescale_external_off_diagonal_indexing(false,1,this->rna_seq->numofbases);
		this->thermo_pars->rescale_thermo_pars(false);
		return(true);
	}

	// No rescaling was needed and none done.
	return(false);
}

/*
Rescale the *thermodynamic parameters* and all the arrays
*/
void t_energy_loops::rescale_internal_off_diagonal_indexing(bool up_scale, int lim_i, int lim_j)
{
	int lim_ij_dist = lim_j - lim_i;

	printf("Rescaling internal single pf arrays...\n");

	for(int ij_dist = MIN_LOOP; ij_dist <= lim_ij_dist && ij_dist <= MIN(this->cli->n_max_separation, this->rna_seq->numofbases); ij_dist++)
	{
		// Update progress bar.

//if(_DUMP_ENERGY_LOOP_MESSAGES_)
//		prog_bar->update_bar(ij_dist);

		// Go over the j indices and compute all ij_dist separated array entries.
		for(int j = ij_dist+1; j <= this->rna_seq->numofbases; j++)
		{
			int i = j - ij_dist;
//if(_DUMP_ENERGY_LOOP_MESSAGES_)
			//printf("Computing (%d, %d)\r", i, j);

			// Do a sanity check on the indices.
			if( i >= 1 && i <= this->rna_seq->numofbases &&
				j >= 1 && j <= this->rna_seq->numofbases)
			{
				// Compute all the arrays.
				//V->compute(i,j);
				double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (j-i+1));
				//printf("Cumulative scaling factor(%d, %d): %lf\n", i,j,cumul_scaling_factor);

				if(cumul_scaling_factor > this->max_bound || cumul_scaling_factor < this->min_bound)
				{
					printf("Fatal error: Cumulative scaling factor hit infinity!\n");
					exit(0);
				}

				if(up_scale)
				{
					V->x(i,j) = MUL(V->x(i,j), cumul_scaling_factor);

					// Rescale WL branchized.
					WL->x_branchized(i,j) = MUL(WL->x_branchized(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x(i,j) = MUL(WL->x(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x(i,j) = MUL(W->x(i,j), cumul_scaling_factor);

					Wcoax->x(i,j) = MUL(Wcoax->x(i,j), cumul_scaling_factor);
		
					WMBL->x(i,j) = MUL(WMBL->x(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x(i,j) = MUL(WMB->x(i,j), cumul_scaling_factor);
				}
				else
				{
					V->x(i,j) = DIV(V->x(i,j), cumul_scaling_factor);

					// Rescale WL branchized.
					WL->x_branchized(i,j) = DIV(WL->x_branchized(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x(i,j) = DIV(WL->x(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x(i,j) = DIV(W->x(i,j), cumul_scaling_factor);

					Wcoax->x(i,j) = DIV(Wcoax->x(i,j), cumul_scaling_factor);
		
					WMBL->x(i,j) = DIV(WMBL->x(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x(i,j) = DIV(WMB->x(i,j), cumul_scaling_factor);
				}
			}
		} // j loop.
	} // i loop.

	// Rescale Wout array.
	// Do not include the boundary condition, which is Wout(0), which does not emit any
	// nucleotide and thus must not be updated.
	for(int i = 0; i <= this->rna_seq->numofbases; i++)
	{
		double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (i-1+1));
		if(up_scale)
		{
			this->Wout->x(i) = MUL(this->Wout->x(i), cumul_scaling_factor);
		}
		else
		{
			this->Wout->x(i) = DIV(this->Wout->x(i), cumul_scaling_factor);
		}
	}
}

/*
Rescale the *thermodynamic parameters* and all the arrays
*/
void t_energy_loops::rescale_internal_row_indexing(bool up_scale, int lim_i, int lim_j)
{
	printf("Rescaling internal single pf arrays...\n");

	// The main loops for energy minimization.
	for(int j = 1; j <= lim_j && j <= this->rna_seq->numofbases; j++)
	{
		int max_i_limit = max(1, j - MIN_LOOP);
		for(int i = max_i_limit; i >= 1; i--)
		{
if(_DUMP_SCALING_MESSAGES_)
			printf("Rescaling (%d, %d)\r", i, j);

			if( (j - i) > MIN_LOOP)
			{
				// Compute all the arrays.
				//V->compute(i,j);
				double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (j-i+1));
				//printf("Cumulative scaling factor(%d, %d): %lf\n", i,j,cumul_scaling_factor);

				if(cumul_scaling_factor > this->max_bound || cumul_scaling_factor < this->min_bound)
				{
					printf("Fatal error: Cumulative scaling factor hit infinity!\n");
					exit(0);
				}

				if(up_scale)
				{
					V->x(i,j) = MUL(V->x(i,j), cumul_scaling_factor);

					// Rescale WL branchized.
					WL->x_branchized(i,j) = MUL(WL->x_branchized(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x(i,j) = MUL(WL->x(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x(i,j) = MUL(W->x(i,j), cumul_scaling_factor);

					Wcoax->x(i,j) = MUL(Wcoax->x(i,j), cumul_scaling_factor);
		
					WMBL->x(i,j) = MUL(WMBL->x(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x(i,j) = MUL(WMB->x(i,j), cumul_scaling_factor);
				}
				else
				{
					V->x(i,j) = DIV(V->x(i,j), cumul_scaling_factor);

					// Rescale WL branchized.
					WL->x_branchized(i,j) = DIV(WL->x_branchized(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x(i,j) = DIV(WL->x(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x(i,j) = DIV(W->x(i,j), cumul_scaling_factor);

					Wcoax->x(i,j) = DIV(Wcoax->x(i,j), cumul_scaling_factor);
		
					WMBL->x(i,j) = DIV(WMBL->x(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x(i,j) = DIV(WMB->x(i,j), cumul_scaling_factor);
				}

				// Limit check.
				if(j == lim_j && i == lim_i)
				{
					// If reached limit for i, break this loop.
					//break; 
				} 
			}
		} // j loop.
	} // i loop.

	// Rescale Wout array.
	// Do not include the boundary condition, which is Wout(0), which does not emit any
	// nucleotide and thus must not be updated.
	for(int i = 0; i <= this->rna_seq->numofbases; i++)
	{
		double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (i-1+1));
		if(up_scale)
		{
			this->Wout->x(i) = MUL(this->Wout->x(i), cumul_scaling_factor);
		}
		else
		{
			this->Wout->x(i) = DIV(this->Wout->x(i), cumul_scaling_factor);
		}
	}
}

void t_energy_loops::rescale_internal_multithreaded(bool up_scale, int lim_i, int lim_j)
{
	// Lock the mutex before updating the indices.
	this->index_mutex->lock_mutex();

	int lim_ij_dist = lim_j - lim_i;

	// Determine the thread that is computing the earliest indices.
	for(int i_thread = 0; i_thread < this->n_threads; i_thread++)
	{
		// In internal computations, ij_dist increases over time, therefore if a thread's ij_dist is smaller, it is in the earlier computations.
		if(lim_ij_dist > this->energy_loop_threads[i_thread]->ij_dist)
		{
			lim_ij_dist = this->energy_loop_threads[i_thread]->ij_dist;
			lim_j = this->energy_loop_threads[i_thread]->j;
		}
		else if(lim_ij_dist == this->energy_loop_threads[i_thread]->ij_dist)
		{
			if(lim_j > this->energy_loop_threads[i_thread]->j)
			{
				lim_j = this->energy_loop_threads[i_thread]->j;
			}
		}
	} // i_thread loop.

	printf("Earliest thread (j, ij_dist) = (%d, %d)\n", lim_j, lim_ij_dist);

	printf("Rescaling internal single pf arrays...\n");

	//for(int ij_dist = MIN(this->cli->n_max_separation, this->rna_seq->numofbases); ij_dist > MIN_LOOP; ij_dist--)
	for(int ij_dist = MIN_LOOP+1; ij_dist <= lim_ij_dist && ij_dist <= MIN(this->cli->n_max_separation, this->rna_seq->numofbases); ij_dist++)
	{
		// Update progress bar.

//if(_DUMP_ENERGY_LOOP_MESSAGES_)
//		prog_bar->update_bar(ij_dist);

		// Go over the j indices and compute all ij_dist separated array entries.
		for(int j = ij_dist+1; j <= this->rna_seq->numofbases; j++)
		{
			int i = j - ij_dist;
//if(_DUMP_ENERGY_LOOP_MESSAGES_)
			//printf("Computing (%d, %d)\r", i, j);

			// Do a sanity check on the indices.
			if( i >= 1 && i <= this->rna_seq->numofbases &&
				j >= 1 && j <= this->rna_seq->numofbases)
			{
				// Compute all the arrays.
				//V->compute(i,j);
				double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (j-i+1));
				//printf("Cumulative scaling factor(%d, %d): %lf\n", i,j,cumul_scaling_factor);

				if(cumul_scaling_factor > this->max_bound || cumul_scaling_factor < this->min_bound)
				{
					printf("Fatal error: Cumulative scaling factor hit infinity!\n");
					exit(0);
				}

				if(up_scale)
				{
					V->x(i,j) = MUL(V->x(i,j), cumul_scaling_factor);

					// Rescale WL branchized.
					WL->x_branchized(i,j) = MUL(WL->x_branchized(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x(i,j) = MUL(WL->x(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x(i,j) = MUL(W->x(i,j), cumul_scaling_factor);

					Wcoax->x(i,j) = MUL(Wcoax->x(i,j), cumul_scaling_factor);
		
					WMBL->x(i,j) = MUL(WMBL->x(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x(i,j) = MUL(WMB->x(i,j), cumul_scaling_factor);
				}
				else
				{
					V->x(i,j) = DIV(V->x(i,j), cumul_scaling_factor);

					// Rescale WL branchized.
					WL->x_branchized(i,j) = DIV(WL->x_branchized(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x(i,j) = DIV(WL->x(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x(i,j) = DIV(W->x(i,j), cumul_scaling_factor);

					Wcoax->x(i,j) = DIV(Wcoax->x(i,j), cumul_scaling_factor);
		
					WMBL->x(i,j) = DIV(WMBL->x(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x(i,j) = DIV(WMB->x(i,j), cumul_scaling_factor);
				}
			}
		} // j loop.
	} // i loop.

	// Rescale Wout array.
	// Do not include the boundary condition, which is Wout(0), which does not emit any
	// nucleotide and thus must not be updated.
	for(int i = 0; i <= this->rna_seq->numofbases; i++)
	{
		double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (i-1+1));
		if(up_scale)
		{
			this->Wout->x(i) = MUL(this->Wout->x(i), cumul_scaling_factor);
		}
		else
		{
			this->Wout->x(i) = DIV(this->Wout->x(i), cumul_scaling_factor);
		}
	}

	// Set the next values to ensure that 
	this->next_ij_dist = lim_ij_dist;
	this->next_i = lim_j - lim_ij_dist;
	this->next_j = lim_j;
	this->index_mutex->release_mutex();
}

void t_energy_loops::rescale_external_off_diagonal_indexing(bool up_scale, int lim_i, int lim_j)
{
	int lim_ij_dist = 0;

	printf("Rescaling external single pf arrays... (%d, %d)\n", lim_i, lim_j);

	// The main loops for energy minimization.
	for(int ij_dist = MIN(this->cli->n_max_separation, this->rna_seq->numofbases); ij_dist >= lim_ij_dist && ij_dist >= MIN_LOOP; ij_dist--)
	{
		// Go over the j indices and compute all ij_dist separated array entries.
		for(int j = ij_dist+1; j <= this->rna_seq->numofbases; j++)
		{
			int i = j - ij_dist;
//if(_DUMP_ENERGY_LOOP_MESSAGES_)
			//printf("Computing (%d, %d)\r", i, j);

			// Do a sanity check on the indices.
			if( i >= 1 && i <= this->rna_seq->numofbases &&
				j >= 1 && j <= this->rna_seq->numofbases)
			{
				// Compute all the arrays.
				// The cumulative rescaling in the case is gonig to 
				double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (this->rna_seq->numofbases) - (j-i+1));

				if(cumul_scaling_factor > this->max_bound || 
					cumul_scaling_factor < this->min_bound)
				{
					printf("Fatal error: Cumulative scaling factor hit infinity!\n");
					exit(0);
				}

				if(up_scale)
				{
					V->x_ext(i,j) = MUL(V->x_ext(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x_ext(i,j) = MUL(WL->x_ext(i,j), cumul_scaling_factor);

					WL->x_branchized_ext(i,j) = MUL(WL->x_branchized_ext(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x_ext(i,j) = MUL(W->x_ext(i,j), cumul_scaling_factor);

					Wcoax->x_ext(i,j) = MUL(Wcoax->x_ext(i,j), cumul_scaling_factor);
		
					WMBL->x_ext(i,j) = MUL(WMBL->x_ext(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x_ext(i,j) = MUL(WMB->x_ext(i,j), cumul_scaling_factor);
				}
				else
				{
					V->x_ext(i,j) = DIV(V->x_ext(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x_ext(i,j) = DIV(WL->x_ext(i,j), cumul_scaling_factor);

					WL->x_branchized_ext(i,j) = DIV(WL->x_branchized_ext(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x_ext(i,j) = DIV(W->x_ext(i,j), cumul_scaling_factor);

					Wcoax->x_ext(i,j) = DIV(Wcoax->x_ext(i,j), cumul_scaling_factor);
		
					WMBL->x_ext(i,j) = DIV(WMBL->x_ext(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x_ext(i,j) = DIV(WMB->x_ext(i,j), cumul_scaling_factor);
				}
			} // min loop check.
		} // j loop.
	} // i loop.

	// Rescale Wout array.
	// Do not include the boundary condition, which is Wout(0), which does not emit any
	// nucleotide and thus must not be updated.
	for(int i = 1; i <= this->rna_seq->numofbases; i++)
	{
		double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (this->rna_seq->numofbases - i + 1));
		if(up_scale)
		{
			this->Wout->x_ext(i) = MUL(this->Wout->x_ext(i), cumul_scaling_factor);
		}
		else
		{
			this->Wout->x_ext(i) = DIV(this->Wout->x_ext(i), cumul_scaling_factor);
		}
	}
}

// Do a rescaling for external computations.
void t_energy_loops::rescale_external_row_indexing(bool up_scale, int lim_i, int lim_j)
{
	printf("Rescaling external single pf arrays...\n");

	// The main loops for energy minimization.
	for(int j = this->rna_seq->numofbases; j >= 1; j--)
	{
		int max_i_limit = max(1, j - MIN_LOOP);
		int min_i_limit = max(1, j - this->cli->n_max_separation);
		for(int i = min_i_limit; i <= max_i_limit; i++)
		{
			printf("Rescaling[Ext] (%d, %d)\r", i, j);

			if( (j - i) > MIN_LOOP)
			{
				// Compute all the arrays.
				// The cumulative rescaling in the case is gonig to 
				double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (this->rna_seq->numofbases) - (j-i+1));

				if(cumul_scaling_factor > this->max_bound || 
					cumul_scaling_factor < this->min_bound)
				{
					printf("Fatal error: Cumulative scaling factor hit infinity!\n");
					exit(0);
				}

				if(up_scale)
				{
					V->x_ext(i,j) = MUL(V->x_ext(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x_ext(i,j) = MUL(WL->x_ext(i,j), cumul_scaling_factor);

					WL->x_branchized_ext(i,j) = MUL(WL->x_branchized_ext(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x_ext(i,j) = MUL(W->x_ext(i,j), cumul_scaling_factor);

					Wcoax->x_ext(i,j) = MUL(Wcoax->x_ext(i,j), cumul_scaling_factor);
		
					WMBL->x_ext(i,j) = MUL(WMBL->x_ext(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x_ext(i,j) = MUL(WMB->x_ext(i,j), cumul_scaling_factor);
				}
				else
				{
					V->x_ext(i,j) = DIV(V->x_ext(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x_ext(i,j) = DIV(WL->x_ext(i,j), cumul_scaling_factor);

					WL->x_branchized_ext(i,j) = DIV(WL->x_branchized_ext(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x_ext(i,j) = DIV(W->x_ext(i,j), cumul_scaling_factor);

					Wcoax->x_ext(i,j) = DIV(Wcoax->x_ext(i,j), cumul_scaling_factor);
		
					WMBL->x_ext(i,j) = DIV(WMBL->x_ext(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x_ext(i,j) = DIV(WMB->x_ext(i,j), cumul_scaling_factor);
				}
			} // min loop check.
		} // j loop.
	} // i loop.

	// Rescale Wout array.
	// Do not include the boundary condition, which is Wout(0), which does not emit any
	// nucleotide and thus must not be updated.
	for(int i = 1; i <= this->rna_seq->numofbases; i++)
	{
		double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (this->rna_seq->numofbases - i));
		if(up_scale)
		{
			this->Wout->x_ext(i) = MUL(this->Wout->x_ext(i), cumul_scaling_factor);
		}
		else
		{
			this->Wout->x_ext(i) = DIV(this->Wout->x_ext(i), cumul_scaling_factor);
		}
	}
}

void t_energy_loops::rescale_external_multithreaded(bool up_scale, int lim_i, int lim_j)
{
	// Set the next values to ensure that 
	this->index_mutex->lock_mutex();

	int lim_ij_dist = lim_j - lim_i;

	// Determine the thread that is computing the earliest indices.
	for(int i_thread = 0; i_thread < this->n_threads; i_thread++)
	{
		// In external computations, ij_dist decreases over time, therefore if a thread's ij_dist is larger, it is in the earlier computations.
		if(lim_ij_dist < this->energy_loop_threads[i_thread]->ij_dist)
		{
			lim_ij_dist = this->energy_loop_threads[i_thread]->ij_dist;
			lim_j = this->energy_loop_threads[i_thread]->j;
		}
		else if(lim_ij_dist == this->energy_loop_threads[i_thread]->ij_dist)
		{
			if(lim_j > this->energy_loop_threads[i_thread]->j)
			{
				lim_j = this->energy_loop_threads[i_thread]->j;
			}
		}
	} // i_thread loop.

	printf("Rescaling external single pf arrays...\n");

	// The main loops for energy minimization.
	for(int ij_dist = MIN(this->cli->n_max_separation, this->rna_seq->numofbases); ij_dist >= lim_ij_dist && ij_dist > MIN_LOOP; ij_dist--)
	{
		// Go over the j indices and compute all ij_dist separated array entries.
		for(int j = ij_dist+1; j <= this->rna_seq->numofbases; j++)
		{
			int i = j - ij_dist;
//if(_DUMP_ENERGY_LOOP_MESSAGES_)
			//printf("Computing (%d, %d)\r", i, j);

			// Do a sanity check on the indices.
			if( i >= 1 && i <= this->rna_seq->numofbases &&
				j >= 1 && j <= this->rna_seq->numofbases)
			{
				// Compute all the arrays.
				// The cumulative rescaling in the case is gonig to 
				double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (this->rna_seq->numofbases) - (j-i+1));

				if(cumul_scaling_factor > this->max_bound || 
					cumul_scaling_factor < this->min_bound)
				{
					printf("Fatal error: Cumulative scaling factor hit infinity!\n");
					exit(0);
				}

				if(up_scale)
				{
					V->x_ext(i,j) = MUL(V->x_ext(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x_ext(i,j) = MUL(WL->x_ext(i,j), cumul_scaling_factor);

					WL->x_branchized_ext(i,j) = MUL(WL->x_branchized_ext(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x_ext(i,j) = MUL(W->x_ext(i,j), cumul_scaling_factor);

					Wcoax->x_ext(i,j) = MUL(Wcoax->x_ext(i,j), cumul_scaling_factor);
		
					WMBL->x_ext(i,j) = MUL(WMBL->x_ext(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x_ext(i,j) = MUL(WMB->x_ext(i,j), cumul_scaling_factor);
				}
				else
				{
					V->x_ext(i,j) = DIV(V->x_ext(i,j), cumul_scaling_factor);

					// WL depends on V, V should be computed before WL.
					WL->x_ext(i,j) = DIV(WL->x_ext(i,j), cumul_scaling_factor);

					WL->x_branchized_ext(i,j) = DIV(WL->x_branchized_ext(i,j), cumul_scaling_factor);

					// W depends on WL.
					W->x_ext(i,j) = DIV(W->x_ext(i,j), cumul_scaling_factor);

					Wcoax->x_ext(i,j) = DIV(Wcoax->x_ext(i,j), cumul_scaling_factor);
		
					WMBL->x_ext(i,j) = DIV(WMBL->x_ext(i,j), cumul_scaling_factor);

					// WMB depends on WMBL and Wcoax.
					WMB->x_ext(i,j) = DIV(WMB->x_ext(i,j), cumul_scaling_factor);
				}
			} // min loop check.
		} // j loop.
	} // i loop.

	// Rescale Wout array.
	// Do not include the boundary condition, which is Wout(0), which does not emit any
	// nucleotide and thus must not be updated.
	for(int i = 1; i <= this->rna_seq->numofbases; i++)
	{
		double cumul_scaling_factor = POW(this->thermo_pars->RESCALING_UPDATE_PER_NUC, (this->rna_seq->numofbases - i));
		if(up_scale)
		{
			this->Wout->x_ext(i) = MUL(this->Wout->x_ext(i), cumul_scaling_factor);
		}
		else
		{
			this->Wout->x_ext(i) = DIV(this->Wout->x_ext(i), cumul_scaling_factor);
		}
	}

	// Set the next values to ensure that 
	this->next_ij_dist = lim_ij_dist;
	this->next_i = lim_j - lim_ij_dist;
	this->next_j = lim_j;

	// Release lock on indices.
	this->index_mutex->release_mutex();
}

