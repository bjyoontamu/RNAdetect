#ifndef _WMB_
#define _WMB_

class t_structure;
class t_energy_array;
class t_energy_loops;

class t_WMB
{
public:
	t_WMB(t_energy_loops* _energy_loops);
	~t_WMB();

	// This is the energy storage.
	t_energy_array* energy_array;
	t_energy_array* ext_energy_array;

	// RNA sequence.
	t_structure* rna_seq;

	// Minimum energy loops that this WL array belongs to.
	// By gaining access to this class, WL has access to all other arrays.
	t_energy_loops* energy_loops;

	double (*MAX_SUM)(double,double);

	// Compute WMBL for a subsequence.
	void compute(int i, int j);
	void compute_ext_dependencies(int i, int j);

	// Accession function.
	double& x(int i, int j);
	double& x_ext(int i, int j);

	void min_energy_tb(int i, int j);
	void stoch_energy_tb(int i, int j);
};

#endif // _WMB_



