#include <stdio.h>
#include <stdlib.h>
#include "energy_loops.h"
#include "min_energy_structure.h"
#include "thermo_parameters.h"
#include "../structure/structure.h"
#include "wout.h"
#include "nnm_energy_paths.h"
#include "../utils/file/utils.h"
#include <math.h>

t_min_energy_structure::t_min_energy_structure(t_energy_loops* _energy_loops)
{
	this->energy_loops = _energy_loops;

	this->bps = (int*)malloc(sizeof(int) * (this->energy_loops->rna_seq->numofbases + 3));

	// Init all base pairs to unpaired.
	for(int i = 0; i <= this->energy_loops->rna_seq->numofbases; i++)
	{
		this->bps[i] = 0;
	}
}

t_min_energy_structure::~t_min_energy_structure()
{
	free(this->bps);
}

void t_min_energy_structure::add_bp(int i, int j)
{
	if(i <= this->energy_loops->rna_seq->numofbases && j <= this->energy_loops->rna_seq->numofbases)
	{
		this->bps[i] = j;
		this->bps[j] = i;
	}
}

void t_min_energy_structure::dump()
{
	// Dump all base pairing info for ct1.
	char str_fp[__MAX_PATH];
	sprintf(str_fp, "%s/%s_min_energy.ct", MIN_ENERGY_STRS_DIR, this->energy_loops->sequence_id());

	//printf("str path is %s\n", str_fp);
	//exit(0);

	FILE* f_str = open_f(str_fp, "w");

	if(f_str == NULL)
	{
		printf("Could not open %s for writing.\n", str_fp);
		exit(0);
	}

	// Division by 1000 is in order to compensate for for KCals.
	fprintf(f_str, "%d\tENERGY %.5f\n", this->energy_loops->rna_seq->numofbases, this->energy_loops->Wout->x(this->energy_loops->rna_seq->numofbases) / (NEG_OVER_RT)); 
	for(int cnt = 1; cnt <= this->energy_loops->rna_seq->numofbases; cnt++)
	{
		// Sth. like following:
		//     1 G       0    2   73    1
		fprintf(f_str, "%d %c\t%d\t%d\t%d\t%d\n", cnt, this->energy_loops->rna_seq->nucs[cnt], cnt-1, cnt+1, this->bps[cnt], cnt);
	}
	fclose(f_str);
}


