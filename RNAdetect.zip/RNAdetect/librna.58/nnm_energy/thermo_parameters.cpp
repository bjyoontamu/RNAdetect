#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "thermo_parameters.h"
#include "energy_loops.h"
#include "nnm_math.h"
#include <math.h>
#include "../structure/structure.h"
#include "../utils/xmath/log/xlog_math.h"
#include "../utils/file/utils.h"

bool DUMP_THERMO_PARAMETERS_MESSAGES = false;

#define BASE_ALLOC_SIZE (8)
#define PAIR_ALLOC_SIZE (8)

t_thermo_parameters::t_thermo_parameters(char* _thermo_data_dir, t_energy_loops* _energy_loops)
{
	// Get the thermo directory.
	this->thermo_data_dir = (char*)malloc(sizeof(char) * (strlen(_thermo_data_dir) + 3));
	strcpy(this->thermo_data_dir, _thermo_data_dir);

	this->MAX_SUM = _energy_loops->MAX_SUM;

	this->rna_seq = _energy_loops->rna_seq;

	this->exp_DG_SHAPE_per_loop = NULL;
	this->exp_DG_SHAPE_per_nuc = NULL;

	//this->DOMTRANS_GAP_ENERGY = INIT_DOMTRANS_GAP_ENERGY; //(CONVERT_FROM_LOG(-0.10f * NEG_OVER_RT));
	//this->DOMTRANS_MATCH_ENERGY = INIT_DOMTRANS_MATCH_ENERGY; //(CONVERT_FROM_LOG(-0.10f * NEG_OVER_RT));
	//this->RELAXATION_FACTOR = DEFAULT_RELAXATION_FACTOR;
	//this->UNCOMMON_ENERGY_CHANGE_PER_NUC_PER_ROUND = this->DOMTRANS_GAP_ENERGY * this->RELAXATION_FACTOR;

	this->scaling_per_nuc = CONVERT_FROM_LIN(1.0f);
	this->two_scaling_per_nuc = MUL(this->scaling_per_nuc, this->scaling_per_nuc);

	// Load thermodynamic data.
	this->load_thermo_files();

#ifdef _LINEAR_NNM_COMPUTATIONS_
	// Initially rescale the thermodynamic parameters if linear computations are being done.
	this->INIT_SCALING_PER_NUC = CONVERT_FROM_LIN(0.4f);
	this->RESCALING_UPDATE_PER_NUC = CONVERT_FROM_LIN(1.05f);
	this->rescale_thermo_pars(true, INIT_SCALING_PER_NUC);
#endif
}

void t_thermo_parameters::rescale_thermo_pars(bool up_scale)
{
	this->rescale_thermo_pars(up_scale, this->RESCALING_UPDATE_PER_NUC);
}

void t_thermo_parameters::rescale_thermo_pars(bool up_scale, double _rescaling_per_nuc)
{
	double effective_rescaling_factor = CONVERT_FROM_LIN(1.0f);
	if(up_scale)
	{
		effective_rescaling_factor = _rescaling_per_nuc;
	}
	else
	{
		effective_rescaling_factor = DIV(1.0f, _rescaling_per_nuc);
	}

		//this->scaling_per_nuc = MUL(this->scaling_per_nuc, RESCALING_UPDATE_PER_NUC);
	this->scaling_per_nuc = MUL(this->scaling_per_nuc, effective_rescaling_factor);
	this->two_scaling_per_nuc = MUL(this->scaling_per_nuc, this->scaling_per_nuc);

	// Rescale loop data.
	for(int n_loop = 1; n_loop <= 30; n_loop++)
	{
		for(int i_loop = 0; i_loop < 3; i_loop++)
		{
			// Includes the scaling for closing bp.
			this->loop_dat[i_loop][n_loop] = MUL(this->loop_dat[i_loop][n_loop], POW(effective_rescaling_factor, n_loop+2));
		}
	}

	/* 
	Rescale tstackh data: These are not rescaled since rescaling for hairpin loops and closing bp are handled 
	by loop size energies.
	*/
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstackh_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstackh_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstackh_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				// Init all to 0.
				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					//this->tstackh_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = this->tstackh_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker];
				}
			}
		}
	}

	/*
	Rescale tstacki data: Not rescaled since scaling for closing bp's are handled by loop size dependencies.
	*/
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstacki_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstacki_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstacki_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					//this->tstacki_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0);
				}
			}
		}
	}

	/*
	Rescale tstacki23, tstacki1n: Are not rescaled since closing and stacking bp's are rescaled by loop size dependent
	energies above.
	*/

	/*
	Rescale tstackm: Terminal mismatches in MBL's: The scaling for closing bp is added in the code. The scaling for
	dangling nucs are added via unpaired_nuc_in_mb term.
	*/

	/*
	Rescale tstack: Terminal mismatches in external loops: The scaling for closing bp is added in the code. The scaling for
	dangling nucs are added via unpaired_nuc_in_mb term.
	*/

	/*
	Rescale stack: Stacking energy for a stacked bp. These will be handled here.
	*/
	//this->stack_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->stack_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->stack_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->stack_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->stack_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = MUL(this->stack_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker], POW(effective_rescaling_factor, 2));
				}
			}
		}
	}

	/*
	Rescale triloop: Special hairpins, add the rescaling factors for closing bp.
	*/
	for(int i = 0; i < (int)this->triloops->size(); i++)
	{
		//printf("%s(%d) -> %f\n", this->triloops->at(i), this->triloop_hashes->at(i), this->triloop_energies->at(i));
		this->triloop_energies->at(i) = MUL(this->triloop_energies->at(i), POW(effective_rescaling_factor, 3+2));
	}

	/*
	Rescale tloop: Special hairpins, add the rescaling factors for closing bp.
	*/
	for(int i = 0; i < (int)this->tetra_loops->size(); i++)
	{
		//printf("%s(%d) -> %f\n", this->triloops->at(i), this->triloop_hashes->at(i), this->triloop_energies->at(i));
		this->tetra_loops_energies->at(i) = MUL(this->tetra_loops_energies->at(i), POW(effective_rescaling_factor, 4+2));
	}

	/*
	Rescale hexaloop: Special hairpins, add the rescaling factors for closing bp.
	*/
	for(int i = 0; i < (int)this->hexaloops->size(); i++)
	{
		//printf("%s(%d) -> %f\n", this->triloops->at(i), this->triloop_hashes->at(i), this->triloop_energies->at(i));
		this->hexaloop_energies->at(i) = MUL(this->hexaloop_energies->at(i), POW(effective_rescaling_factor, 6+2));
	}

	/*
	Rescale miscloop parameters: Only unpaired nuc in MBL penalty.
	*/
	//this->large_loop_scale = this->miscloop_dat->at(0)->at(0);

	// Following goes into computing asymmetry penalties for internal loops, need not be scaled
	// since these are not directly related to emitting nucleotides.
	//this->max_asym_penalty = this->miscloop_dat->at(1)->at(0);
	//this->poppen[1] = this->miscloop_dat->at(2)->at(0);
	//this->poppen[2] = this->miscloop_dat->at(2)->at(1);
	//this->poppen[3] = this->miscloop_dat->at(2)->at(2);
	//this->poppen[4] = this->miscloop_dat->at(2)->at(3);

	// MB closure penalty is related to closing and MBL where the closing bp is emitted. The 
	// rescaling for closing bp is added manually.
	// MBL closure corresponds to closing an MBL with a base pair. This can be exploited to 
	this->MBL_closure_penalty = MUL(this->MBL_closure_penalty, POW(effective_rescaling_factor, 2));
	this->unpaired_nuc_in_MBL_penalty = MUL(this->unpaired_nuc_in_MBL_penalty, effective_rescaling_factor);
	this->unpaired_nuc_in_ext_penalty = MUL(this->unpaired_nuc_in_ext_penalty, effective_rescaling_factor);
	//this->per_helix_penalty = this->miscloop_dat->at(3)->at(2);
	//this->terminal_AU_penalty = this->miscloop_dat->at(7)->at(0);

	// GGG loop bonus for hairpins. Rescaling is included in the loop size energy.
	//this->GGG_loop_bonus = this->miscloop_dat->at(8)->at(0);

	// Multi C hairpin loop intercept and slope energies. The scaling for unpaired nucs in the loop
	// are included in size dependent energy.
	//this->C_hp_slope = this->miscloop_dat->at(9)->at(0);
	//this->C_hp_intercept = this->miscloop_dat->at(10)->at(0);
	//this->C3_hp_bonus = this->miscloop_dat->at(11)->at(0);

	// Single C bulge, scaling is included in size dependent energy.
	//this->single_C_bulge = this->miscloop_dat->at(13)->at(0);

	/*
	Rescale int11: Special 1x1 internal loop.
	*/
	for(int	_outer_pair = AU_pair; _outer_pair <= UG_pair; _outer_pair++)
	{
		//this->int11_dat[_outer_pair] = (double***)malloc(sizeof(double**) * PAIR_ALLOC_SIZE);

		for(int	_inner_pair = AU_pair; _inner_pair <= UG_pair; _inner_pair++)		
		{
			//this->int11_dat[_outer_pair][_inner_pair] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
			{
				//this->int11_dat[_outer_pair][_inner_pair][_fp_nuc] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
				{
					// Do not include the special loop bonuses for these nucleotides.
					this->int11_dat[_outer_pair][_inner_pair][_fp_nuc][_tp_nuc] = MUL(this->int11_dat[_outer_pair][_inner_pair][_fp_nuc][_tp_nuc], POW(effective_rescaling_factor, 4));
				}
			} // Allocation loop fp_nuc
		} // Allocation loop innter_pair
	} // Allocation loop outer_pair

	/*
	Rescale int21
	*/
	for(int	_outer_pair = AU_pair; _outer_pair <= UG_pair; _outer_pair++)
	{
		//this->int21_dat[_outer_pair] = (double****)malloc(sizeof(double***) * PAIR_ALLOC_SIZE);

		for(int	_inner_pair = AU_pair; _inner_pair <= UG_pair; _inner_pair++)
		{
			//this->int21_dat[_outer_pair][_inner_pair] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

			for(int	_fp_side_fp_nuc = BASE_X; _fp_side_fp_nuc <= BASE_I; _fp_side_fp_nuc++)
			{
				//this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

				for(int	_fp_side_tp_nuc = BASE_X; _fp_side_tp_nuc <= BASE_I; _fp_side_tp_nuc++)
				{
					//this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc][_fp_side_tp_nuc] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

					for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
					{
						this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc][_fp_side_tp_nuc][_tp_nuc] = MUL(this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc][_fp_side_tp_nuc][_tp_nuc], POW(effective_rescaling_factor, 5));
					}
				}
			} // Allocation loop fp_nuc
		} // Allocation loop innter_pair
	} // Allocation loop outer_pair

	/*
	Rescale int22
	*/
	for(int	_outer_pair = int22_AU_pair; _outer_pair <= int22_UG_pair; _outer_pair++)
	{
		//this->int22_dat[_outer_pair] = (double***)malloc(sizeof(double**) * PAIR_ALLOC_SIZE);

		for(int _inner_pair = int22_AU_pair; _inner_pair <= int22_UG_pair; _inner_pair++)
		{
			//this->int22_dat[_outer_pair][_inner_pair] = (double**)malloc(sizeof(double*) * 18);

			for(int	_outer_mm = AA_mm; _outer_mm <= UU_mm; _outer_mm++)
			{
				//this->int22_dat[_outer_pair][_inner_pair][_outer_mm] = (double*)malloc(sizeof(double) * 18);

				for(int _inner_mm = AA_mm; _inner_mm <= UU_mm; _inner_mm++)
				{
					//printf("eff res factor: %lf\n", POW(effective_rescaling_factor, 6));
					this->int22_dat[_outer_pair][_inner_pair][_outer_mm][_inner_mm] = MUL(this->int22_dat[_outer_pair][_inner_pair][_outer_mm][_inner_mm], POW(effective_rescaling_factor, 6));
				}
			} // Allocation loop fp_nuc
		} // Allocation loop innter_pair
	} // Allocation loop outer_pair

	/*
	Rescale dangle: The rescaling factors for dangling nucleotides are included in unpaired_nuc_in_mbl energies. 
	The rescaling of nucleotides in base pairs that the dangling nucleotides are stacked on are handled whenever
	they close the corresponding loop. The issue here is that the dangles and stacks might be handling on branch
	or on mb closure stacking. That is why it is not appropriate to handle scaling of paired nucs here.
	*/

	/*
	Coaxial stacking energies: Only rescale tstackcoax.
	*/
	//for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	//{
	//	//this->tstackcoax_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

	//	for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
	//	{
	//		//this->tstackcoax_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

	//		for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
	//		{
	//			//this->tstackcoax_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

	//			for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
	//			{
	//				this->tstackcoax_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = MUL(this->tstackcoax_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker], POW(effective_rescaling_factor, 2));
	//			}
	//		}
	//	}
	//}

	//printf("energy = %lf\n", this->interior_2x2_loop_energy(10, 20, 13, 17));
	//printf("energy = %lf\n", this->int22_dat[int22_GU_pair][int22_GU_pair][_outer_mm][_inner_mm]);
	//exit(0);
}

void t_thermo_parameters::load_thermo_files()
{
	this->load_loop();
	this->load_tstackh();
	this->load_tstacki();
	this->load_tstacki23();
	this->load_tstacki1n();
	this->load_tstackm();
	this->load_tstack();
	this->load_stack();
	this->load_triloop();
	this->load_tloop();
	this->load_hexaloop();
	this->load_miscloop();
	this->load_int11();
	this->load_int21();
	this->load_int22();
	this->load_dangle();
	this->load_coaxial();
	this->load_coaxstack();
	this->load_tstackcoax();

	this->unpaired_nuc_in_ext_penalty = CONVERT_FROM_LIN(1.0f);
}

t_thermo_parameters::~t_thermo_parameters()
{
	free(this->thermo_data_dir);

	//this->loop_dat = (double**)malloc(sizeof(double*) * 4);
	for(int i = 0; i < 3; i++)
	{
		//this->loop_dat[i] = (double*)malloc(sizeof(double) * 35);
		free(this->loop_dat[i]);
	}
	free(this->loop_dat);

	// Free triloop arrays.
	this->triloop_energies->clear();
	this->triloop_hashes->clear();

	for(int i_triloop = 0; i_triloop < (int)this->triloops->size(); i_triloop++)
	{
		free(this->triloops->at(i_triloop));
	}
	this->triloops->clear();
	delete(this->triloops);

	this->triloop_energies->clear();
	delete(this->triloop_energies);

	this->triloop_hashes->clear();
	delete(this->triloop_hashes);

	// Free tstach data.
	// Allocate tstackh data structure.
	//this->tstackh_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstackh_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstackh_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstackh_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				//// Init all to 0.
				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->tstackh_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				//}

				free(this->tstackh_dat[_fp_nuc][_tp_nuc][_fp_stacker]);
			}

			free(this->tstackh_dat[_fp_nuc][_tp_nuc]);
		}
		free(this->tstackh_dat[_fp_nuc]);
	}
	free(this->tstackh_dat);

	// tstacki
	//this->tstacki_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstacki_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstacki_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstacki_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);
				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->tstacki_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0);
				//}

				free(this->tstacki_dat[_fp_nuc][_tp_nuc][_fp_stacker]);
			}

			free(this->tstacki_dat[_fp_nuc][_tp_nuc]);
		}

		free(this->tstacki_dat[_fp_nuc]);
	}
	free(this->tstacki_dat);

	// free tstacki23 data.
	//this->tstacki23_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstacki23_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstacki23_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstacki23_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);
				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->tstacki23_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				//}

				free(this->tstacki23_dat[_fp_nuc][_tp_nuc][_fp_stacker]);
			}
			free(this->tstacki23_dat[_fp_nuc][_tp_nuc]);
		}
		free(this->tstacki23_dat[_fp_nuc]);
	}
	free(this->tstacki23_dat);

	// Free tstacki1n data
	//this->tstacki1n_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstacki1n_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstacki1n_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstacki1n_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->tstacki1n_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);;
				//}

				free(this->tstacki1n_dat[_fp_nuc][_tp_nuc][_fp_stacker]);
			}

			free(this->tstacki1n_dat[_fp_nuc][_tp_nuc]);
		}

		free(this->tstacki1n_dat[_fp_nuc]);
	}	
	free(this->tstacki1n_dat);


	// free tstackm data.
	//this->tstackm_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstackm_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstackm_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstackm_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->tstackm_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				//}

				free(this->tstackm_dat[_fp_nuc][_tp_nuc][_fp_stacker]);
			}
			free(this->tstackm_dat[_fp_nuc][_tp_nuc]);
		}
		free(this->tstackm_dat[_fp_nuc]);
	}
	free(this->tstackm_dat);

	// Free tstack data.
	//this->tstack_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstack_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstack_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstack_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->tstack_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				//}

				free(this->tstack_dat[_fp_nuc][_tp_nuc][_fp_stacker]);

			}
			free(this->tstack_dat[_fp_nuc][_tp_nuc]);
		}
		free(this->tstack_dat[_fp_nuc]);
	}
	free(this->tstack_dat);

	// Free stack data.
	//this->stack_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->stack_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->stack_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->stack_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->stack_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				//}

				free(this->stack_dat[_fp_nuc][_tp_nuc][_fp_stacker]);
			}
			free(this->stack_dat[_fp_nuc][_tp_nuc]);
		}

		free(this->stack_dat[_fp_nuc]);
	}
	free(this->stack_dat);

	// Free tloop data.
	for(int i_tloop = 0; i_tloop < (int)this->tetra_loops->size(); i_tloop++)
	{
		free(this->tetra_loops->at(i_tloop));
	}
	this->tetra_loops->clear();
	delete(this->tetra_loops);

	this->tetra_loops_energies->clear();
	delete(this->tetra_loops_energies);

	this->tetra_loop_hashes->clear();
	delete(this->tetra_loop_hashes);

	// Free hexaloop data.
	for(int i_hexaloop = 0; i_hexaloop < (int)this->hexaloops->size(); i_hexaloop++)
	{
		free(this->hexaloops->at(i_hexaloop));
	}
	this->hexaloops->clear();
	delete(this->hexaloops);

	this->hexaloop_energies->clear();
	delete(this->hexaloop_energies);

	this->hexaloop_hashes->clear();
	delete(this->hexaloop_hashes);

	// Free miscloop data.
	for(int i_misc_energy_set = 0; i_misc_energy_set < (int)this->miscloop_dat->size(); i_misc_energy_set++)
	{
		vector<double>* cur_misc_energy_set = this->miscloop_dat->at(i_misc_energy_set);
		cur_misc_energy_set->clear();
		delete(cur_misc_energy_set);
	}
	this->miscloop_dat->clear();
	delete(this->miscloop_dat);

	// Free int11 data.
	//this->int11_dat = (double****)malloc(sizeof(double***) * PAIR_ALLOC_SIZE);
	for(int	_outer_pair = AU_pair; _outer_pair <= UG_pair; _outer_pair++)
	{
		//this->int11_dat[_outer_pair] = (double***)malloc(sizeof(double**) * PAIR_ALLOC_SIZE);

		for(int	_inner_pair = AU_pair; _inner_pair <= UG_pair; _inner_pair++)		
		{
			//this->int11_dat[_outer_pair][_inner_pair] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
			{
				//this->int11_dat[_outer_pair][_inner_pair][_fp_nuc] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				//for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
				//{
				//	// Do not include the special loop bonuses for these nucleotides.
				//	this->int11_dat[_outer_pair][_inner_pair][_fp_nuc][_tp_nuc] = ZERO;
				//}

				free(this->int11_dat[_outer_pair][_inner_pair][_fp_nuc]);
			} // Allocation loop fp_nuc

			free(this->int11_dat[_outer_pair][_inner_pair]);
		} // Allocation loop innter_pair

		free(this->int11_dat[_outer_pair]);
	} // Allocation loop outer_pair
	free(this->int11_dat);

	// Free int21 data.
	//this->int21_dat = (double*****)malloc(sizeof(double****) * PAIR_ALLOC_SIZE);
	for(int	_outer_pair = AU_pair; _outer_pair <= UG_pair; _outer_pair++)
	{
		//this->int21_dat[_outer_pair] = (double****)malloc(sizeof(double***) * PAIR_ALLOC_SIZE);

		for(int	_inner_pair = AU_pair; _inner_pair <= UG_pair; _inner_pair++)
		{
			//this->int21_dat[_outer_pair][_inner_pair] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

			for(int	_fp_side_fp_nuc = BASE_X; _fp_side_fp_nuc <= BASE_I; _fp_side_fp_nuc++)
			{
				//this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

				for(int	_fp_side_tp_nuc = BASE_X; _fp_side_tp_nuc <= BASE_I; _fp_side_tp_nuc++)
				{
					//this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc][_fp_side_tp_nuc] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

					//for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
					//{
					//	this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc][_fp_side_tp_nuc][_tp_nuc] = ZERO;
					//}

					free(this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc][_fp_side_tp_nuc]);
				}

				free(this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc]);
			} // Allocation loop fp_nuc

			free(this->int21_dat[_outer_pair][_inner_pair]);
		} // Allocation loop innter_pair

		free(this->int21_dat[_outer_pair]);
	} // Allocation loop outer_pair
	free(this->int21_dat);

	// Free int22 data.
	//this->int22_dat = (double****)malloc(sizeof(double***) * PAIR_ALLOC_SIZE);
	for(int	_outer_pair = int22_AU_pair; _outer_pair <= int22_UG_pair; _outer_pair++)
	{
		//this->int22_dat[_outer_pair] = (double***)malloc(sizeof(double**) * PAIR_ALLOC_SIZE);

		for(int _inner_pair = int22_AU_pair; _inner_pair <= int22_UG_pair; _inner_pair++)
		{
			//this->int22_dat[_outer_pair][_inner_pair] = (double**)malloc(sizeof(double*) * 18);

			for(int	_outer_mm = AA_mm; _outer_mm <= UU_mm; _outer_mm++)
			{
				//this->int22_dat[_outer_pair][_inner_pair][_outer_mm] = (double*)malloc(sizeof(double) * 18);
				//for(int _inner_mm = AA_mm; _inner_mm <= UU_mm; _inner_mm++)
				//{
				//	this->int22_dat[_outer_pair][_inner_pair][_outer_mm][_inner_mm] = ZERO;
				//}

				free(this->int22_dat[_outer_pair][_inner_pair][_outer_mm]);
			} // Allocation loop fp_nuc
			free(this->int22_dat[_outer_pair][_inner_pair]);
		} // Allocation loop innter_pair
		free(this->int22_dat[_outer_pair]);
	} // Allocation loop outer_pair
	free(this->int22_dat);

	// Free dangle data.
	//this->fp_dangle_dat = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);
	for(int	_fp_pair = BASE_X; _fp_pair <= BASE_I; _fp_pair++)
	{
		//this->fp_dangle_dat[_fp_pair] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

		for(int	_tp_pair = BASE_X; _tp_pair <= BASE_I; _tp_pair++)
		{
			//this->fp_dangle_dat[_fp_pair][_tp_pair] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);
					
			//for(int __tp_dangle = BASE_X; __tp_dangle <= BASE_I; __tp_dangle++)
			//{
			//	this->fp_dangle_dat[_fp_pair][_tp_pair][__tp_dangle] = CONVERT_FROM_LIN(1.0f);
			//}

			free(this->fp_dangle_dat[_fp_pair][_tp_pair]);
		} // tp_pair alloc loop.
		free(this->fp_dangle_dat[_fp_pair]);
	} // fp_pair alloc loop.
	free(this->fp_dangle_dat);

	//this->tp_dangle_dat = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);
	for(int	__fp_pair = BASE_X; __fp_pair <= BASE_I; __fp_pair++)
	{
		//this->tp_dangle_dat[__fp_pair] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

		for(int	__tp_pair = BASE_X; __tp_pair <= BASE_I; __tp_pair++)
		{
			//this->tp_dangle_dat[__fp_pair][__tp_pair] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);
			//for(int ___fp_dangle = BASE_X; ___fp_dangle <= BASE_I; ___fp_dangle++)
			//{
			//	this->tp_dangle_dat[__fp_pair][__tp_pair][___fp_dangle] = CONVERT_FROM_LIN(1.0f);
			//}

			free(this->tp_dangle_dat[__fp_pair][__tp_pair]);
		} // tp_pair alloc loop.
		free(this->tp_dangle_dat[__fp_pair]);
	} // fp_pair alloc loop.
	free(this->tp_dangle_dat);

	// Free coaxial data.
	//this->coaxial_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->coaxial_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->coaxial_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->coaxial_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->coaxial_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				//}

				free(this->coaxial_dat[_fp_nuc][_tp_nuc][_fp_stacker]);

			}
			free(this->coaxial_dat[_fp_nuc][_tp_nuc]);
		}

		free(this->coaxial_dat[_fp_nuc]);
	}
	free(this->coaxial_dat);

	// Free coaxstack data.
	//this->coaxstack_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->coaxstack_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->coaxstack_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->coaxstack_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->coaxstack_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				//}
				free(this->coaxstack_dat[_fp_nuc][_tp_nuc][_fp_stacker]);
			}
			free(this->coaxstack_dat[_fp_nuc][_tp_nuc]);
		}
		free(this->coaxstack_dat[_fp_nuc]);
	}
	free(this->coaxstack_dat);

	// Free tstackcoax data.
	// Allocate stack data structure.
	//this->tstackcoax_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		//this->tstackcoax_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			//this->tstackcoax_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				//this->tstackcoax_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);
				//for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				//{
				//	this->tstackcoax_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				//}

				free(this->tstackcoax_dat[_fp_nuc][_tp_nuc][_fp_stacker]);
			}
			free(this->tstackcoax_dat[_fp_nuc][_tp_nuc]);
		}
		free(this->tstackcoax_dat[_fp_nuc]);
	}
	free(this->tstackcoax_dat);
}

// loop.dat includes the size dependent loop energies for loops from size 1 to 30.
// the data structure that holds loop energies can be indexed as: loop_dat[loop_type][loop_size]
// where loop type is from 1 to 3, loop size is from 1 to 30.
void t_thermo_parameters::load_loop()
{
	char loop_dat_fp[1000];
	sprintf(loop_dat_fp, "%s/loop.dat", this->thermo_data_dir);
	FILE* f_loop_dat = open_f(loop_dat_fp, "r");

	// Allocate loop data structure.
	this->loop_dat = (double**)malloc(sizeof(double*) * 4);
	for(int i = 0; i < 3; i++)
	{
		this->loop_dat[i] = (double*)malloc(sizeof(double) * 35);
	}

	// Read the first string in the file until "------------------------".
	char line_buf[1000];
	while(fscanf(f_loop_dat, "%s", line_buf) != EOF)
	{
		line_buf[5] = 0;

if(DUMP_THERMO_PARAMETERS_MESSAGES)
		printf("%s\n", line_buf);

		if(strcmp(line_buf, "-----") == 0)
		{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
			printf("Found data!\n");

			break;
		}
	}

	// The file pointer is at the data right now.
	while(1)
	{
		int n_loop;
		char internal_energy_str[10];
		char bulge_energy_str[10];
		char hairpin_energy_str[10];
		int ret = fscanf(f_loop_dat, "%d %s %s %s", &n_loop, internal_energy_str, bulge_energy_str, hairpin_energy_str);

		if(ret == EOF)
		{
			break;
		}
		else if(ret == 4)
		{
			// Check the ZERO conditions.
			if(strcmp(internal_energy_str, ".") == 0)
			{
				this->loop_dat[INTERIOR_LOOP][n_loop] = ZERO;
			}
			else
			{
				this->loop_dat[INTERIOR_LOOP][n_loop] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(internal_energy_str));
			}

			if(strcmp(bulge_energy_str, ".") == 0)
			{
				this->loop_dat[BULGE_LOOP][n_loop] = ZERO;
			}
			else
			{
				this->loop_dat[BULGE_LOOP][n_loop] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(bulge_energy_str));
			}

			if(strcmp(hairpin_energy_str, ".") == 0)
			{				
				this->loop_dat[HAIRPIN_LOOP][n_loop] = ZERO;
			}
			else
			{
				this->loop_dat[HAIRPIN_LOOP][n_loop] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(hairpin_energy_str));
			}
		}
		else if(ret != 4)
		{
			printf("Problem while loading loop.dat\n");
			exit(0);
		}
	}

	fclose(f_loop_dat);

	// Dump the loop energies..
if(DUMP_THERMO_PARAMETERS_MESSAGES)
{
	for(int n_loop = 1; n_loop <= 30; n_loop++)
	{
		for(int i_loop = 0; i_loop < 3; i_loop++)
		{
			printf("%f ", this->loop_dat[i_loop][n_loop]);
		}
		printf("\n");
	}
}
}

// tstackh includes the stacking thermodynamic parameters for terminal mismatches
// for hairpin loops. The data structure that stores tstackh parameters is as following:
// tstackh_dat[5' pair][3' pair][5' stacker][3' stacker]
void t_thermo_parameters::load_tstackh()
{
	char tstackh_dat_fp[1000];
	sprintf(tstackh_dat_fp, "%s/tstackh.dat", this->thermo_data_dir);
	FILE* f_tstackh_dat = open_f(tstackh_dat_fp, "r");

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading tstackh\n");

	// Allocate tstackh data structure.
	this->tstackh_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->tstackh_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->tstackh_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->tstackh_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				// Init all to 0.
				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->tstackh_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				}
			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_tstackh_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)	
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_tstackh_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->tstackh_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->tstackh_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
					}
				} // fp_stacker loop.
			} // tp_pair loop.

		} // Read 16 thermodynamic data.

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_tstackh_dat);
}

void t_thermo_parameters::load_triloop()
{
	char triloop_dat_fp[1000];
	sprintf(triloop_dat_fp, "%s/triloop.dat", this->thermo_data_dir);
	FILE* f_triloop_dat = open_f(triloop_dat_fp, "r");

	// Read the file and stop at -------------.
if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading triloop\n");

	char line_buf[1000];
	while(fscanf(f_triloop_dat, "%s", line_buf) != EOF)
	{
		line_buf[5] = 0;
		//printf("%s\n", line_buf);
		if(strcmp(line_buf, "-----") == 0)
		{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
			printf("Found triloop data!\n");

			break;
		}
	}

	// Start reading triloops and energies.
	this->triloops = new vector<char*>();
	this->triloop_energies = new vector<double>();
	this->triloop_hashes = new vector<int>();
	
	double cur_triloop_energy;
	char cur_triloop[1000];
	while(1)
	{		
		int ret = fscanf(f_triloop_dat, "%s %lf", cur_triloop, &cur_triloop_energy);

		if(ret == 2)
		{
			char* triloop_str = (char*)malloc(sizeof(char) * (strlen(cur_triloop) + 2));
			strcpy(triloop_str, cur_triloop);

			this->triloops->push_back(triloop_str);
			this->triloop_energies->push_back(CONVERT_FROM_LOG(NEG_OVER_RT * cur_triloop_energy));
			this->triloop_hashes->push_back(this->compute_hp_hash(triloop_str));
		}
		else if(ret == -1)
		{
			// Assuming that file ends while reading the triloops.
			break;
		}
		else
		{
			printf("Could not read triloop.dat\n");
			exit(0);
		}
	}

	// Dump triloops and energies.
if(DUMP_THERMO_PARAMETERS_MESSAGES)
{
	for(int i = 0; i < (int)this->triloops->size(); i++)
	{
		printf("%s(%d) -> %f\n", this->triloops->at(i), this->triloop_hashes->at(i), this->triloop_energies->at(i));
	}
}

	fclose(f_triloop_dat);
}

void t_thermo_parameters::load_hexaloop()
{
	char hexaloop_dat_fp[1000];
	sprintf(hexaloop_dat_fp, "%s/hexaloop.dat", this->thermo_data_dir);
	FILE* f_hexaloop_dat = open_f(hexaloop_dat_fp, "r");

	// Read the file and stop at -------------.
if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading hexaloop\n");

	char line_buf[1000];
	while(fscanf(f_hexaloop_dat, "%s", line_buf) != EOF)
	{
		line_buf[5] = 0;
		//printf("%s\n", line_buf);
		if(strcmp(line_buf, "-----") == 0)
		{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
			printf("Found hexaloop data!\n");

			break;
		}
	}

	// Start reading triloops and energies.
	this->hexaloops = new vector<char*>();
	this->hexaloop_energies = new vector<double>();
	this->hexaloop_hashes = new vector<int>();
	
	double cur_hexa_loop_energy;
	char cur_hexa_loop[1000];
	while(1)
	{		
		int ret = fscanf(f_hexaloop_dat, "%s %lf", cur_hexa_loop, &cur_hexa_loop_energy);

		if(ret == 2)
		{
			char* hexa_loop_str = (char*)malloc(sizeof(char) * (strlen(cur_hexa_loop) + 2));
			strcpy(hexa_loop_str, cur_hexa_loop);

			this->hexaloops->push_back(hexa_loop_str);
			this->hexaloop_energies->push_back(CONVERT_FROM_LOG(NEG_OVER_RT * cur_hexa_loop_energy));
			this->hexaloop_hashes->push_back(this->compute_hp_hash(hexa_loop_str));
		}
		else if(ret == -1)
		{
			// Assuming that file ends while reading the triloops.
			break;
		}
		else
		{
			printf("Could not read hexaloop.dat\n");
			exit(0);
		}
	}

	// Dump triloops and energies.
if(DUMP_THERMO_PARAMETERS_MESSAGES)
{
	for(int i = 0; i < (int)this->hexaloops->size(); i++)
	{
		printf("%s(%d) -> %f\n", this->hexaloops->at(i), this->hexaloop_hashes->at(i), this->hexaloop_energies->at(i));
	}
}

	fclose(f_hexaloop_dat);
}


void t_thermo_parameters::load_tloop()
{
	char tloop_dat_fp[1000];
	sprintf(tloop_dat_fp, "%s/tloop.dat", this->thermo_data_dir);
	FILE* f_tloop_dat = open_f(tloop_dat_fp, "r");


	// Read the file and stop at -------------.
if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading tloop\n");

	char line_buf[1000];
	while(fscanf(f_tloop_dat, "%s", line_buf) != EOF)
	{
		line_buf[5] = 0;
		//printf("%s\n", line_buf);
		if(strcmp(line_buf, "-----") == 0)
		{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
			printf("Found tloop data!\n");

			break;
		}
	}

	// Start reading triloops and energies.
	this->tetra_loops = new vector<char*>();
	this->tetra_loops_energies = new vector<double>();
	this->tetra_loop_hashes = new vector<int>();
	
	double cur_tetra_loop_energy;
	char cur_tetra_loop[1000];
	while(1)
	{		
		int ret = fscanf(f_tloop_dat, "%s %lf", cur_tetra_loop, &cur_tetra_loop_energy);

		if(ret == 2)
		{
			char* tetra_loop_str = (char*)malloc(sizeof(char) * (strlen(cur_tetra_loop) + 2));
			strcpy(tetra_loop_str, cur_tetra_loop);

			this->tetra_loops->push_back(tetra_loop_str);
			this->tetra_loops_energies->push_back(CONVERT_FROM_LOG(NEG_OVER_RT * cur_tetra_loop_energy));
			this->tetra_loop_hashes->push_back(this->compute_hp_hash(tetra_loop_str));
		}
		else if(ret == -1)
		{
			// Assuming that file ends while reading the triloops.
			break;
		}
		else
		{
			printf("Could not read tloop.dat\n");
			exit(0);
		}
	}

	// Dump triloops and energies.
if(DUMP_THERMO_PARAMETERS_MESSAGES)
{
	for(int i = 0; i < (int)this->tetra_loops->size(); i++)
	{
		printf("%s(%d) -> %f\n", this->tetra_loops->at(i), this->tetra_loop_hashes->at(i), this->tetra_loops_energies->at(i));
	}
}

	fclose(f_tloop_dat);
}

int t_thermo_parameters::compute_hp_hash(char* loop_nucs)
{
	int hash = 0;
	int base = 1;
	for(int cnt = (int)strlen(loop_nucs) - 1; cnt >= 0; cnt--)
	{
		int cur_nuc_num = this->base2num(loop_nucs[cnt]);
		hash += (cur_nuc_num * base);
		base = base * 5;
	}

	return(hash);
}

// Compute int value corresponding to nuc sequence from i to j in base 5.
int t_thermo_parameters::compute_hp_hash(int i, int j)
{
	int hash = 0;
	int base = 1;
	for(int cnt = j; cnt >= i; cnt--)
	{
		hash += (this->rna_seq->numseq[cnt] * base);
		base = base * 5;
	}

	return(hash);
}

void t_thermo_parameters::load_miscloop()
{
	char miscloop_dat_fp[1000];
	sprintf(miscloop_dat_fp, "%s/miscloop.dat", this->thermo_data_dir);
	FILE* f_miscloop_dat = open_f(miscloop_dat_fp, "r");


	// Create the vector of misc loop parameters.
	this->miscloop_dat = new vector<vector<double>*>();
	
if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading miscloop\n");

	while(1)
	{
		// Read the file and stop at -->
		char line_buf[1000];
		char marker_buf[1000];

		// Initialization is necessary for making sure iterations do not mess up.
		marker_buf[0] = 0;

		// File ends in this loop.
		char* ret = NULL;
		while(1)
		{
			ret = (char*)fgets(line_buf, 1000, f_miscloop_dat);
			if(ret == NULL)
			{
				break;
			}

			sscanf(line_buf, "%s", marker_buf);

			//printf("%s\n", marker_buf);
			if(strcmp(marker_buf, "-->") == 0)
			{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
				printf("Found miscloop data!\n");

				// Create a new vector in misc loop parameters dataset.
				this->miscloop_dat->push_back(new vector<double>());
				break;
			}
		}

		// If EOF or error, break!
		if(ret == NULL)
		{
			break;
		}

		// Now at the data, this is a little tricky because it is required to read as many as 4 different parameters
		// in this line.
		fgets(line_buf, 1000, f_miscloop_dat);
		//printf("%s\n", line_buf);
		double pars[5];

		int n_pars_read = sscanf(line_buf, "%lf %lf %lf %lf", &pars[0], &pars[1], &pars[2], &pars[3]);

		//printf("sscanf'ed %d parameters.\n", ret);
		for(int i = 0; i < n_pars_read; i++)
		{
			//printf("%f ", pars[i]);

			// Add all these parameters.
			//printf("Pushing: %lf\n", CONVERT_FROM_LOG(NEG_OVER_RT * pars[i]));
			this->miscloop_dat->back()->push_back(pars[i]);
		}
	} // file reading loop. 

	//printf("\n%f\n", this->miscloop_dat->at(2)->at(3));

	// large_loop_scale term is not converted from log domain because it is not an energy term,
	// it helps extrapolate loop sizes greater than 30.

	this->large_loop_scale = this->miscloop_dat->at(0)->at(0);

	this->max_asym_penalty = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(1)->at(0));
	this->poppen[1] = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(2)->at(0));
	this->poppen[2] = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(2)->at(1));
	this->poppen[3] = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(2)->at(2));
	this->poppen[4] = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(2)->at(3));
	this->MBL_closure_penalty = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(3)->at(0));
	this->unpaired_nuc_in_MBL_penalty = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(3)->at(1));
	this->per_helix_penalty = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(3)->at(2));
	this->terminal_AU_penalty = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(7)->at(0));
	this->GGG_loop_bonus = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(8)->at(0));
	this->C_hp_slope = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(9)->at(0));
	this->C_hp_intercept = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(10)->at(0));
	this->C3_hp_bonus = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(11)->at(0));
	this->single_C_bulge = CONVERT_FROM_LOG(NEG_OVER_RT * this->miscloop_dat->at(13)->at(0));

	fclose(f_miscloop_dat);
}

void t_thermo_parameters::load_int11()
{
	char int11_dat_fp[1000];
	sprintf(int11_dat_fp, "%s/int11.dat", this->thermo_data_dir);
	FILE* f_int11_dat = open_f(int11_dat_fp, "r");

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading int11\n");

	// Allocate tstackh data structure.
	/*
	int11_dat[outer_pair_index][inner_pair_index][5' nuc in internal loop][3' nuc in internal loop]
	*/
	this->int11_dat = (double****)malloc(sizeof(double***) * PAIR_ALLOC_SIZE);
	for(int	_outer_pair = AU_pair; _outer_pair <= UG_pair; _outer_pair++)
	{
		this->int11_dat[_outer_pair] = (double***)malloc(sizeof(double**) * PAIR_ALLOC_SIZE);

		for(int	_inner_pair = AU_pair; _inner_pair <= UG_pair; _inner_pair++)		
		{
			this->int11_dat[_outer_pair][_inner_pair] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
			{
				this->int11_dat[_outer_pair][_inner_pair][_fp_nuc] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
				{
					// Do not include the special loop bonuses for these nucleotides.
					this->int11_dat[_outer_pair][_inner_pair][_fp_nuc][_tp_nuc] = ZERO;
				}
			} // Allocation loop fp_nuc
		} // Allocation loop innter_pair
	} // Allocation loop outer_pair

	// Read the Data arrangement stuff to skip it.

	char line_buf[1000];
	while(fgets(line_buf, 1000, f_int11_dat) != NULL)
	{
		//printf("%s\n", line_buf);
		// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
		char first_string[1000];
		char second_string[1000];
		char third_string[1000];
		int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

		if(ret == 3)
		{
			//printf("%s %s %s", first_string, second_string, third_string);

			if(strcmp(first_string, "3'") == 0 &&
				strcmp(second_string, "<--") == 0 &&
				strcmp(third_string, "5'") == 0)
			{
//if(DUMP_THERMO_PARAMETERS_MESSAGES)
//				printf("Found data in int11 for outer_pair %d\n", outer_pair);

				break;
			}
		}
	} // Find the next data block.

	// Read the file.
	int outer_pair = AU_pair;
	while(outer_pair <= UG_pair)
	{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
		printf("Reading for outer_pair = %d\n", outer_pair);

		// Read file.
		while(fgets(line_buf, 1000, f_int11_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data in int11 for outer_pair %d\n", outer_pair);

					break;
				}
			}
		} // Find the next data block.

		// Reading a new block of data for current outer_pair.
		// Each row corresponds to one fp_nuc.
		for(int tp_nuc = BASE_A; tp_nuc <= BASE_U; tp_nuc++)
		{
			for(int inner_pair = AU_pair; inner_pair <= UG_pair; inner_pair++)
			{
				for(int fp_nuc = BASE_A; fp_nuc <= BASE_U; fp_nuc++)
				{
					int ret = fscanf(f_int11_dat, "%s", line_buf);
					if(strcmp(line_buf, ".") == 0)
					{
						this->int11_dat[outer_pair][inner_pair][fp_nuc][tp_nuc] = ZERO;
					}
					else
					{
						this->int11_dat[outer_pair][inner_pair][fp_nuc][tp_nuc] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(line_buf));
						//printf("int11_dat[%d][%d][%d][%d]=%s\n",outer_pair,inner_pair,fp_nuc,tp_nuc,line_buf);
					}

				} // tp_nuc loop.
			} // outer_pair loop.
		} // Read all this data block. 

		// Next block reads next outer_pair.
		outer_pair++;

if(DUMP_THERMO_PARAMETERS_MESSAGES)
		printf("outer_pair is %d\n", outer_pair);

	} // Loop for reading a new block.

	fclose(f_int11_dat);
}

void t_thermo_parameters::load_int21()
{
	char int21_dat_fp[1000];
	sprintf(int21_dat_fp, "%s/int21.dat", this->thermo_data_dir);
	FILE* f_int21_dat = open_f(int21_dat_fp, "r");

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading int21\n");

	// Allocate tstackh data structure.
	/*
	int21_dat[outer_pair_index][inner_pair_index][5p side 5' nuc in internal loop][5' side 3' nuc in internal loop][3' nuc in internal loop]
	*/
	this->int21_dat = (double*****)malloc(sizeof(double****) * PAIR_ALLOC_SIZE);
	for(int	_outer_pair = AU_pair; _outer_pair <= UG_pair; _outer_pair++)
	{
		this->int21_dat[_outer_pair] = (double****)malloc(sizeof(double***) * PAIR_ALLOC_SIZE);

		for(int	_inner_pair = AU_pair; _inner_pair <= UG_pair; _inner_pair++)
		{
			this->int21_dat[_outer_pair][_inner_pair] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

			for(int	_fp_side_fp_nuc = BASE_X; _fp_side_fp_nuc <= BASE_I; _fp_side_fp_nuc++)
			{
				this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

				for(int	_fp_side_tp_nuc = BASE_X; _fp_side_tp_nuc <= BASE_I; _fp_side_tp_nuc++)
				{
					this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc][_fp_side_tp_nuc] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

					for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
					{
						this->int21_dat[_outer_pair][_inner_pair][_fp_side_fp_nuc][_fp_side_tp_nuc][_tp_nuc] = ZERO;
					}
				}
			} // Allocation loop fp_nuc
		} // Allocation loop innter_pair
	} // Allocation loop outer_pair

	// Read the Data arrangement stuff to skip it.
	char line_buf[1000];
	while(fgets(line_buf, 1000, f_int21_dat) != NULL)
	{
		//printf("%s\n", line_buf);
		// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
		char first_string[1000];
		char second_string[1000];
		char third_string[1000];
		int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

		if(ret == 3)
		{
			//printf("%s %s %s", first_string, second_string, third_string);

			if(strcmp(first_string, "3'") == 0 &&
				strcmp(second_string, "<--") == 0 &&
				strcmp(third_string, "5'") == 0)
			{
				break;
			}
		}
	} // Find the next data block.

	// Read the file.
	int outer_pair = AU_pair;
	while(outer_pair <= UG_pair)
	{
		// Read file.
		char line_buf[1000];
		//this->int21_dat[outer_pair][inner_pair][fp_side_fp_nuc][fp_side_tp_nuc][tp_nuc]
		for(int fp_side_tp_nuc = BASE_A; fp_side_tp_nuc <= BASE_U; fp_side_tp_nuc++)
		{
			while(fgets(line_buf, 1000, f_int21_dat) != NULL)
			{
				//printf("%s\n", line_buf);
				// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
				char first_string[1000];
				char second_string[1000];
				char third_string[1000];
				int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

				if(ret == 3)
				{
					//printf("%s %s %s", first_string, second_string, third_string);

					if(strcmp(first_string, "3'") == 0 &&
						strcmp(second_string, "<--") == 0 &&
						strcmp(third_string, "5'") == 0)
					{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
						printf("Found data!\n");

						break;
					}
				}
			} // Find the next data block.

			// Reading a new block of data for current inner_pair.
			// Each row corresponds to one fp_nuc.

			for(int tp_nuc = BASE_A; tp_nuc <= BASE_U; tp_nuc++)
			{
				for(int inner_pair = AU_pair; inner_pair <= UG_pair; inner_pair++)
				{
					for(int fp_side_fp_nuc = BASE_A; fp_side_fp_nuc <= BASE_U; fp_side_fp_nuc++)
					{
						int ret = fscanf(f_int21_dat, "%s", line_buf);
						if(strcmp(line_buf, ".") == 0)
						{
							this->int21_dat[outer_pair][inner_pair][fp_side_fp_nuc][fp_side_tp_nuc][tp_nuc] = ZERO;
						}
						else
						{
							this->int21_dat[outer_pair][inner_pair][fp_side_fp_nuc][fp_side_tp_nuc][tp_nuc] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(line_buf));
						}
					}
				} // outer_pair loop.
			} // fp_side_nuc loop.
		} // tp_side_fp_nuc loop.

		// Next block reads next outer_pair.
		outer_pair++;

	} // Loop for reading a new block.

	fclose(f_int21_dat);
}

void t_thermo_parameters::load_int22()
{
	char int22_dat_fp[1000];
	sprintf(int22_dat_fp, "%s/int22.dat", this->thermo_data_dir);
	FILE* f_int22_dat = open_f(int22_dat_fp, "r");


if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading int22\n");

	// Allocate tstackh data structure.
	/*
	int22_dat[outer_pair_index][inner_pair_index][outer_mismatched_pair_index][inner_mismatched_pair_index]
	*/
	this->int22_dat = (double****)malloc(sizeof(double***) * PAIR_ALLOC_SIZE);
	for(int	_outer_pair = int22_AU_pair; _outer_pair <= int22_UG_pair; _outer_pair++)
	{
		this->int22_dat[_outer_pair] = (double***)malloc(sizeof(double**) * PAIR_ALLOC_SIZE);

		for(int _inner_pair = int22_AU_pair; _inner_pair <= int22_UG_pair; _inner_pair++)
		{
			this->int22_dat[_outer_pair][_inner_pair] = (double**)malloc(sizeof(double*) * 18);

			for(int	_outer_mm = AA_mm; _outer_mm <= UU_mm; _outer_mm++)
			{
				this->int22_dat[_outer_pair][_inner_pair][_outer_mm] = (double*)malloc(sizeof(double) * 18);

				for(int _inner_mm = AA_mm; _inner_mm <= UU_mm; _inner_mm++)
				{
					this->int22_dat[_outer_pair][_inner_pair][_outer_mm][_inner_mm] = ZERO;
				}
			} // Allocation loop fp_nuc
		} // Allocation loop innter_pair
	} // Allocation loop outer_pair


	// Read the first data arrangement block to skip it.
	char line_buf[1000];
	while(fgets(line_buf, 1000, f_int22_dat) != NULL)
	{
		//printf("%s\n", line_buf);
		// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
		char first_string[1000];
		char second_string[1000];
		char third_string[1000];
		int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

		if(ret == 3)
		{
			//printf("%s %s %s", first_string, second_string, third_string);

			if(strcmp(first_string, "3'") == 0 &&
				strcmp(second_string, "<------") == 0 &&
				strcmp(third_string, "5'") == 0)
			{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
				printf("Found data!\n");

				break;
			}
		}
	} // Find the next data block.


	// Read the file.
	int outer_pair = int22_AU_pair;
	while(outer_pair <= int22_UG_pair)
	{
		// Read file.
		for(int inner_pair = int22_AU_pair; inner_pair <= int22_UG_pair; inner_pair++)
		{
			while(fgets(line_buf, 1000, f_int22_dat) != NULL)
			{
				//printf("%s\n", line_buf);
				// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
				char first_string[1000];
				char second_string[1000];
				char third_string[1000];
				int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

				if(ret == 3)
				{
					//printf("%s %s %s", first_string, second_string, third_string);

					if(strcmp(first_string, "3'") == 0 &&
						strcmp(second_string, "<------") == 0 &&
						strcmp(third_string, "5'") == 0)
					{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
						printf("Found data!\n");

						break;
					}
				}
			} // Find the next data block.

			// Read current 2x2 parameters table for current inner and outer pairs closing interior loop.
			for(int outer_mm = AA_mm; outer_mm <= UU_mm; outer_mm++)
			{
				for(int inner_mm = AA_mm; inner_mm <= UU_mm; inner_mm++)
				{
					int ret = fscanf(f_int22_dat, "%s", line_buf);
					if(strcmp(line_buf, ".") == 0)
					{
						this->int22_dat[outer_pair][inner_pair][outer_mm][inner_mm] = ZERO;
					}
					else
					{
						this->int22_dat[outer_pair][inner_pair][outer_mm][inner_mm] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(line_buf));
					}
				} // tp_mm loop.
			} // fp_mm loop.
		} // inner_pair loop.

		outer_pair++;
	} // outer_pair loop. 

	fclose(f_int22_dat);
}

void t_thermo_parameters::load_dangle()
{
	char dangle_dat_fp[1000];
	sprintf(dangle_dat_fp, "%s/dangle.dat", this->thermo_data_dir);
	FILE* f_dangle_dat = open_f(dangle_dat_fp, "r");


if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading dangle_fp\n");

	/*
	dangle_dat[fp_pair][tp_pair][3p dangle]
	*/
	this->fp_dangle_dat = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);
	for(int	_fp_pair = BASE_X; _fp_pair <= BASE_I; _fp_pair++)
	{
		this->fp_dangle_dat[_fp_pair] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

		for(int	_tp_pair = BASE_X; _tp_pair <= BASE_I; _tp_pair++)
		{
			this->fp_dangle_dat[_fp_pair][_tp_pair] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);
					
			for(int __tp_dangle = BASE_X; __tp_dangle <= BASE_I; __tp_dangle++)
			{
				this->fp_dangle_dat[_fp_pair][_tp_pair][__tp_dangle] = CONVERT_FROM_LIN(1.0f);
			}
		} // tp_pair alloc loop.
	} // fp_pair alloc loop.

	this->tp_dangle_dat = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);
	for(int	__fp_pair = BASE_X; __fp_pair <= BASE_I; __fp_pair++)
	{
		this->tp_dangle_dat[__fp_pair] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

		for(int	__tp_pair = BASE_X; __tp_pair <= BASE_I; __tp_pair++)
		{
			this->tp_dangle_dat[__fp_pair][__tp_pair] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

			for(int ___fp_dangle = BASE_X; ___fp_dangle <= BASE_I; ___fp_dangle++)
			{
				this->tp_dangle_dat[__fp_pair][__tp_pair][___fp_dangle] = CONVERT_FROM_LIN(1.0f);
			}
		} // tp_pair alloc loop.
	} // fp_pair alloc loop.

	// Load 3' dangles in dangle.dat.
	for(int ___fp_pair = BASE_A; ___fp_pair <= BASE_U; ___fp_pair++)
	{
		// Read file.
		char line_buf[1000];

		while(fgets(line_buf, 1000, f_dangle_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		} // Find the next data block.

		for(int ___tp_pair = BASE_A; ___tp_pair <= BASE_U; ___tp_pair++)	
		{
			for(int ___tp_dangle = BASE_A; ___tp_dangle <= BASE_U; ___tp_dangle++)
			{
				int ret = fscanf(f_dangle_dat, "%s", line_buf);
				if(strcmp(line_buf, ".") == 0)
				{
					this->tp_dangle_dat[___fp_pair][___tp_pair][___tp_dangle] = ZERO;
				}
				else
				{
					this->tp_dangle_dat[___fp_pair][___tp_pair][___tp_dangle] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(line_buf));
				}
			} // tp_dangle loop
		} // tp_pair loop
	} // fp_pair loop

	// Load 5' dangles in dangle.dat.
	for(int ____fp_pair = BASE_A; ____fp_pair <= BASE_U; ____fp_pair++)
	{
		// Read file.
		char line_buf[1000];

		while(fgets(line_buf, 1000, f_dangle_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		} // Find the next data block.

		for(int ____tp_pair = BASE_A; ____tp_pair <= BASE_U; ____tp_pair++)	
		{
			for(int ____fp_dangle = BASE_A; ____fp_dangle <= BASE_U; ____fp_dangle++)
			{
				int ret = fscanf(f_dangle_dat, "%s", line_buf);
				if(strcmp(line_buf, ".") == 0)
				{
					this->fp_dangle_dat[____fp_pair][____tp_pair][____fp_dangle] = ZERO;
				}
				else
				{
					this->fp_dangle_dat[____fp_pair][____tp_pair][____fp_dangle] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(line_buf));
				}
			} // tp_dangle loop
		} // tp_pair loop
	} // fp_pair loop

	fclose(f_dangle_dat);
}

// tstackm includes the stacking thermodynamic parameters for terminal mismatches
// for MB loops. The data structure that stores tstacki parameters is as following:
// tstackm_dat[5' pair][3' pair][5' stacker][3' stacker]
void t_thermo_parameters::load_tstackm()
{
	char tstackm_dat_fp[1000];
	sprintf(tstackm_dat_fp, "%s/tstackm.dat", this->thermo_data_dir);
	FILE* f_tstackm_dat = open_f(tstackm_dat_fp, "r");


if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading tstackm\n");

	// Allocate tstackm data structure.
	this->tstackm_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->tstackm_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->tstackm_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->tstackm_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->tstackm_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				}
			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_tstackm_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_tstackm_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->tstackm_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->tstackm_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
						//printf("%f\n", this->tstackm_dat[fp_pair][tp_pair][fp_stacker][tp_stacker]);
					}
				} // fp_stacker loop
			} // tp_pair loop
		} // tp_stacker loop

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_tstackm_dat);
}

// tstack includes the stacking thermodynamic parameters for terminal mismatches
// for external loops. The data structure that stores tstacki parameters is as following:
// tstack_dat[5' pair][3' pair][5' stacker][3' stacker]
void t_thermo_parameters::load_tstack()
{
	char tstack_dat_fp[1000];
	sprintf(tstack_dat_fp, "%s/tstack.dat", this->thermo_data_dir);
	FILE* f_tstack_dat = open_f(tstack_dat_fp, "r");
	if(f_tstack_dat == NULL)
	{
		printf("Could not find tstack.dat at %s.\n", tstack_dat_fp);
		exit(0);
	}

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading tstack\n");

	// Allocate tstack data structure.
	this->tstack_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->tstack_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->tstack_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->tstack_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->tstack_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				}

			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_tstack_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_tstack_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->tstack_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->tstack_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
						//printf("%f\n", this->tstack_dat[fp_pair][tp_pair][fp_stacker][tp_stacker]);
					}
				} // fp_stacker loop
			} // tp_pair loop
		} // tp_stacker loop

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_tstack_dat);
}


// tstacki includes the stacking thermodynamic parameters for terminal mismatches
// for internal loops. The data structure that stores tstacki parameters is as following:
// tstacki_dat[5' pair][3' pair][5' stacker][3' stacker]
void t_thermo_parameters::load_tstacki()
{
	char tstacki_dat_fp[1000];
	sprintf(tstacki_dat_fp, "%s/tstacki.dat", this->thermo_data_dir);
	FILE* f_tstacki_dat = open_f(tstacki_dat_fp, "r");


if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading tstacki\n");

	// Allocate tstacki data structure.
	this->tstacki_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->tstacki_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->tstacki_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->tstacki_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->tstacki_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0);
				}
			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_tstacki_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_tstacki_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->tstacki_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->tstacki_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
						//printf("%f\n", this->tstacki_dat[fp_pair][tp_pair][fp_stacker][tp_stacker]);
					}
				} // fp_stacker loop
			} // tp_pair loop
		} // tp_stacker loop

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_tstacki_dat);
}

// tstacki includes the stacking thermodynamic parameters for terminal mismatches
// for internal loops. The data structure that stores tstacki parameters is as following:
// tstacki_dat[5' pair][3' pair][5' stacker][3' stacker]
void t_thermo_parameters::load_tstacki23()
{
	char tstacki23_dat_fp[1000];
	sprintf(tstacki23_dat_fp, "%s/tstacki23.dat", this->thermo_data_dir);
	FILE* f_tstacki23_dat = open_f(tstacki23_dat_fp, "r");


if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading tstacki23\n");

	// Allocate tstacki data structure.
	this->tstacki23_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->tstacki23_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->tstacki23_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->tstacki23_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->tstacki23_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				}
			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_tstacki23_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_tstacki23_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->tstacki23_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->tstacki23_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
						//printf("%f\n", this->tstacki23_dat[fp_pair][tp_pair][fp_stacker][tp_stacker]);
					}
				} // fp_stacker loop
			} // tp_pair loop
		} // tp_stacker loop

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_tstacki23_dat);
}

// tstacki includes the stacking thermodynamic parameters for terminal mismatches
// for internal loops. The data structure that stores tstacki parameters is as following:
// tstacki_dat[5' pair][3' pair][5' stacker][3' stacker]
void t_thermo_parameters::load_tstacki1n()
{
	char tstacki1n_dat_fp[1000];
	sprintf(tstacki1n_dat_fp, "%s/tstacki1n.dat", this->thermo_data_dir);
	FILE* f_tstacki1n_dat = open_f(tstacki1n_dat_fp, "r");

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading tstacki1n\n");

	// Allocate tstacki data structure.
	this->tstacki1n_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->tstacki1n_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->tstacki1n_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->tstacki1n_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->tstacki1n_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);;
				}
			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_tstacki1n_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_tstacki1n_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->tstacki1n_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->tstacki1n_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
						//printf("%f\n", this->tstacki1n_dat[fp_pair][tp_pair][fp_stacker][tp_stacker]);
					}
				} // fp_stacker loop
			} // tp_pair loop
		} // tp_stacker loop

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_tstacki1n_dat);
}

// stack includes the stacking thermodynamic parameters for stacking base pairs.
// The data structure that stores stack parameters is as following:
// stack_dat[5' pair][3' pair][5' stacker][3' stacker]
void t_thermo_parameters::load_stack()
{
	char stack_dat_fp[1000];
	sprintf(stack_dat_fp, "%s/stack.dat", this->thermo_data_dir);
	FILE* f_stack_dat = open_f(stack_dat_fp, "r");
	if(f_stack_dat == NULL)
	{
		printf("Could not find stack.dat at %s.\n", stack_dat_fp);
		exit(0);
	}

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading stack\n");

	// Allocate stack data structure.
	this->stack_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->stack_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->stack_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->stack_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->stack_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				}
			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_stack_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)	
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_stack_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->stack_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->stack_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
					}
				} // fp_stacker loop.
			} // tp_pair loop.

		} // Read 16 thermodynamic data.

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_stack_dat);
	//exit(0);
}

// Coaxial stacking data files below.
// Coaxial Stacking energies of immediately adjacent helices.
void t_thermo_parameters::load_coaxial()
{
	char stack_dat_fp[1000];
	sprintf(stack_dat_fp, "%s/coaxial.dat", this->thermo_data_dir);
	FILE* f_stack_dat = open_f(stack_dat_fp, "r");
	if(f_stack_dat == NULL)
	{
		printf("Could not find stack.dat at %s.\n", stack_dat_fp);
		exit(0);
	}

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading coaxial\n");

	// Allocate stack data structure.
	this->coaxial_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->coaxial_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->coaxial_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->coaxial_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->coaxial_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				}

			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_stack_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)	
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_stack_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->coaxial_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->coaxial_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
					}
				} // fp_stacker loop.
			} // tp_pair loop.

		} // Read 16 thermodynamic data.

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_stack_dat);
}

// Coaxial Stacking energies of helices that are separated by one
// non-canonical base pair.
void t_thermo_parameters::load_tstackcoax()
{
	char stack_dat_fp[1000];
	sprintf(stack_dat_fp, "%s/tstackcoax.dat", this->thermo_data_dir);
	FILE* f_stack_dat = open_f(stack_dat_fp, "r");
	if(f_stack_dat == NULL)
	{
		printf("Could not find stack.dat at %s.\n", stack_dat_fp);
		exit(0);
	}

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading coaxial\n");

	// Allocate stack data structure.
	this->tstackcoax_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->tstackcoax_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->tstackcoax_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->tstackcoax_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->tstackcoax_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				}
			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_stack_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)	
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_stack_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->tstackcoax_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->tstackcoax_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
					}
				} // fp_stacker loop.
			} // tp_pair loop.

		} // Read 16 thermodynamic data.

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_stack_dat);
}

void t_thermo_parameters::load_coaxstack()
{
	char stack_dat_fp[1000];
	sprintf(stack_dat_fp, "%s/coaxstack.dat", this->thermo_data_dir);
	FILE* f_stack_dat = open_f(stack_dat_fp, "r");
	if(f_stack_dat == NULL)
	{
		printf("Could not find stack.dat at %s.\n", stack_dat_fp);
		exit(0);
	}

if(DUMP_THERMO_PARAMETERS_MESSAGES)
	printf("Reading coaxial\n");

	// Allocate stack data structure.
	this->coaxstack_dat = (double****)malloc(sizeof(double***) * BASE_ALLOC_SIZE);
	for(int	_fp_nuc = BASE_X; _fp_nuc <= BASE_I; _fp_nuc++)
	{
		this->coaxstack_dat[_fp_nuc] = (double***)malloc(sizeof(double**) * BASE_ALLOC_SIZE);

		for(int	_tp_nuc = BASE_X; _tp_nuc <= BASE_I; _tp_nuc++)
		{
			this->coaxstack_dat[_fp_nuc][_tp_nuc] = (double**)malloc(sizeof(double*) * BASE_ALLOC_SIZE);

			for(int	_fp_stacker = BASE_X; _fp_stacker <= BASE_I; _fp_stacker++)
			{
				this->coaxstack_dat[_fp_nuc][_tp_nuc][_fp_stacker] = (double*)malloc(sizeof(double) * BASE_ALLOC_SIZE);

				for(int	_tp_stacker = BASE_X; _tp_stacker <= BASE_I; _tp_stacker++)
				{
					this->coaxstack_dat[_fp_nuc][_tp_nuc][_fp_stacker][_tp_stacker] = CONVERT_FROM_LIN(1.0f);
				}
			}
		}
	}

	int fp_pair = BASE_A;
	while(fp_pair <= BASE_U)
	{
		// Read file.
		char line_buf[1000];
		while(fgets(line_buf, 1000, f_stack_dat) != NULL)
		{
			//printf("%s\n", line_buf);
			// Look for "3' <-- 5'" string at a line. The first line that is after this line is data.
			char first_string[1000];
			char second_string[1000];
			char third_string[1000];
			int ret = sscanf(line_buf, "%s %s %s", first_string, second_string, third_string);

			if(ret == 3)
			{
				//printf("%s %s %s", first_string, second_string, third_string);

				if(strcmp(first_string, "3'") == 0 &&
					strcmp(second_string, "<--") == 0 &&
					strcmp(third_string, "5'") == 0)
				{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
					printf("Found data!\n");

					break;
				}
			}
		}

		char stack_thermo_par_str[1000];
		// Now at the data point, read data.
		for(int tp_stacker = BASE_A; tp_stacker <= BASE_U; tp_stacker++)
		{
			for(int tp_pair = BASE_A; tp_pair <= BASE_U; tp_pair++)	
			{
				for(int fp_stacker = BASE_A; fp_stacker <= BASE_U; fp_stacker++)
				{				
					fscanf(f_stack_dat, "%s", stack_thermo_par_str);
					//printf("%s\n", stack_thermo_par_str);
					if(strcmp(stack_thermo_par_str, ".") == 0)
					{
						this->coaxstack_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = ZERO;
					}
					else
					{
						this->coaxstack_dat[fp_pair][tp_pair][fp_stacker][tp_stacker] = CONVERT_FROM_LOG(NEG_OVER_RT * atof(stack_thermo_par_str));
					}
				} // fp_stacker loop.
			} // tp_pair loop.

		} // Read 16 thermodynamic data.

		// Next block of data includes next fp_pair data.
		fp_pair++;

	}// Main file read loop, finds data points of EOF's.

	fclose(f_stack_dat);
}

/*
	<-5'		 3'->
		---------
outer_i			 inner_i
outer_j			 inner_j
		---------
    <-3'		 5'<-
*/
double t_thermo_parameters::interior_energy(int outer_i, int outer_j, int inner_i, int inner_j) // Energy of an interior loop.
{
	// Determine the size and asymmetry.
	int size_fp = abs(inner_i - outer_i) - 1;
	int size_tp = abs(outer_j - inner_j) - 1;
	int size = size_tp + size_fp;
	int asymmetry = abs(size_fp - size_tp);

	// Check if this is a stacked pair.
	if(size_fp == 0 && size_tp == 0)
	{
		printf("A stacked pair is handled in interior energy loops.\n");
		double* p = NULL;
		*p = 0;
		exit(0);
	}

	double SHAPE_energy_of_loop = CONVERT_FROM_LIN(1.0f);

	// Check bulge loop.
	if(size_fp == 0 || size_tp == 0)
	{
		// Size dependent energy for bulge loop.
		double bulge_size_energy = this->loop_energy_by_size(BULGE_LOOP, size);

		// Add terminal penalties for bulges.
		double terminal_pair_penalty = CONVERT_FROM_LIN(1.0f);

		// 0.0 is the non-stacked stacking energy, i.e. w/o stacking.
		double single_bulge_bonuses = CONVERT_FROM_LIN(1.0f);

		// Consider stacking of inner and outer base pairs.
		if(size == 1)
		{
			bulge_size_energy = this->loop_energy_by_size(BULGE_LOOP, size);

			// The stacking bonus comes for bulge loops of size 1 just like stacking of base pair that are closing
			// the bulge loop.
			// Must remove the scaling factors for paired bases coming from stacking energy table since 
			// they must 
			single_bulge_bonuses = DIV(this->bp_stack_energy(outer_i, outer_j, inner_j, inner_i), this->two_scaling_per_nuc);

			// Add the SHAPE contribution for single bulge loops.
			if(this->exp_DG_SHAPE_per_loop != NULL)
			{
				SHAPE_energy_of_loop = MUL4(this->exp_DG_SHAPE_per_nuc[outer_i], 
											this->exp_DG_SHAPE_per_nuc[outer_j],
											this->exp_DG_SHAPE_per_nuc[inner_i],
											this->exp_DG_SHAPE_per_nuc[inner_j]);
			}

			// Check for single C bulge.
			if(size_fp == 1 && (this->rna_seq->numseq[outer_i + 1]==BASE_C &&
				(this->rna_seq->numseq[inner_i]==BASE_C || this->rna_seq->numseq[outer_i]==BASE_C)))
			{
				//printf("fp single c bulge!\n");
				single_bulge_bonuses = MUL(single_bulge_bonuses, this->single_C_bulge);
			}
			else if(size_tp == 1 && (this->rna_seq->numseq[outer_j-1]==BASE_C &&
				(this->rna_seq->numseq[outer_j]==BASE_C || this->rna_seq->numseq[inner_j]==BASE_C)))// size_tp = 1.
			{
				//printf("tp single c bulge!\n");
				single_bulge_bonuses = MUL(single_bulge_bonuses, this->single_C_bulge);
			}

			//printf("Bonus division for single loop: stack + size = %lf + %lf\n", bulge_size_energy, single_bulge_bonuses);

		}
		else
		{ 
			// Size dependent energy for bulge loop.
			bulge_size_energy = this->loop_energy_by_size(BULGE_LOOP, size);

			// Add terminal penalties for bulges.
			terminal_pair_penalty = MUL(this->terminal_pair_penalty(outer_i, outer_j), this->terminal_pair_penalty(inner_i, inner_j));
		}

if(DUMP_THERMO_PARAMETERS_MESSAGES)
		printf("Bulge loop energy at (%d, %d)-(%d, %d) = %.5f + %.5f = %.5f\n", outer_i, outer_j, inner_i, inner_j, bulge_size_energy, single_bulge_bonuses, MUL(bulge_size_energy, single_bulge_bonuses));

		return(MUL4(SHAPE_energy_of_loop,
					bulge_size_energy, 
					single_bulge_bonuses, 
					terminal_pair_penalty));
	} // end bulge loop handling.


	// internal loop is handled below.
	// This includes all the scaling factors for all the nucleotides in the internal loop (including closing bp), no further 
	// scaling is required.
	double interior_size_energy = this->loop_energy_by_size(INTERIOR_LOOP, size);

	if(size > 30)
	{
		if(size_fp == 1 || size_tp == 1)
		{
			// Take the stacking value from stacki1n table.
			double outer_stack_energy = this->interior_stack1n_energy(outer_i, outer_j, outer_j-1, outer_i+1);
			double inner_stack_energy = this->interior_stack1n_energy(inner_j, inner_i, inner_i-1, inner_j+1);

			// compute asymmetry penalty.
			//max(data->maxpen, pow(data->poppen[min(2,min(size1,size2))],lopsid))*
			double asym_penalty = MAX(this->max_asym_penalty, POW(this->poppen[MIN(2, MIN(size_fp, size_tp))], asymmetry));

			return(MUL5(SHAPE_energy_of_loop, 
						inner_stack_energy, 
						outer_stack_energy, 
						interior_size_energy, 
						asym_penalty));
		}
		else
		{
			double outer_stack_energy = this->interior_stack_energy(outer_i, outer_j, outer_j-1, outer_i+1);
			double inner_stack_energy = this->interior_stack_energy(inner_j, inner_i, inner_i-1, inner_j+1);

			double asym_penalty = MAX(this->max_asym_penalty, POW(this->poppen[MIN(2, MIN(size_fp, size_tp))], asymmetry));

			return(MUL5(SHAPE_energy_of_loop, 
						inner_stack_energy, 
						outer_stack_energy, 
						interior_size_energy, 
						asym_penalty));
		}

	}
	else if(size_fp == 2 && size_tp == 2)
	{
		double interior_2x2_energy = this->interior_2x2_loop_energy(outer_i, outer_j, inner_i, inner_j);
		//printf("Computing 2x2\n");
		return(MUL(SHAPE_energy_of_loop, 
				interior_2x2_energy));
	}
	else if(size_fp == 1 && size_tp == 2)
	{
		double interior_2x1_energy = this->interior_2x1_loop_energy(outer_i, outer_j, inner_i, inner_j);
		//printf("Computing 1x2 (%d, %d, %d, %d): %f\n", outer_i, outer_j, inner_i, inner_j, interior_2x1_energy);
		//printf("Computing 1x2\n");
		return(MUL(SHAPE_energy_of_loop, 
					interior_2x1_energy));
	}
	else if(size_fp == 2 && size_tp == 1)
	{
		// this->int21_dat[outer_pair][inner_pair][fp_side_fp_nuc][fp_side_tp_nuc][tp_nuc]
		double interior_2x1_energy = this->interior_2x1_loop_energy(inner_j, inner_i, outer_j, outer_i);
		//printf("Computing 2x1 (%d, %d, %d, %d): %f\n", outer_i, outer_j, inner_i, inner_j, interior_2x1_energy);
		//exit(0);
		return(MUL(SHAPE_energy_of_loop,
					interior_2x1_energy));
	}
	else if(size == 2)
	{
		double interior_1x1_energy = this->interior_1x1_loop_energy(outer_i, outer_j, inner_i, inner_j);
		//printf("Computing 1x1 (%d, %d, %d, %d): %f\n", outer_i, outer_j, inner_i, inner_j, interior_1x1_energy);
		return(MUL(SHAPE_energy_of_loop,
					interior_1x1_energy));
	}
	else if(size_fp == 1 || size_tp == 1)
	{
		//energy = data->tstki1n[ct->numseq[i]][ct->numseq[j]][ct->numseq[i+1]][ct->numseq[j-1]] *
		//		data->tstki1n[ct->numseq[jp]][ct->numseq[ip]][ct->numseq[jp+1]][ct->numseq[ip-1]] *
		//		data->inter[size] * data->eparam[3] *
		//	max(data->maxpen,pow(data->poppen[min(2,min(size1,size2))],lopsid));
		// Take the stacking value from stacki1n table.
		double outer_stack_energy = this->interior_stack1n_energy(outer_i, outer_j, outer_j-1, outer_i+1);
		double inner_stack_energy = this->interior_stack1n_energy(inner_j, inner_i, inner_i-1, inner_j+1);

		double asym_penalty = MAX(this->max_asym_penalty, POW(this->poppen[MIN(2, MIN(size_fp, size_tp))], asymmetry));

		return(MUL5(SHAPE_energy_of_loop, 
					inner_stack_energy, 
					outer_stack_energy, 
					interior_size_energy, 
					asym_penalty));
	}
	else if((size_fp == 2 && size_tp == 3) || (size_fp == 3 && size_tp == 2))
	{
		//energy = data->tstki23[ct->numseq[i]][ct->numseq[j]][ct->numseq[i+1]][ct->numseq[j-1]] *
		//data->tstki23[ct->numseq[jp]][ct->numseq[ip]][ct->numseq[jp+1]][ct->numseq[ip-1]] *
		//data->inter[size] * data->eparam[3] *
		//max(data->maxpen,pow(data->poppen[min(2,min(size1,size2))],lopsid));
		double outer_stack_energy = this->interior_stack23_energy(outer_i, outer_j, outer_j-1, outer_i+1);
		double inner_stack_energy = this->interior_stack23_energy(inner_j, inner_i, inner_i-1, inner_j+1);

		double asym_penalty = MAX(this->max_asym_penalty, POW(this->poppen[MIN(2, MIN(size_fp, size_tp))], asymmetry));

		//printf("Computing 3x2 (%d, %d, %d, %d)\n", outer_i, outer_j, inner_i, inner_j);

		return(MUL5(SHAPE_energy_of_loop, 
				inner_stack_energy, 
				outer_stack_energy, 
				interior_size_energy, 
				asym_penalty));
	}
	else
	{
		//energy = data->tstki[ct->numseq[i]][ct->numseq[j]][ct->numseq[i+1]][ct->numseq[j-1]] *
		//data->tstki[ct->numseq[jp]][ct->numseq[ip]][ct->numseq[jp+1]][ct->numseq[ip-1]] *
		//data->inter[size] * data->eparam[3] *
		//max(data->maxpen,pow(data->poppen[min(2,min(size1,size2))],lopsid));
		double outer_stack_energy = this->interior_stack_energy(outer_i, outer_j, outer_j-1, outer_i+1);
		double inner_stack_energy = this->interior_stack_energy(inner_j, inner_i, inner_i-1, inner_j+1);

		double asym_penalty = MAX(this->max_asym_penalty, POW(this->poppen[MIN(2, MIN(size_fp, size_tp))], asymmetry));

		return(MUL5(SHAPE_energy_of_loop, 
					inner_stack_energy, 
					outer_stack_energy, 
					interior_size_energy, 
					asym_penalty));
	}
}

double t_thermo_parameters::mm_stack_coax_helix_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker)
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	return(this->tstackcoax_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc]);
}

double t_thermo_parameters::perfect_coaxial_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker)
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	return(this->coaxial_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc]);
}

double t_thermo_parameters::imperfect_coaxial_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker)
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	return(this->coaxstack_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc]);
}

/*
Compute the coaxial stacking energy such that there are stacking of i, ip and ip+1, j.
Stacking scenario is as following:
... -ip-(ip+1)-(ip+1)...
...  |   |
... -i   j    -(j-1) ...
*/
double t_thermo_parameters::coaxial_stacking_energy(int i, int ip, int j)
{
	if(ip > i && ip > j)
	{
		printf("coaxial stack energy computation is called for indices %d, %d, %d at %s(%d)\n", i,j,ip, __FILE__, __LINE__);
		exit(0);
	}

	// Consider all 3 cases of stacking and return max/sum energy.
	double perfect_stacking_energy = this->perfect_coaxial_stack_energy(ip, i, ip+1, j);

	// One of the imperfect coax. stacking is by noncanonical pairing of i and ip.
	double stack_i_ip_in_coax_stack_energy = ZERO;
	double energy_imperfect_coaxial_stack1 = ZERO;
	if(ip+1 <= this->rna_seq->numofbases)
	{
		energy_imperfect_coaxial_stack1 = this->imperfect_coaxial_stack_energy(ip, i, ip+1, j);

		if(ip - 1 > 1 && i > 1)
		{
			stack_i_ip_in_coax_stack_energy = this->mm_stack_coax_helix_energy(ip-1, i-1, ip+1, j);
		}
	}

	double imperfect_stacking_energy1 = MUL(stack_i_ip_in_coax_stack_energy, energy_imperfect_coaxial_stack1);

	// Other imperfect stacking is by noncanonical pairing of ip+1 and j.
	double stack_ipp_j_in_coax_stack_energy = ZERO;
	double energy_imperfect_coaxial_stack2 = ZERO;

	if(j - 1 <= ip + 2)
	{
		printf("ERROR at %s(%d)\n", __FILE__, __LINE__);
		exit(0);
	}

	if(ip+2 <= this->rna_seq->numofbases)
	{
		energy_imperfect_coaxial_stack2 = this->imperfect_coaxial_stack_energy(j, ip+1, i, ip);

		stack_ipp_j_in_coax_stack_energy = this->mm_stack_coax_helix_energy(j-1, ip+2, j, ip+1);		
	}

	double imperfect_stacking_energy2 = MUL(stack_ipp_j_in_coax_stack_energy, energy_imperfect_coaxial_stack2);

	// Compute final stacking energy and return it.
	double stacking_energy = perfect_stacking_energy;
	stacking_energy = this->MAX_SUM(stacking_energy, imperfect_stacking_energy1);
	stacking_energy = this->MAX_SUM(stacking_energy, imperfect_stacking_energy2);

	return(stacking_energy);
}

/*
5' -> 3'
i - (i+1) .. 
|           
j - (j-1) ..
3' <- 5'
*/
double t_thermo_parameters::hairpin_energy(int outer_i, int outer_j)
{
	// Handle the distinguished loops first.
	int size = outer_j - outer_i - 1;
	if(size == 3)
	{
		int current_hash = this->compute_hp_hash(outer_i, outer_j);

		// Search triloop hashes.
		for(int cnt = 0; cnt < (int)this->triloop_hashes->size(); cnt++)
		{			
			if(this->triloop_hashes->at(cnt) == current_hash)
			{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
				printf("Found a distinguished triloop: %s\n", this->triloops->at(cnt));

				return(this->triloop_energies->at(cnt));
			}
		}
	}
	else if(size == 4)
	{
		int current_hash = this->compute_hp_hash(outer_i, outer_j);

		// Search triloop hashes.
		for(int cnt = 0; cnt < (int)this->tetra_loop_hashes->size(); cnt++)
		{
			//printf("%d: %d\n", current_hash, this->tetra_loop_hashes->at(cnt));
			if(this->tetra_loop_hashes->at(cnt) == current_hash)
			{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
				printf("Found a distinguished tetraloop: %s\n", this->tetra_loops->at(cnt));
				return(this->tetra_loops_energies->at(cnt));
			}
		}
	}
	else if(size == 6)
	{
		int current_hash = this->compute_hp_hash(outer_i, outer_j);

		// Search triloop hashes.
		for(int cnt = 0; cnt < (int)this->hexaloop_hashes->size(); cnt++)
		{
			if(this->hexaloop_hashes->at(cnt) == current_hash)
			{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
				printf("Found a distinguished tetraloop: %s\n", this->hexaloops->at(cnt));

				return(this->hexaloop_energies->at(cnt));
			}
		}
	}

	// Compute the energies for ordinary loops.
	double hp_loop_energy_by_size = this->loop_energy_by_size(HAIRPIN_LOOP, outer_j - outer_i - 1);

	double hp_stack_energy = CONVERT_FROM_LIN(1.0); 

	// Do not consider stacking for hairpins of size 3.
	if(size > 3)
	{
		hp_stack_energy = this->hairpin_stack_energy(outer_i, outer_j, outer_j - 1, outer_i + 1);

if(DUMP_THERMO_PARAMETERS_MESSAGES)
{
#ifdef _LINEAR_NNM_COMPUTATIONS_
		printf("Hairpin stack: %lf\n", log(hp_stack_energy));
#endif // _LINEAR_NNM_COMPUTATIONS_

#ifdef _LOG_NNM_COMPUTATIONS_
		printf("Hairpin stack: %lf\n", hp_stack_energy);
#endif // _LOG_NNM_COMPUTATIONS_

}
	}
	else if(size == 3) // The AU penalty needs to be included for triloop. This penalty is included in stacking data for larger loops.
	{
		// Add the AU penalty.
		hp_stack_energy = this->terminal_pair_penalty(outer_i, outer_j);

if(DUMP_THERMO_PARAMETERS_MESSAGES)
{
#ifdef _LINEAR_NNM_COMPUTATIONS_
		printf("Hairpin stack: %lf\n", log(hp_stack_energy));
#endif // _LINEAR_NNM_COMPUTATIONS_

#ifdef _LOG_NNM_COMPUTATIONS_
		printf("Hairpin stack: %lf\n", hp_stack_energy);
#endif // _LOG_NNM_COMPUTATIONS_
}
	}

	// Handle special loop bonuses:
	double special_loop_bonuses = CONVERT_FROM_LIN(1.0);

	// Handle a GGG loop:
	/*
	5'GGG ... -> 
	  |
	3'U   ... <-
	*/
    //if (ct->numseq[i]==3&&ct->numseq[j]==4) 
	if(this->rna_seq->numseq[outer_i] == BASE_G && this->rna_seq->numseq[outer_j] == BASE_U)
	{
		//printf("GG bonus check: %d, %d\n", outer_i, outer_j);
		//exit(0);
		if (outer_i >= 3 && this->rna_seq->numseq[outer_i-1] == BASE_G && this->rna_seq->numseq[outer_i-2] == BASE_G)
		{
			//energy = energy * data->gubonus;
			special_loop_bonuses = MUL(special_loop_bonuses, this->GGG_loop_bonus);
        }
    }

	// Check if poly-C bonus is applicable.
	bool is_poly_C_loop = true;
	for(int cnt = outer_i+1; cnt <= outer_j-1; cnt++)
	{
		if(this->rna_seq->numseq[cnt] != BASE_C)
		{
			//printf("checking %d.: %c\n", 
			is_poly_C_loop = false;
			break;
		}
	}

	// Apply the poly C bonus.
	if(is_poly_C_loop)
	{
		// CCC loop gets a special bouns.
		if(size == 3)
		{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
			printf("Found a CCC loop!");

			special_loop_bonuses = MUL(special_loop_bonuses, this->C3_hp_bonus);
		}
		else
		{
if(DUMP_THERMO_PARAMETERS_MESSAGES)
			printf("Found a Poly-C loop (%d, %d)",outer_i, outer_j);

			special_loop_bonuses = MUL(special_loop_bonuses, MUL(this->C_hp_intercept, POW(this->C_hp_slope, size)));
		}
	}

if(DUMP_THERMO_PARAMETERS_MESSAGES)
{
#ifdef _LOG_NNM_COMPUTATIONS_
	printf("Hairpin loop energy closed by (%d, %d) is %.5f + %.5f = %.5f\n", outer_i, outer_j, hp_loop_energy_by_size, hp_stack_energy, MUL(hp_loop_energy_by_size, hp_stack_energy));
#endif

#ifdef _LINEAR_NNM_COMPUTATIONS_
	double log_correction = log(POW(this->scaling_per_nuc, outer_j-outer_i+1));
	printf("Hairpin loop energy closed by (%d, %d) is %.5f + %.5f = %.5f\n", outer_i, outer_j, log(hp_loop_energy_by_size) - log_correction, log(hp_stack_energy), log(MUL(hp_loop_energy_by_size, hp_stack_energy)) - log_correction);
#endif
}

	return(MUL3(hp_loop_energy_by_size, 
				hp_stack_energy, 
				special_loop_bonuses));
}

double t_thermo_parameters::loop_energy_by_size(int loop_type, int loop_size)
{
	if(loop_size < 31)
	{
		//printf("Size: %d -> %lf\n", loop_size, this->loop_dat[loop_type][loop_size]);
		return(this->loop_dat[loop_type][loop_size]);
	}

	//printf("Greater than 30!\n");
	
	// Loop size is greater than 30, use formulation.
	/*
	Uses 1.079???
	*/
	//double energy_by_loop_size = MUL(this->loop_dat[loop_type][30], (-1 * this->large_loop_scale * GAS_CONST * TEMP * log(loop_size / 30.0f)) * NEG_OVER_RT);
	double energy_by_loop_size = MUL3(this->loop_dat[loop_type][30], 
									CONVERT_FROM_LOG(this->large_loop_scale * NEG_OVER_RT * log(loop_size / 30.0f)),
									POW(this->scaling_per_nuc, loop_size - 30)); // Add the scaling for extra nucleotides, which were not accounted for in loop.dat

	//printf("Computed loop energy: %d: %f = %f + %f\n", loop_size, energy_by_loop_size, this->loop_dat[loop_type][30], ((-1 * this->large_loop_scale * GAS_CONST * TEMP * log(loop_size / 30.0f)) * NEG_OVER_RT));
	return(energy_by_loop_size);

}

// Array accession functions.
double t_thermo_parameters::hairpin_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker) // [5' pair][3' pair][5' stacker][3' stacker]
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	return(this->tstackh_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc]);
}

double t_thermo_parameters::interior_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker) // [5' pair][3' pair][5' stacker][3' stacker]
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	return(this->tstacki_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc]);
}

double t_thermo_parameters::interior_stack23_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker) // [5' pair][3' pair][5' stacker][3' stacker]
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	return(this->tstacki23_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc]);
}

double t_thermo_parameters::interior_stack1n_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker) // [5' pair][3' pair][5' stacker][3' stacker]
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	return(this->tstacki1n_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc]);
}

double t_thermo_parameters::bp_stack_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker) // [5' pair][3' pair][5' stacker][3' stacker]
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	double SHAPE_energy_of_loop = CONVERT_FROM_LIN(1.0f);

	// Add SHAPE contribution if SHAPE data exists.
	if(this->exp_DG_SHAPE_per_loop != NULL)
	{
		SHAPE_energy_of_loop = MUL(this->exp_DG_SHAPE_per_loop[fp_pair][tp_stacker], 
									this->exp_DG_SHAPE_per_loop[fp_stacker][tp_pair]);
	}

	double bp_stacking_energy = this->stack_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc];

	return(MUL(SHAPE_energy_of_loop, 
				bp_stacking_energy));
}

double t_thermo_parameters::mbl_mismatch_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker)
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	double mbl_mm_energy = this->tstackm_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc];

	return(mbl_mm_energy);
}

double t_thermo_parameters::ext_loop_mismatch_energy(int fp_pair, int tp_pair, int fp_stacker, int tp_stacker)
{
	int fp_pair_nuc = this->rna_seq->numseq[fp_pair];
	int tp_pair_nuc = this->rna_seq->numseq[tp_pair];
	int fp_stacker_nuc = this->rna_seq->numseq[fp_stacker];
	int tp_stacker_nuc = this->rna_seq->numseq[tp_stacker];

	double ext_loop_mm_energy = this->tstack_dat[fp_pair_nuc][tp_pair_nuc][fp_stacker_nuc][tp_stacker_nuc];

	return(ext_loop_mm_energy);
}

// These are indices.
//double t_thermo_parameters::interior_1x1_loop_energy(int outer_fp_pair, int outer_tp_pair, int inner_fp_pair, int inner_tp_pair)
double t_thermo_parameters::interior_1x1_loop_energy(int outer_i, int outer_j, int inner_i, int inner_j)
{
	int int11_outer_pair_index = this->int11_pair_index(outer_i, outer_j);
	int int11_inner_pair_index = this->int11_pair_index(inner_i, inner_j);

	// fp nuc is next to outer j.
	// tp nuc is next to outer i.
	int fp_nuc_in_loop = this->rna_seq->numseq[outer_j - 1];
	int tp_nuc_in_loop = this->rna_seq->numseq[outer_i + 1];

	double int11_energy = this->int11_dat[int11_outer_pair_index][int11_inner_pair_index][fp_nuc_in_loop][tp_nuc_in_loop];

	//printf("%lf\n", int11_energy / NEG_OVER_RT);

	return(int11_energy);
}

double t_thermo_parameters::interior_2x1_loop_energy(int outer_i, int outer_j, int inner_i, int inner_j)
{
	int outer_pair = this->int11_pair_index(outer_i, outer_j);
	int inner_pair = this->int11_pair_index(inner_i, inner_j);

	int tp_nuc = this->rna_seq->numseq[outer_i + 1];
	int fp_side_fp_nuc = this->rna_seq->numseq[outer_j - 1];
	int fp_side_tp_nuc = this->rna_seq->numseq[outer_j - 2];

	return(this->int21_dat[outer_pair][inner_pair][fp_side_fp_nuc][fp_side_tp_nuc][tp_nuc]);
}

double t_thermo_parameters::terminal_pair_penalty(int i, int j)
{
	int fp_bp_nuc = this->rna_seq->numseq[i];
	int tp_bp_nuc = this->rna_seq->numseq[j];
	
	if(fp_bp_nuc == 4 || tp_bp_nuc == 4)
	{
		return(this->terminal_AU_penalty);
	}
	else
	{
		return(CONVERT_FROM_LIN(1.0f));
	}
}

double t_thermo_parameters::dangle_tp_energy(int fp_bp, int tp_bp, int tp_dangler)
{
	int fp_bp_nuc = this->rna_seq->numseq[fp_bp];
	int tp_bp_nuc = this->rna_seq->numseq[tp_bp];
	int tp_dangler_nuc = this->rna_seq->numseq[tp_dangler];

	return(this->tp_dangle_dat[fp_bp_nuc][tp_bp_nuc][tp_dangler_nuc]);
}

double t_thermo_parameters::dangle_fp_energy(int fp_bp, int tp_bp, int fp_dangler)
{
	int fp_bp_nuc = this->rna_seq->numseq[fp_bp];
	int tp_bp_nuc = this->rna_seq->numseq[tp_bp];
	int fp_dangler_nuc = this->rna_seq->numseq[fp_dangler];

	return(this->fp_dangle_dat[fp_bp_nuc][tp_bp_nuc][fp_dangler_nuc]);
}

double t_thermo_parameters::interior_2x2_loop_energy(int outer_i, int outer_j, int inner_i, int inner_j)
{
	// The modified nucleotide checks are performed here for interior 2x2 loops.
	int outer_mm_i_nuc = this->rna_seq->numseq[outer_i+1];
	int outer_mm_j_nuc = this->rna_seq->numseq[outer_j-1];
	int inner_mm_i_nuc = this->rna_seq->numseq[inner_i-1];
	int inner_mm_j_nuc = this->rna_seq->numseq[inner_j+1];

	if(outer_mm_i_nuc == BASE_X || outer_mm_i_nuc == BASE_I || 
		outer_mm_j_nuc == BASE_X || outer_mm_j_nuc == BASE_I ||
		inner_mm_i_nuc == BASE_X || inner_mm_i_nuc == BASE_I ||
		inner_mm_j_nuc == BASE_X || inner_mm_j_nuc == BASE_I)
	{
		return(ZERO);
	}

	int int22_outer_pair_index = this->int22_pair_index(outer_i, outer_j);
	int int22_inner_pair_index = this->int22_pair_index(inner_i, inner_j);

	int outer_mm_index = this->int22_MM_index(outer_i + 1, outer_j - 1);
	int inner_mm_index = this->int22_MM_index(inner_i - 1, inner_j + 1);

	return(this->int22_dat[int22_outer_pair_index][int22_inner_pair_index][outer_mm_index][inner_mm_index]);
}

// This does the conversion of ACGU->1234
int t_thermo_parameters::base2num(char _nuc)
{
		if(_nuc == 'a' || _nuc == 'A')
		{
			return(BASE_A);
		}
		else if(_nuc == 'C' || _nuc == 'C')
		{
			return(BASE_C);
		}
		else if(_nuc == 'g' || _nuc == 'G')
		{
			return(BASE_G);
		}
		else if(_nuc == 'u' || _nuc == 'U' || _nuc == 't' || _nuc == 'T')
		{
			return(BASE_U);
		}
		else
		{
			printf("Unknown character (%c) input as nuc in %s(%d)\n", _nuc, __FILE__, __LINE__);
			exit(0);
		}
}

int t_thermo_parameters::int11_pair_index(int i, int j)
{
	int i_nuc = this->rna_seq->numseq[i];
	int j_nuc = this->rna_seq->numseq[j];
	if(i_nuc == BASE_A)
	{
		if(j_nuc == BASE_U)
		{
			return(AU_pair);
		}
		else
		{
			printf("Could not resolve a pair for int11 @ %s(%d)\n", __FILE__, __LINE__);
			int* p = NULL;
			*p = 0;
		}
	}

	if(i_nuc == BASE_C)
	{
		if(j_nuc == BASE_G)
		{
			return(CG_pair);
		}
		else
		{
			printf("Could not resolve a pair for int11 @ %s(%d)\n", __FILE__, __LINE__);
			int* p = NULL;
			*p = 0;
		}
	}

	if(i_nuc == BASE_U)
	{
		if(j_nuc == BASE_G)
		{
			return(UG_pair);
		}
		else if(j_nuc == BASE_A)
		{
			return(UA_pair);
		}
		else
		{
			printf("Could not resolve a pair for int11 @ %s(%d)\n", __FILE__, __LINE__);
						int* p = NULL;
			*p = 0;
		}
	}

	if(i_nuc == BASE_G)
	{
		if(j_nuc == BASE_C)
		{
			return(GC_pair);
		}
		else if(j_nuc == BASE_U)
		{
			return(GU_pair);
		}
		else
		{
			printf("Could not resolve a pair for int11 @ %s(%d)\n", __FILE__, __LINE__);
			int* p = NULL;
			*p = 0;
		}
	}
	else
	{
		printf("Failed @ %s(%d)\n", __FILE__, __LINE__);
			int* p = NULL;
			*p = 0;
		exit(0);
	}
}

int t_thermo_parameters::int22_pair_index(int i, int j)
{
	int i_nuc = this->rna_seq->numseq[i];
	int j_nuc = this->rna_seq->numseq[j];

	if(i_nuc == BASE_A)
	{
		if(j_nuc == BASE_U)
		{
			return(int22_AU_pair);
		}
		else
		{
			printf("Could not resolve a pair for int22 @ %s(%d)\n", __FILE__, __LINE__);
		}
	}

	if(i_nuc == BASE_C)
	{
		if(j_nuc == BASE_G)
		{
			return(int22_CG_pair);
		}
		else
		{
			printf("Could not resolve a pair for int22 @ %s(%d)\n", __FILE__, __LINE__);
		}
	}

	if(i_nuc == BASE_U)
	{
		if(j_nuc == BASE_G)
		{
			return(int22_UG_pair);
		}
		else if(j_nuc == BASE_A)
		{
			return(int22_UA_pair);
		}
		else
		{
			printf("Could not resolve a pair for int22 @ %s(%d)\n", __FILE__, __LINE__);
		}
	}

	if(i_nuc == BASE_G)
	{
		if(j_nuc == BASE_C)
		{
			return(int22_GC_pair);
		}
		else if(j_nuc == BASE_U)
		{
			return(int22_GU_pair);
		}
		else
		{
			printf("Could not resolve a pair for int22 @ %s(%d)\n", __FILE__, __LINE__);			
		}
	}

	exit(0);
}

int t_thermo_parameters::int22_MM_index(int i, int j)
{
	int i_nuc = this->rna_seq->numseq[i];
	int j_nuc = this->rna_seq->numseq[j];

	return((i_nuc - 1) * 4 + (j_nuc - 1));
	/*
	if(i_nuc == BASE_A)
	{
		if(j_nuc == BASE_A)
		{
			return(AA_mm);
		}
		else if(j_nuc == BASE_C)
		{
			return(AC_mm);
		}
		else if(j_nuc == BASE_G)
		{
			return(AG_mm);
		}
		else if(j_nuc == BASE_U)
		{
			return(AU_mm);
		}
	}
	else if(i_nuc == BASE_C)
	{
		if(j_nuc == BASE_A)
		{
			return(CA_mm);
		}
		else if(j_nuc == BASE_C)
		{
			return(CC_mm);
		}
		else if(j_nuc == BASE_G)
		{
			return(CG_mm);
		}
		else if(j_nuc == BASE_U)
		{
			return(CU_mm);
		}
	}
	else if(i_nuc == BASE_G)
	{
		if(j_nuc == BASE_A)
		{
			return(GA_mm);
		}
		else if(j_nuc == BASE_C)
		{
			return(GC_mm);
		}
		else if(j_nuc == BASE_G)
		{
			return(GG_mm);
		}
		else if(j_nuc == BASE_U)
		{
			return(GU_mm);
		}
	}
	else if(i_nuc == BASE_U)
	{
		if(j_nuc == BASE_A)
		{
			return(UA_mm);
		}
		else if(j_nuc == BASE_C)
		{
			return(UC_mm);
		}
		else if(j_nuc == BASE_G)
		{
			return(UG_mm);
		}
		else if(j_nuc == BASE_U)
		{
			return(UU_mm);
		}
	}
	else
	{
		printf("Could not resolve mm index for 2x2 internal loop.\n");
		exit(0);
	}
	*/
}

void t_thermo_parameters::load_SHAPE_data(char* SHAPE_fp)
{
	// Read the reactivities and compute \Delta G_{SHAPE}. Also convert via \Delta G / RT.
	FILE* f_SHAPE = open_f(SHAPE_fp, "r");
	if(f_SHAPE == NULL)
	{
		printf("Could not open SHAPE data @ %s\n", SHAPE_fp);
		exit(0);
	}

	this->exp_DG_SHAPE_per_nuc = (double*)malloc(sizeof(double) * (this->rna_seq->numofbases + 2));

	int cur_i = 0;
	for(int i = 1; i <= this->rna_seq->numofbases; i++)
	{
		this->exp_DG_SHAPE_per_nuc[i] = CONVERT_FROM_LOG(-999.0f);

		double cur_SHAPE_reactivity = 0.0f;
		fscanf(f_SHAPE, "%d %lf", &cur_i, &cur_SHAPE_reactivity);

		// Set negative reactivities to 0.
		if(cur_SHAPE_reactivity < 0.0f)
		{
			cur_SHAPE_reactivity = 0.0f;
		}

		if(cur_i != i)
		{
			printf("Could not read SHAPE reactivity data for %d. nucleotide.\n", i);
			exit(0);
		}

		double current_nuc_DG_SHAPE = (DEFAULT_SHAPE_SLOPE * xlog(cur_SHAPE_reactivity + 1)) + DEFAULT_SHAPE_INTERCEPT;
		this->exp_DG_SHAPE_per_nuc[i] = CONVERT_FROM_LOG(current_nuc_DG_SHAPE);
	} // i loop, goes over all the nucleotides. 
	fclose(f_SHAPE);

	// Compute exponential converted SHAPE energies per loop.
	this->exp_DG_SHAPE_per_loop = (double**)malloc(sizeof(double*) * (this->rna_seq->numofbases + 2));
	for(int i = 1; i <= this->rna_seq->numofbases; i++)
	{
		this->exp_DG_SHAPE_per_loop[i] = (double*)malloc(sizeof(double) * (this->rna_seq->numofbases - i + 2));
		this->exp_DG_SHAPE_per_loop[i] -= i;

		// Initialize.
		this->exp_DG_SHAPE_per_loop[i][i] = this->exp_DG_SHAPE_per_nuc[i];

		for(int j = i+1; j <= this->rna_seq->numofbases; j++)
		{
			this->exp_DG_SHAPE_per_loop[i][j] = MUL(this->exp_DG_SHAPE_per_loop[i][j-1], this->exp_DG_SHAPE_per_nuc[j]);
			//printf("exp_DG_SHAPE_per_loop[%d][%d] = %.5f\n", i, j, this->exp_DG_SHAPE_per_loop[i][j]);
		} // j loop
	} // i loop
}



