#include <stdlib.h>
#include <stdio.h>
#include <stack>
#include "tb_stack.h"
#include "energy_loops.h"

bool _DUMP_TB_STACK_MESSAGES= false;

using namespace std;

t_tb_stack::t_tb_stack()
{
	this->tb_stack = new stack<t_tb_substructure*>();
}

t_tb_stack::~t_tb_stack()
{
	while(this->size())
	{
		int array_id, i, j;
		this->pop_substr(array_id, i, j);
	}

	delete(this->tb_stack);
}

void t_tb_stack::push_substr(int tb_array_id, int i, int j)
{
	//printf("Pushing %d(%d, %d)\n", tb_array_id, i, j);
	//if(tb_array_id == tb_V && j - i < MIN_LOOP)
	//{
	//	exit(0);
	//}

	t_tb_substructure* tb_substr = (t_tb_substructure*)malloc(sizeof(t_tb_substructure));
	tb_substr->i = i;
	tb_substr->j = j;
	tb_substr->tb_array_id = tb_array_id;

	// Push the newly allocated substructure identifier on stack.
	this->tb_stack->push(tb_substr);

if(_DUMP_TB_STACK_MESSAGES)
	printf("Pushed %s(%d, %d)\n", array_names[tb_array_id], i, j);
}

void t_tb_stack::pop_substr(int& tb_array_id, int& i, int& j)
{
	// Get the next element on stack, which is an LIFO list so that this element is going to be 
	// the elements that is last pushed onto stack.
	t_tb_substructure* tb_substr = this->tb_stack->top();

	// Set the values.
	i = tb_substr->i;
	j = tb_substr->j;
	tb_array_id = tb_substr->tb_array_id;

	// Remove last element.
	this->tb_stack->pop();

if(_DUMP_TB_STACK_MESSAGES)
	printf("Popped %s(%d, %d)\n", array_names[tb_array_id], i, j);

	// Free substructure identifier memory.
	free(tb_substr);
}

int t_tb_stack::size()
{
	return((int)this->tb_stack->size());
}


