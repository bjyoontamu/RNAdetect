#ifndef __COINC_INFO__
#define __COINC_INFO__

class t_matrix;
class t_structure;
class t_energy_loops;
class t_structure;

/*
Manages the co-incidence priors for an RNA sequence.
The computed posteriors are in LINEAR domain.
*/
class t_coinc_info
{
public:
	t_coinc_info(t_energy_loops* _energy_loops);
	t_coinc_info(t_coinc_info* _coinc_info);
	t_coinc_info(t_structure* _rna_seq);

	t_energy_loops* energy_loops;

	~t_coinc_info();

	t_matrix* v_coinc_info; // Same as base pairing probabilities, since co-incidence for V array implies that nucleotides are paired.
	t_matrix* branchized_v_coinc_info;
	t_matrix* w_coinc_info;
	t_matrix* wmb_coinc_info;
	t_matrix* wout_coinc_info;
	t_matrix* wl_coinc_info;
	t_matrix* wmbl_coinc_info;
};

#endif // __COINC_INFO__


