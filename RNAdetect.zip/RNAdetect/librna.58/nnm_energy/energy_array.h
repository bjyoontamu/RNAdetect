#ifndef _ENERGY_ARRAY_
#define _ENERGY_ARRAY_

/*
The array that encapsulates storage of energy terms for partition function and ml prediction. The arrays hold the log of sum of exponentials of
negative energies.
*/

class t_structure;

class t_energy_array
{
public: 
	t_energy_array(t_structure* _rna_seq); // Construct.
	~t_energy_array(); // Deallocate.

	double** energy_array;
	t_structure* rna_seq;

	double mem_usage;

	// Access the array, this function is needed because there is 
	// translation of indices.
	//double& x(int i, int j);

	inline double& x(int i, int j)
	{
		return(this->energy_array[i][j]);
	}
};

#endif // _ENERGY_ARRAY_



