#include <stdio.h>
#include <stdlib.h>
#include "v.h"
#include "w.h"
#include "wcoax.h"
#include "wmb.h"
#include "wout.h"
#include "energy_array.h"
#include "energy_loops.h"
#include "nnm_math.h"
#include "tb_stack.h"
#include "min_energy_structure.h"
#include "stoch_energy_structures.h"
#include "sampling_math.h"
#include "nnm_energy_compilation_directives.h"
#include "../structure/structure.h"
#include "thermo_parameters.h"
#include "../structure/folding_constraints.h"
//
bool _DUMP_V_MESSAGES_ = false;

// Define the pairability array.
							// -, A, C, G, U
int t_V::pairable[5][5] = {	{ 0, 0, 0, 0, 0 },  // -
							{ 0, 0, 0, 0, 1 },  // A
							{ 0, 0, 0, 1, 0 },  // C
							{ 0, 0, 1, 0, 1 },  // G
							{ 0, 1, 0, 1, 0 }}; // U

t_V::t_V(t_energy_loops* _energy_loops)
{
	this->energy_loops = _energy_loops;

	// Allocate energy array.
	this->energy_array = new t_energy_array(energy_loops->rna_seq);
	this->ext_energy_array = new t_energy_array(energy_loops->rna_seq);

	// Copy rna sequence pointer for later use.
	this->rna_seq = this->energy_loops->rna_seq;
	this->MAX_SUM = (this->energy_loops->MAX_SUM);
}

// Free the energy array.
t_V::~t_V()
{
	delete(this->energy_array);
	delete(this->ext_energy_array);
}

void t_V::compute(int i, int j)
{	
	if(!this->energy_loops->folding_constraints->pairing_map[i][j])
	{
		return;
	}

	// Check MIN_LOOP constraint.
	// If the nucleotides are not pairable, do not bother computation, assign infinity to
	// current array value and return.
	if((j-i-1) < MIN_LOOP || 
		!pairable[rna_seq->numseq[i]][rna_seq->numseq[j]])
	{
		//printf("%d and %d are not pairable\n", i,j);
		this->x(i,j) = ZERO;
		return;
	}
	else
	{
		//printf("Computing!!!\n");
		//printf("%d and %d are pairable: %c-%c\n", i,j, rna_seq->nucs[i], rna_seq->nucs[j]);
	}

	// Following code is borrowed from pfunction.
	int before = 0;
	if (i>1 && j < rna_seq->numofbases)
	{
		before = pairable[rna_seq->numseq[i-1]][rna_seq->numseq[j+1]];
	}


	int after = 0;
	if((((j-i) > MIN_LOOP + 2)&&(j<=rna_seq->numofbases))&&(i < rna_seq->numofbases)) {
		after = pairable[rna_seq->numseq[i+1]][rna_seq->numseq[j-1]];

	}
	else after = 0;

	//if there are no stackable pairs to i.j then don't allow a pair i,j
	if ((before==0)&&(after==0)) 
	{
		this->x(i,j) = ZERO;
		return;
	}

	t_WMB* WMB = this->energy_loops->WMB;
	t_W* W = this->energy_loops->W;
	t_Wcoax* Wcoax = this->energy_loops->Wcoax;

if(_DUMP_V_MESSAGES_)
{
			printf("---------------------------\n");
			printf("Computing V(%d, %d)\n", i, j);
}

	// Hairpin.
	double current_cumulative = ZERO;
	//double energy_closing_hairpin = ZERO;
#ifdef _TRANS_HP_LOOP_2_V_
	if(this->energy_loops->folding_constraints->check_hairpin_loop(i,j))
	{
		double energy_closing_hairpin = this->energy_loops->thermo_pars->hairpin_energy(i, j);

		// Make sure the loop is interior to the constrained base pair.
		current_cumulative = MAX_SUM(current_cumulative, this->energy_loops->thermo_pars->hairpin_energy(i, j));

if(_DUMP_V_MESSAGES_)
{
		printf("---------------------------\n");
		printf("Hairpin -> V(%d, %d): %.10f\n", i, j, current_cumulative);
}
	}
	else
	{
if(_DUMP_V_MESSAGES_)
{
	printf("Forbidden hairpin %d-%d\n", i,j);
}
	}
#endif // _TRANS_HP_LOOP_2_V_

#ifdef _TRANS_V_INT_LOOP_2_V_
	// Internal.
	// Need a double loop for searching for internal loops.
	double energy_closing_interior = ZERO;

	for(int inner_i = i+1; inner_i < j; inner_i++)
	{
		for(int inner_j = j-1; inner_j > inner_i; inner_j--)
		{
			// Exclude the internal loop where loop is just stacking of this base pair on next base pair.
			if(!(inner_i == i+1 && inner_j == j-1))
			{
				int fp_size = abs(i - inner_i) - 1;
				int tp_size = abs(j - inner_j) - 1;
				int size = fp_size + tp_size;

				if(size <= MAX_INT_LOOP_SIZE && 
					(inner_j - inner_i) > MIN_LOOP && 
					this->energy_loops->folding_constraints->pairing_map[inner_i][inner_j])
				{
				if(this->energy_loops->folding_constraints->check_internal_loop(i, j, inner_i, inner_j))
				{
					double energy_closing_current_interior = MUL(this->x(inner_i, inner_j), 
																this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j));

					//double ij_term_pen = this->energy_loops->thermo_pars->terminal_pair_penalty(i,j);
					//double inner_ij_term_pen = this->energy_loops->thermo_pars->terminal_pair_penalty(inner_i,inner_j);

if(_DUMP_V_MESSAGES_)
{
#ifdef _LINEAR_NNM_COMPUTATIONS_
					double log_correction = log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, inner_j-inner_i+1));
					double int_log_correction = log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, size+2));
					printf("V(%d, %d) + Internal(%d,%d)-(%d,%d) = %.5f + %.5f = %.15f\n", inner_i, inner_j, i, j, inner_i, inner_j, log(this->x(inner_i, inner_j))-log_correction, log(this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j)) - int_log_correction, log(energy_closing_current_interior) - (log_correction + int_log_correction));
#endif

#ifdef _LOG_NNM_COMPUTATIONS_
					printf("V(%d, %d) + Internal(%d,%d)-(%d,%d) = %.5f + %.5f = %.5f\n", inner_i, inner_j, i, j, inner_i, inner_j, this->x(inner_i, inner_j), this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j), energy_closing_current_interior);
#endif
}
					current_cumulative = MAX_SUM(current_cumulative, energy_closing_current_interior);

if(_DUMP_V_MESSAGES_)
{
					printf("---------------------------\n");
					printf("V[Internal] -> V(%d, %d): %.10f\n", i, j, current_cumulative);
}
				} // same loop check for nucleotides in the internal loop.
				} // pairing and max int loop size checks.
			} // Exclude stacked pairs as a consideration for interior loops.
		} // inner_j loop.
	} // inner_i loop.

	// Stacked base pair.
	current_cumulative = MAX_SUM(current_cumulative, MUL(this->x(i+1, j-1), this->energy_loops->thermo_pars->bp_stack_energy(i,j, j-1, i+1)));

if(_DUMP_V_MESSAGES_)
{
	printf("V[stacked](%d, %d, %d, %d) -> V(%d, %d): %.10f (%.10f)\n", i,j, j-1, i+1, i, j, current_cumulative, this->energy_loops->thermo_pars->bp_stack_energy(i,j, j-1, i+1));
}
#endif // _TRANS_V_INT_LOOP_2_V_

	// Multibranch.
	// Consider the stacking on top of closing i-j base pair.
	double multibranch_closing_penalty = this->energy_loops->thermo_pars->MBL_closure_penalty;
	double multibranch_helix_init_energy = this->energy_loops->thermo_pars->per_helix_penalty;
	double two_multibranch_helix_init_energy = MUL(multibranch_helix_init_energy, multibranch_helix_init_energy);
	double unpaired_nuc_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	double two_unpaired_nuc_in_mbl_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_WMB_DANGLE_STACK_2_V_
	// Consider the dangling ends here. i+1 and j-1 can dangle. Consider all 4 cases.
	double i_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(i,j,i+1);
	double j_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(i,j,j-1);
	double ij_dangle_energy = this->energy_loops->thermo_pars->mbl_mismatch_energy(i,j,j-1,i+1);

	// Choose min of 4 cases
	// Add the scaling parameters for closing bp.

	// no dangle
	current_cumulative = MAX_SUM(current_cumulative, MUL4(this->energy_loops->WMB->x(i+1, j-1),
														this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
														multibranch_helix_init_energy,
														multibranch_closing_penalty));

	// i dangle
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1))
	{
		current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+2, j-1),
															i_dangle_energy,
															unpaired_nuc_in_mbl_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
															multibranch_helix_init_energy,
															multibranch_closing_penalty));
	}

	// j dangle
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(j-1))
	{
		current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+1, j-2),
															j_dangle_energy,
															unpaired_nuc_in_mbl_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
															multibranch_helix_init_energy,
															multibranch_closing_penalty));
	}

	// ij mismatch:
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
	{
		current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+2, j-2),
															ij_dangle_energy,
															two_unpaired_nuc_in_mbl_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
															multibranch_helix_init_energy,
															multibranch_closing_penalty));
	}

if(_DUMP_V_MESSAGES_)
{
	double no_dangle = MUL4(this->energy_loops->WMB->x(i+1, j-1), multibranch_closing_penalty, multibranch_helix_init_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
	double i_dangle = MUL4(MUL3(i_dangle_energy, unpaired_nuc_in_mbl_energy, WMB->x(i+2, j-1)), multibranch_closing_penalty, multibranch_helix_init_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
	double j_dangle = MUL4(MUL3(j_dangle_energy, unpaired_nuc_in_mbl_energy, WMB->x(i+1, j-2)), multibranch_closing_penalty, multibranch_helix_init_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
	double ij_mm = MUL4(MUL3(ij_dangle_energy, two_unpaired_nuc_in_mbl_energy, WMB->x(i+2, j-2)), multibranch_closing_penalty, multibranch_helix_init_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));

	printf("V(%d, %d): no dangling energy: %lf, %lf\n",i,j,no_dangle, WMB->x(i+1, j-1));
	printf("V(%d, %d): i dangling energy: %lf, %lf: %lf\n",i,j,i_dangle, i_dangle_energy, WMB->x(i+2, j-1));
	printf("V(%d, %d): j dangling energy: %lf, %lf: %lf\n",i,j,j_dangle, j_dangle_energy, WMB->x(i+1, j-2));
	printf("V(%d, %d): ij dangling energy: %lf, %lf: %lf\n",i,j,ij_mm, ij_dangle_energy, WMB->x(i+2, j-2));
}
#endif // _TRANS_WMB_DANGLE_STACK_2_V_

#ifdef _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_
if(_DUMP_V_MESSAGES_)
	printf("Nonbroken j cases:\n");
	// Add 6 coaxial stacking cases: 3 for breakage between i and ip, 3 for breakage between jp and j.
	for(int ip = i + MIN_LOOP + 1; ip < j - MIN_LOOP; ip++)
	{
		// 1: Perfect stacking between i-j and ip-(j-1).
		double perfect_stacking_energy = ZERO;

		if(ip < j-1 && i+1 < ip-1)
		{
			perfect_stacking_energy = MUL3(this->x(ip,j-1),
											this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(j-1, ip, i, j),
											MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)));

			// Add unpaired nuc and helix init penalties.
			perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-1));
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			perfect_stacking_energy = MUL(perfect_stacking_energy, multibranch_closing_penalty);
			current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);
		}	
		
if(_DUMP_V_MESSAGES_)
		printf("perfect_stacking_energy: (%d, %d)-(%d, %d)=%.5f\n", i,ip, ip+1, j, current_cumulative);

		// 2: 
		// This is the energy of stacking of mismatched pair (i+1, j-1) on (i,j)
		double stack_on_ij_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(i, j, j-1, i+1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(j-2, ip, i+1, j-1);

		double imperfect_stacking_energy1 = ZERO;
		if(j-2 > ip && i+2 < ip-1)
		{
			imperfect_stacking_energy1 = MUL4(this->x(ip,j-2), 
												MAX_SUM(W->x(i+2, ip-1), WMB->x(i+2, ip-1)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-2));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, multibranch_closing_penalty);
		}

		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy1);
		}

if(_DUMP_V_MESSAGES_)
{
		printf("imperfect_stacking_energy1: (%d, %d)-(%d, %d)=%.5f\n", i,ip, ip+1, j, current_cumulative);
}
		// 3
		// This is the energy of stacking of mismatched pair (ip, j-1) on (ip+1, j-2)                           
		double stack_on_ip_p_j_nn_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-2, ip+1, ip, j-1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(j-1, ip, i, j);

		double imperfect_stacking_energy2 = ZERO;
		if(j-2 > ip+1 && ip-1 > i+1)
		{
			imperfect_stacking_energy2 = MUL4(this->x(ip+1,j-2), 
												MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)),
												stack_on_ip_p_j_nn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j-2));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, multibranch_closing_penalty);
		}

		// Update current cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[ip][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip, j-1))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy2);
		}

if(_DUMP_V_MESSAGES_)
{
		printf("imperfect_stacking_energy2: (%d, %d)-(%d, %d)=%.5f\n", i,ip, ip+1, j, current_cumulative);
}
	}
#endif // _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_

#ifdef _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_
if(_DUMP_V_MESSAGES_)
	printf("Nonbroken i cases:\n");

	// Breakage between j and jp.
	//for(int jp = i+1 ; jp < j ; jp++)
	for(int jp = i + MIN_LOOP + 1; jp < j - MIN_LOOP; jp++)
	{
		// 1: Perfect stacking between (i+1, jp) and (i,j).
		double perfect_stacking_energy = ZERO;

		if(i+1 < jp && jp+1 < j-1)
		{
			perfect_stacking_energy = MUL3(this->x(i+1, jp),
											this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(i, j, jp, i+1),
											MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)));

			perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, jp));
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			perfect_stacking_energy = MUL(perfect_stacking_energy, multibranch_closing_penalty);
			current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);
		}

if(_DUMP_V_MESSAGES_)
		printf("perfect_stacking_energy: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, current_cumulative);

		// 2: Mismatching between
		double stack_on_ij_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(i, j, j-1, i+1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(i+1, j-1, jp, i+2);

		double imperfect_stacking_energy1 = ZERO;

		if(jp > i+2 && j-2 > jp+1)
		{
			imperfect_stacking_energy1 = MUL4(this->x(i+2,jp), 
												MAX_SUM(W->x(jp+1, j-2), WMB->x(jp+1, j-2)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, multibranch_closing_penalty);
		}

		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy1);
		}

if(_DUMP_V_MESSAGES_)
{
		printf("imperfect_stacking_energy1: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, current_cumulative);
		//printf("Total stacking energy: %lf + %lf = %lf\n", stack_on_ij_in_coax_stack_energy, energy_imperfect_coaxial_stack1, xlog_mul(stack_on_ij_in_coax_stack_energy, energy_imperfect_coaxial_stack1));
}

		// 3
		// This is the energy of stacking of mismatched pair on (i, ip-1)
		double stack_on_ipjn_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(jp-1, i+2, i+1, jp);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(i, j, jp, i+1);

		double imperfect_stacking_energy2 = ZERO;
		if(i+2 < jp-1 && jp+1 < j-1)
		{
			imperfect_stacking_energy2 = MUL4(this->x(i+2,jp-1), 
												MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)),
												stack_on_ipjn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2);
		}

		// Add unpaired nuc and helix init penalties.
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp-1));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, multibranch_closing_penalty);

		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][jp] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, jp))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy2);
		}

if(_DUMP_V_MESSAGES_)
		printf("imperfect_stacking_energy2: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, current_cumulative);
	}
	// End of coaxial stacking cases.

#endif // _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_

	// Choose the minimum for V the minimum of all the hairpin, internal, stacked and mb energies.
	this->x(i,j) = MUL(this->energy_loops->bp_prior(i,j), current_cumulative);
} // t_V::compute

double& t_V::x(int i, int j)
{
	return(this->energy_array->x(i,j));
}

void t_V::min_energy_tb(int i, int j)
{	
if(_DUMP_V_MESSAGES_)
	printf("Backtracking V(%d, %d)\n", i,j);

	// Check MIN_LOOP constraint.
	// If the nucleotides are not pairable, do not bother computation, assign infinity to
	// current array value and return.
	if(!this->energy_loops->folding_constraints->pairing_map[i][j])
	{
		printf("Trackback error while backtracking %d, %d @ %s(%d)\n", i, j, __FILE__, __LINE__);
		exit(0);
	}
	else
	{
		//printf("Computing!!!\n");
		//printf("%d and %d are pairable: %c-%c\n", i,j, rna_seq->nucs[i], rna_seq->nucs[j]);
	}

	// Following code is borrowed from pfunction.
	int before = 0;
	if (i>1 && j < rna_seq->numofbases)
	{
		before = pairable[rna_seq->numseq[i-1]][rna_seq->numseq[j+1]];
	}


	int after = 0;
	if((((j-i) > MIN_LOOP + 2)&&(j<=rna_seq->numofbases))&&(i < rna_seq->numofbases)) {
		after = pairable[rna_seq->numseq[i+1]][rna_seq->numseq[j-1]];

	}
	else after = 0;

	//if there are no stackable pairs to i.j then don't allow a pair i,j
	if ((before==0)&&(after==0)) 
	{
		printf("Trackback error: Isolated base pair at (%d, %d) @ %s(%d)\n", i, j, __FILE__, __LINE__);
		exit(0);
	}

	// Add this base pair.
	this->energy_loops->min_energy_str->add_bp(i,j);

	// Start backtracking.
	double current_max = ZERO;
	bool pushed = false;

	t_WMB* WMB = this->energy_loops->WMB;
	t_W* W = this->energy_loops->W;
	t_Wcoax* Wcoax = this->energy_loops->Wcoax;

#ifdef _TRANS_HP_LOOP_2_V_
	if(this->energy_loops->folding_constraints->check_hairpin_loop(i,j))
	{
		// Hairpin.
		double energy_closing_hairpin = this->energy_loops->thermo_pars->hairpin_energy(i, j);

		// Update current_cumulative.
		current_max = MAX_SUM(current_max, energy_closing_hairpin);

		if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
		{
			pushed = true;
		}
	}
#endif // _TRANS_HP_LOOP_2_V_

#ifdef _TRANS_V_INT_LOOP_2_V_
	// Internal.
	// Need a double loop for searching for internal loops.
	double energy_closing_interior = ZERO;

	for(int inner_i = i+1; inner_i < j; inner_i++)
	{
		for(int inner_j = j-1; inner_j > inner_i; inner_j--)
		{
			// Exclude the internal loop where loop is just stacking of this base pair on next base pair.
			if(!(inner_i == i+1 && inner_j == j-1))
			{
				int fp_size = abs(i - inner_i) - 1;
				int tp_size = abs(j - inner_j) - 1;
				int size = fp_size + tp_size;

				if(size <= MAX_INT_LOOP_SIZE && 
					(inner_j - inner_i) > MIN_LOOP && 
					this->energy_loops->folding_constraints->pairing_map[inner_i][inner_j])
				{
				if(this->energy_loops->folding_constraints->check_internal_loop(i, j, inner_i, inner_j))
				{
					double energy_closing_current_interior = MUL(this->x(inner_i, inner_j), 
																this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j));

					//double ij_term_pen = this->energy_loops->thermo_pars->terminal_pair_penalty(i,j);
					//double inner_ij_term_pen = this->energy_loops->thermo_pars->terminal_pair_penalty(inner_i,inner_j);

//if(i == 152 && j == 157)
if(_DUMP_V_MESSAGES_)
{
#ifdef _LINEAR_NNM_COMPUTATIONS_
					double log_correction = log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, inner_j-inner_i+1));
					double int_log_correction = log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, size+2));
					printf("V(%d, %d) + Internal(%d,%d)-(%d,%d) = %.5f + %.5f = %.5f\n", inner_i, inner_j, i, j, inner_i, inner_j, log(this->x(inner_i, inner_j))-log_correction, log(this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j)) - int_log_correction, energy_closing_current_interior);
#endif

#ifdef _LOG_NNM_COMPUTATIONS_
					printf("V(%d, %d) + Internal(%d,%d)-(%d,%d) = %.5f + %.5f = %.5f\n", inner_i, inner_j, i, j, inner_i, inner_j, this->x(inner_i, inner_j), this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j), energy_closing_current_interior);
#endif
}
					//energy_closing_interior = MAX_SUM(energy_closing_interior, energy_closing_current_interior);

					// Update current_cumulative.
					current_max = MAX_SUM(current_max, energy_closing_current_interior);

					if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
					{
						//printf("Internal!\n");
						this->energy_loops->tb_stack->push_substr(tb_V, inner_i, inner_j);
						pushed = true;
					}
				} // internal loop constraint check.
				} // internal loop size checks.
			} // Exclude stacked pairs as a consideration for interior loops.
		} // inner_j loop.
	} // inner_i loop.

	// Stacked base pair.
	double stacked_energy = MUL(this->x(i+1, j-1), this->energy_loops->thermo_pars->bp_stack_energy(i,j, j-1, i+1));

	// Update current_cumulative.
	current_max = MAX_SUM(current_max, stacked_energy);

	if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
	{
		//printf("Stack!\n");
		this->energy_loops->tb_stack->push_substr(tb_V, i+1, j-1);
		pushed = true;
	}
#endif // _TRANS_V_INT_LOOP_2_V_

	// Multibranch.
	// Consider the stacking on top of closing i-j base pair.
	double multibranch_closing_penalty = this->energy_loops->thermo_pars->MBL_closure_penalty;
	double multibranch_helix_init_energy = this->energy_loops->thermo_pars->per_helix_penalty;
	double two_multibranch_helix_init_energy = MUL(multibranch_helix_init_energy, multibranch_helix_init_energy);
	double unpaired_nuc_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	double two_unpaired_nuc_in_mbl_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_WMB_DANGLE_STACK_2_V_
	// Consider the dangling ends here. i+1 and j-1 can dangle. Consider all 4 cases.
	double i_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(i,j,i+1);
	double j_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(i,j,j-1);
	double ij_dangle_energy = this->energy_loops->thermo_pars->mbl_mismatch_energy(i,j,j-1,i+1);


	//// Choose min of 4 cases
	//double mbl_closing_energy = this->energy_loops->WMB->x(i+1, j-1);
	//mbl_closing_energy = MAX_SUM(mbl_closing_energy, MUL3(i_dangle_energy, unpaired_nuc_in_mbl_energy, WMB->x(i+2, j-1)));
	//mbl_closing_energy = MAX_SUM(mbl_closing_energy, MUL3(j_dangle_energy, unpaired_nuc_in_mbl_energy, WMB->x(i+1, j-2)));
	//mbl_closing_energy = MAX_SUM(mbl_closing_energy, MUL3(ij_dangle_energy, two_unpaired_nuc_in_mbl_energy, WMB->x(i+2, j-2)));
	//mbl_closing_energy = MUL(mbl_closing_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
	//mbl_closing_energy = MUL(mbl_closing_energy, multibranch_helix_init_energy);
	//mbl_closing_energy = MUL(mbl_closing_energy, multibranch_closing_penalty);

	// No dangling:
	current_max = MAX_SUM(current_max, MUL4(this->energy_loops->WMB->x(i+1, j-1),
														this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
														multibranch_helix_init_energy,
														multibranch_closing_penalty));

	if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_WMB, i+1, j-1);
		pushed = true;
	}

	// i dangling:
	current_max = MAX_SUM(current_max, MUL6(this->energy_loops->WMB->x(i+2, j-1),
														i_dangle_energy,
														unpaired_nuc_in_mbl_energy,
														this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
														multibranch_helix_init_energy,
														multibranch_closing_penalty));

	if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_WMB, i+2, j-1);
		pushed = true;
	}

	// j dangling:
	current_max = MAX_SUM(current_max, MUL6(this->energy_loops->WMB->x(i+1, j-2),
														j_dangle_energy,
														unpaired_nuc_in_mbl_energy,
														this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
														multibranch_helix_init_energy,
														multibranch_closing_penalty));

	if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_WMB, i+1, j-2);
		pushed = true;
	}

	// ij mismatch:
	current_max = MAX_SUM(current_max, MUL6(this->energy_loops->WMB->x(i+2, j-2),
														ij_dangle_energy,
														two_unpaired_nuc_in_mbl_energy,
														this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
														multibranch_helix_init_energy,
														multibranch_closing_penalty));

	if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_WMB, i+2, j-2);
		pushed = true;
	}

if(_DUMP_V_MESSAGES_)
{
	double no_dangle = MUL4(this->energy_loops->WMB->x(i+1, j-1), multibranch_closing_penalty, multibranch_helix_init_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
	double i_dangle = MUL4(MUL3(i_dangle_energy, unpaired_nuc_in_mbl_energy, WMB->x(i+2, j-1)), multibranch_closing_penalty, multibranch_helix_init_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
	double j_dangle = MUL4(MUL3(j_dangle_energy, unpaired_nuc_in_mbl_energy, WMB->x(i+1, j-2)), multibranch_closing_penalty, multibranch_helix_init_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
	double ij_mm = MUL4(MUL3(ij_dangle_energy, two_unpaired_nuc_in_mbl_energy, WMB->x(i+2, j-2)), multibranch_closing_penalty, multibranch_helix_init_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));

	printf("V(%d, %d): no dangling energy: %lf, %lf\n",i,j,no_dangle, WMB->x(i+1, j-1));
	printf("V(%d, %d): i dangling energy: %lf, %lf: %lf\n",i,j,i_dangle, i_dangle_energy, WMB->x(i+2, j-1));
	printf("V(%d, %d): j dangling energy: %lf, %lf: %lf\n",i,j,j_dangle, j_dangle_energy, WMB->x(i+1, j-2));
	printf("V(%d, %d): ij dangling energy: %lf, %lf: %lf\n",i,j,ij_mm, ij_dangle_energy, WMB->x(i+2, j-2));
}

#endif // _TRANS_WMB_DANGLE_STACK_2_V_


#ifdef _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_
if(_DUMP_V_MESSAGES_)
	printf("Nonbroken j cases:\n");
	// Add 6 coaxial stacking cases: 3 for breakage between i and ip, 3 for breakage between jp and j.
	for(int ip = i + MIN_LOOP + 1; ip < j - MIN_LOOP; ip++)
	{
		// 1: Perfect stacking between i-j and ip-(j-1).
		double perfect_stacking_energy = ZERO;

		if(ip < j-1 && i+1 < ip-1)
		{
			perfect_stacking_energy = MUL3(this->x(ip,j-1),
											this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(j-1, ip, i, j),
											MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)));

			// Add unpaired nuc and helix init penalties.
			perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-1));
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			perfect_stacking_energy = MUL(perfect_stacking_energy, multibranch_closing_penalty);
		}

		// Update current cumulative.
		current_max = MAX_SUM(current_max, perfect_stacking_energy);


if(_DUMP_V_MESSAGES_)
		printf("perfect_stacking_energy: (%d, %d)-(%d, %d)=%.5f\n", i,ip, ip+1, j, current_max);

		if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, ip, j-1);

			// Choose W and WMB probabilistically.
			double w_wmb_max = MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1));
			if(COMPARE(W->x(i+1, ip-1), w_wmb_max))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, i+1, ip-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, i+1, ip-1);
			}

			pushed = true;
		}

		// 2: 
		// This is the energy of stacking of mismatched pair (i+1, j-1) on (i,j)
		double stack_on_ij_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(i, j, j-1, i+1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(j-2, ip, i+1, j-1);

		double imperfect_stacking_energy1 = ZERO;
		if(j-2 > ip && i+2 < ip-1)
		{
			imperfect_stacking_energy1 = MUL4(this->x(ip,j-2), 
												MAX_SUM(W->x(i+2, ip-1), WMB->x(i+2, ip-1)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-2));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, multibranch_closing_penalty);
		}

		// Update current cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
		{
			current_max = MAX_SUM(current_max, imperfect_stacking_energy1);
		}

		if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, ip,j-2);

			// Choose W and WMB probabilistically.
			double w_wmb_max = MAX_SUM(W->x(i+2, ip-1), WMB->x(i+2, ip-1));
			if(COMPARE(W->x(i+2, ip-1),  w_wmb_max))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, i+2, ip-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, i+2, ip-1);
			}

			pushed = true;
		}	

		// 3
		// This is the energy of stacking of mismatched pair (ip, j-1) on (ip+1, j-2)                           
		double stack_on_ip_p_j_nn_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-2, ip+1, ip, j-1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(j-1, ip, i, j);

		double imperfect_stacking_energy2 = ZERO;
		if(j-2 > ip+1 && ip-1 > i+1)
		{
			imperfect_stacking_energy2 = MUL4(this->x(ip+1,j-2), 
												MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)),
												stack_on_ip_p_j_nn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j-2));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, multibranch_closing_penalty);
		}

		// Update current cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[ip][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip, j-1))
		{
			current_max = MAX_SUM(current_max, imperfect_stacking_energy2);
		}

		if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, ip+1,j-2);

			// Choose W and WMB probabilistically.
			double w_wmb_max = MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1));
			if(COMPARE(W->x(i+1, ip-1), w_wmb_max))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, i+1, ip-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, i+1, ip-1);
			}

			pushed = true;
		}

if(_DUMP_V_MESSAGES_)
{
		printf("imperfect_stacking_energy2: (%d, %d)-(%d, %d)=%.5f\n", i,ip, ip+1, j, imperfect_stacking_energy2);
}

		//double coaxial_stacking_closing_energy = perfect_stacking_energy;
		//coaxial_stacking_closing_energy = MAX_SUM(coaxial_stacking_closing_energy, imperfect_stacking_energy1);
		//coaxial_stacking_closing_energy = MAX_SUM(coaxial_stacking_closing_energy, imperfect_stacking_energy2);
		//mbl_closing_energy = MAX_SUM(mbl_closing_energy, coaxial_stacking_closing_energy);
	}

#endif // _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_

#ifdef _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_
if(_DUMP_V_MESSAGES_)
	printf("Nonbroken i cases:\n");

	// Breakage between j and jp.
	//for(int jp = i+1 ; jp < j ; jp++)
	for(int jp = i + MIN_LOOP + 1; jp < j - MIN_LOOP; jp++)
	{
		// 1: Perfect stacking between (i+1, jp) and (i,j).
		double perfect_stacking_energy = ZERO;

		if(i+1 < jp && jp+1 < j-1)
		{
			perfect_stacking_energy = MUL3(this->x(i+1, jp),
											this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(i, j, jp, i+1),
											MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)));

			perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, jp));
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			perfect_stacking_energy = MUL(perfect_stacking_energy, multibranch_closing_penalty);
		}

		// Update current cumulative.
		current_max = MAX_SUM(current_max, perfect_stacking_energy);


if(_DUMP_V_MESSAGES_)
		printf("perfect_stacking_energy: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, current_max);


		if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i+1, jp);

			// Choose W and WMB probabilistically.
            double w_wmb_max = MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1));
            if(!pushed && COMPARE(W->x(jp+1, j-1), w_wmb_max))
            {
				this->energy_loops->tb_stack->push_substr(tb_W, jp+1, j-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, jp+1, j-1);
			}

			pushed = true;
		}

		// 2: Mismatching between
		double stack_on_ij_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(i, j, j-1, i+1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(i+1, j-1, jp, i+2);

		double imperfect_stacking_energy1 = ZERO;

		if(jp > i+2 && j-2 > jp+1)
		{
			imperfect_stacking_energy1 = MUL4(this->x(i+2,jp), 
												MAX_SUM(W->x(jp+1, j-2), WMB->x(jp+1, j-2)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, multibranch_closing_penalty);
		}

		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
		{			
			current_max = MAX_SUM(current_max, imperfect_stacking_energy1);
		}

		if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i+2,jp);

			// Choose W and WMB probabilistically.
			double w_wmb_max = MAX_SUM(W->x(jp+1, j-2), WMB->x(jp+1, j-2));
			if(COMPARE(W->x(jp+1, j-2), w_wmb_max))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, jp+1, j-2);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, jp+1, j-2);
			}

			pushed = true;
		}

		// 3
		// This is the energy of stacking of mismatched pair on (i, ip-1)
		double stack_on_ipjn_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(jp-1, i+2, i+1, jp);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(i, j, jp, i+1);

		double imperfect_stacking_energy2 = ZERO;
		if(i+2 < jp-1 && jp+1 < j-1)
		{
			imperfect_stacking_energy2 = MUL4(this->x(i+2,jp-1), 
												MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)),
												stack_on_ipjn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2);
		}

		// Add unpaired nuc and helix init penalties.
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp-1));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
		imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, multibranch_closing_penalty);

		// Update current cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][jp] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, jp))
		{
			current_max = MAX_SUM(current_max, imperfect_stacking_energy2);
		}

		if(!pushed && COMPARE(MUL(this->energy_loops->bp_prior(i,j), current_max), this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i+2,jp-1);

			// Choose W and WMB probabilistically.
			double w_wmb_max = MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1));
			if(COMPARE(W->x(jp+1, j-1), w_wmb_max))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, jp+1, j-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, jp+1, j-1);
			}

			pushed = true;
		}

//if(_DUMP_V_MESSAGES_)
//		printf("imperfect_stacking_energy2: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, imperfect_stacking_energy2);

		//double coaxial_stacking_closing_energy = perfect_stacking_energy;
		//coaxial_stacking_closing_energy = MAX_SUM(coaxial_stacking_closing_energy, imperfect_stacking_energy1);
		//coaxial_stacking_closing_energy = MAX_SUM(coaxial_stacking_closing_energy, imperfect_stacking_energy2);
		//mbl_closing_energy = MAX_SUM(mbl_closing_energy, coaxial_stacking_closing_energy);
	}
	// End of coaxial stacking cases.
#endif // _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_

	// Add the helix init and multibranch closure penalties.
	//mbl_closing_energy = MUL(mbl_closing_energy, multibranch_helix_init_energy);
	if(!COMPARE(this->x(i,j), MUL(this->energy_loops->bp_prior(i,j), current_max)))
	{
		printf("Stochastic Traceback error in V min energy traceback @ %s(%d): %.25f, %.25f\n", __FILE__, __LINE__, this->x(i,j), current_max);
		exit(0);
	}
}

void t_V::stoch_energy_tb(int i, int j)
{
//	printf("---------------------------------------------------\n");
if(_DUMP_V_MESSAGES_)
	printf("Stochastic backtracking V(%d, %d)\n", i,j);
//	getc(stdin);

	// Check MIN_LOOP constraint.
	// If the nucleotides are not pairable, do not bother computation, assign infinity to
	// current array value and return.
	if((j-i-1) < MIN_LOOP || 
		!pairable[rna_seq->numseq[i]][rna_seq->numseq[j]])
	{
		printf("Trackback error while backtracking %d, %d @ %s(%d)\n", i, j, __FILE__, __LINE__);
		exit(0);
	}
	else
	{
		//printf("Computing!!!\n");
		//printf("%d and %d are pairable: %c-%c\n", i,j, rna_seq->nucs[i], rna_seq->nucs[j]);
	}

	// Following code is borrowed from pfunction.
	int before = 0;
	if (i>1 && j < rna_seq->numofbases)
	{
		before = pairable[rna_seq->numseq[i-1]][rna_seq->numseq[j+1]];
	}


	int after = 0;
	if((((j-i) > MIN_LOOP + 2)&&(j<=rna_seq->numofbases))&&(i < rna_seq->numofbases)) {
		after = pairable[rna_seq->numseq[i+1]][rna_seq->numseq[j-1]];

	}
	else after = 0;

	//if there are no stackable pairs to i.j then don't allow a pair i,j
	if ((before==0)&&(after==0)) 
	{
		printf("Trackback error @ %s(%d)\n", __FILE__, __LINE__);
		exit(0);
	}

	// Add this base pair.
	this->energy_loops->stoch_energy_strs->add_bp(i,j);

	// Start backtracking.
	double random_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), this->x(i,j));
	double current_cumulative = ZERO;

	//printf("Backtracking V(%d, %d): %.15f\n", i,j, log(random_cumulative));

	bool pushed = false;

	t_WMB* WMB = this->energy_loops->WMB;
	t_W* W = this->energy_loops->W;
	t_Wcoax* Wcoax = this->energy_loops->Wcoax;

	// Hairpin.
#ifdef _TRANS_HP_LOOP_2_V_
	double energy_closing_hairpin = this->energy_loops->thermo_pars->hairpin_energy(i, j);

	// Update current_cumulative.
	if(this->energy_loops->folding_constraints->check_hairpin_loop(i,j))
	{
		current_cumulative = MAX_SUM(current_cumulative, energy_closing_hairpin);

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			pushed = true;
		}
	}
#endif // _TRANS_HP_LOOP_2_V_

#ifdef _TRANS_V_INT_LOOP_2_V_
	// Internal.
	// Need a double loop for searching for internal loops.
	double energy_closing_interior = ZERO;

	for(int inner_i = i+1; inner_i < j; inner_i++)
	{
		for(int inner_j = j-1; inner_j > inner_i; inner_j--)
		{
			// Exclude the internal loop where loop is just stacking of this base pair on next base pair.
			if(!(inner_i == i+1 && inner_j == j-1))
			{
				int fp_size = abs(i - inner_i) - 1;
				int tp_size = abs(j - inner_j) - 1;
				int size = fp_size + tp_size;

				if(size <= MAX_INT_LOOP_SIZE && 
					(inner_j - inner_i) > MIN_LOOP && 
					this->energy_loops->folding_constraints->pairing_map[inner_i][inner_j])
				{
				if(this->energy_loops->folding_constraints->check_internal_loop(i, j, inner_i, inner_j))
				{
					double energy_closing_current_interior = MUL(this->x(inner_i, inner_j), 
																this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j));

					//double ij_term_pen = this->energy_loops->thermo_pars->terminal_pair_penalty(i,j);
					//double inner_ij_term_pen = this->energy_loops->thermo_pars->terminal_pair_penalty(inner_i,inner_j);

if(_DUMP_V_MESSAGES_)
{
#ifdef _LINEAR_NNM_COMPUTATIONS_
					double log_correction = log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, inner_j-inner_i+1));
					double int_log_correction = log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, size+2));
					printf("V(%d, %d) + Internal(%d,%d)-(%d,%d) = %.5f + %.5f = %.15f\n", inner_i, inner_j, i, j, inner_i, inner_j, log(this->x(inner_i, inner_j))-log_correction, log(this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j)) - int_log_correction, log(energy_closing_current_interior) - (log_correction + int_log_correction));
#endif

#ifdef _LOG_NNM_COMPUTATIONS_
					printf("V(%d, %d) + Internal(%d,%d)-(%d,%d) = %.5f + %.5f = %.5f\n", inner_i, inner_j, i, j, inner_i, inner_j, this->x(inner_i, inner_j), this->energy_loops->thermo_pars->interior_energy(i, j, inner_i, inner_j), energy_closing_current_interior);
#endif
}

					//energy_closing_interior = MAX_SUM(energy_closing_interior, energy_closing_current_interior);

					// Update current_cumulative.
					current_cumulative = MAX_SUM(current_cumulative, energy_closing_current_interior);

					if(!pushed && GEQ(current_cumulative, random_cumulative))
					{
						//printf("Internal!\n");
						this->energy_loops->tb_stack->push_substr(tb_V, inner_i, inner_j);
						pushed = true;
					}
				} // same loop check for nucleotides in the internal loop.
				} // pairing and max int loop size checks.
			} // Exclude stacked pairs as a consideration for interior loops.
		} // inner_j loop.
	} // inner_i loop.

	// Stacked base pair.
	double stacked_energy = MUL(this->x(i+1, j-1), this->energy_loops->thermo_pars->bp_stack_energy(i,j, j-1, i+1));

	// Update current_cumulative.
	current_cumulative = MAX_SUM(current_cumulative, stacked_energy);

	if(!pushed && GEQ(current_cumulative, random_cumulative))
	{
		//printf("Stack!\n");
		this->energy_loops->tb_stack->push_substr(tb_V, i+1, j-1);
		pushed = true;
	}
#endif // _TRANS_V_INT_LOOP_2_V_

	// Multibranch.
	// Consider the stacking on top of closing i-j base pair.
	double multibranch_closing_penalty = this->energy_loops->thermo_pars->MBL_closure_penalty;
	double multibranch_helix_init_energy = this->energy_loops->thermo_pars->per_helix_penalty;
	double two_multibranch_helix_init_energy = MUL(multibranch_helix_init_energy, multibranch_helix_init_energy);
	double unpaired_nuc_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	double two_unpaired_nuc_in_mbl_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

	// Consider the dangling ends here. i+1 and j-1 can dangle. Consider all 4 cases.
	double i_dangle_energy = this->energy_loops->thermo_pars->dangle_tp_energy(i,j,i+1);
	double j_dangle_energy = this->energy_loops->thermo_pars->dangle_fp_energy(i,j,j-1);
	double ij_dangle_energy = this->energy_loops->thermo_pars->mbl_mismatch_energy(i,j,j-1,i+1);

#ifdef _TRANS_WMB_DANGLE_STACK_2_V_
	// Choose min of 4 cases
	double mbl_closing_energy = this->energy_loops->WMB->x(i+1, j-1);
	mbl_closing_energy = MAX_SUM(mbl_closing_energy, MUL3(i_dangle_energy, unpaired_nuc_in_mbl_energy, WMB->x(i+2, j-1)));
	mbl_closing_energy = MAX_SUM(mbl_closing_energy, MUL3(j_dangle_energy, unpaired_nuc_in_mbl_energy, WMB->x(i+1, j-2)));
	mbl_closing_energy = MAX_SUM(mbl_closing_energy, MUL3(ij_dangle_energy, two_unpaired_nuc_in_mbl_energy, WMB->x(i+2, j-2)));
	mbl_closing_energy = MUL(mbl_closing_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
	mbl_closing_energy = MUL(mbl_closing_energy, multibranch_helix_init_energy);
	mbl_closing_energy = MUL(mbl_closing_energy, multibranch_closing_penalty);

	// No dangling:
	current_cumulative = MAX_SUM(current_cumulative, MUL4(this->energy_loops->WMB->x(i+1, j-1),
														this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
														multibranch_helix_init_energy,
														multibranch_closing_penalty));

	if(!pushed && GEQ(current_cumulative, random_cumulative))
	{
		this->energy_loops->tb_stack->push_substr(tb_WMB, i+1, j-1);
		pushed = true;
	}

	// i dangling:
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1))
	{
		current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+2, j-1),
															i_dangle_energy,
															unpaired_nuc_in_mbl_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
															multibranch_helix_init_energy,
															multibranch_closing_penalty));

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_WMB, i+2, j-1);
			this->energy_loops->stoch_energy_strs->add_tp_nuc_dangling_on_mb_closure(i+1);
			pushed = true;
		}
	}

	// j dangling:
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(j-1))
	{
		current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+1, j-2),
															j_dangle_energy,
															unpaired_nuc_in_mbl_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
															multibranch_helix_init_energy,
															multibranch_closing_penalty));

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_WMB, i+1, j-2);
			this->energy_loops->stoch_energy_strs->add_fp_nuc_dangling_on_mb_closure(j-1);
			pushed = true;
		}
	}

	// ij mismatch:
	if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
		!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
	{
		current_cumulative = MAX_SUM(current_cumulative, MUL6(this->energy_loops->WMB->x(i+2, j-2),
															ij_dangle_energy,
															two_unpaired_nuc_in_mbl_energy,
															this->energy_loops->thermo_pars->terminal_pair_penalty(i,j),
															multibranch_helix_init_energy,
															multibranch_closing_penalty));

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_WMB, i+2, j-2);
			this->energy_loops->stoch_energy_strs->add_mm_pair_on_mb_closure(j-1, i+1);
			pushed = true;
		}
	}

if(_DUMP_V_MESSAGES_)
{
#ifdef _LINEAR_NNM_COMPUTATIONS_
	printf("Hairpin closing V(%d, %d) = %.5f\n", i,j,  log(energy_closing_hairpin) - log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, j-i+1)));
	printf("Internal loop closing V(%d, %d) = %.5f\n", i,j, log(energy_closing_interior) - log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, j-i+1)));
	printf("Stacked pair V(%d, %d) = %.5f\n", i,j, log(stacked_energy) - log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, j-i+1)));
	printf("MBL closing V(%d, %d) = %.5f\n", i,j, log(mbl_closing_energy) - log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, j-i+1)));
	printf("V(%d, %d) = %.5f\n", i,j, log(this->x(i,j)) - log(POW(this->energy_loops->thermo_pars->scaling_per_nuc, j-i+1)));
#endif // _LINEAR_NNM_COMPUTATIONS_

#ifdef _LOG_NNM_COMPUTATIONS_
	printf("Hairpin closing V(%d, %d) = %.5f\n", i,j,  energy_closing_hairpin);
	printf("Internal loop closing V(%d, %d) = %.5f\n", i,j, energy_closing_interior);
	printf("Stacked pair V(%d, %d) = %.5f\n", i,j, stacked_energy);
	printf("MBL closing V(%d, %d) = %.5f\n", i,j, mbl_closing_energy);
	printf("V(%d, %d) = %.5f\n", i,j, this->x(i,j));
#endif // _LOG_NNM_COMPUTATIONS_
}
#endif // _TRANS_WMB_DANGLE_STACK_2_V_


#ifdef _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_
if(_DUMP_V_MESSAGES_)
	printf("Nonbroken j cases:\n");
	// Add 6 coaxial stacking cases: 3 for breakage between i and ip, 3 for breakage between jp and j.
	for(int ip = i + MIN_LOOP + 1; ip < j - MIN_LOOP; ip++)
	{
		// 1: Perfect stacking between i-j and ip-(j-1).
		double perfect_stacking_energy = ZERO;

		if(ip < j-1 && i+1 < ip-1)
		{
			perfect_stacking_energy = MUL3(this->x(ip,j-1),
											this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(j-1, ip, i, j),
											MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)));

			// Add unpaired nuc and helix init penalties.
			perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-1));
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			perfect_stacking_energy = MUL(perfect_stacking_energy, multibranch_closing_penalty);
			current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);
		}	

if(_DUMP_V_MESSAGES_)
		printf("perfect_stacking_energy: (%d, %d)-(%d, %d)=%.5f\n", i,ip, ip+1, j, current_cumulative);

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, ip, j-1);

			// Choose W and WMB probabilistically.
			double w_wmb_cumulative = MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1));
			double random_w_wmb_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), w_wmb_cumulative);
			if(GEQ(W->x(i+1, ip-1), random_w_wmb_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, i+1, ip-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, i+1, ip-1);
			}

			pushed = true;
		}

		// 2: 
		// This is the energy of stacking of mismatched pair (i+1, j-1) on (i,j)
		double stack_on_ij_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(i, j, j-1, i+1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(j-2, ip, i+1, j-1);

		double imperfect_stacking_energy1 = ZERO;
		if(j-2 > ip && i+2 < ip-1)
		{
			imperfect_stacking_energy1 = MUL4(this->x(ip,j-2), 
												MAX_SUM(W->x(i+2, ip-1), WMB->x(i+2, ip-1)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(ip,j-2));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, multibranch_closing_penalty);
		}

		// Update current cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy1);
		}

if(_DUMP_V_MESSAGES_)
{
		printf("imperfect_stacking_energy1: (%d, %d)-(%d, %d)=%.5f\n", i,ip, ip+1, j, current_cumulative);
}

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, ip,j-2);

			// Choose W and WMB probabilistically.
			double w_wmb_cumulative = MAX_SUM(W->x(i+2, ip-1), WMB->x(i+2, ip-1));
			double random_w_wmb_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), w_wmb_cumulative);
			if(GEQ(W->x(i+2, ip-1), random_w_wmb_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, i+2, ip-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, i+2, ip-1);
			}

			pushed = true;
		}	

		// 3
		// This is the energy of stacking of mismatched pair (ip, j-1) on (ip+1, j-2)                           
		double stack_on_ip_p_j_nn_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-2, ip+1, ip, j-1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(j-1, ip, i, j);

		double imperfect_stacking_energy2 = ZERO;
		if(j-2 > ip+1 && ip-1 > i+1)
		{
			imperfect_stacking_energy2 = MUL4(this->x(ip+1,j-2), 
												MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1)),
												stack_on_ip_p_j_nn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j-2));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, multibranch_closing_penalty);
		}

		// Update current cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[ip][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip, j-1))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy2);
		}

if(_DUMP_V_MESSAGES_)
{
		printf("imperfect_stacking_energy2: (%d, %d)-(%d, %d)=%.5f\n", i,ip, ip+1, j, current_cumulative);
}

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, ip+1,j-2);

			// Choose W and WMB probabilistically.
			double w_wmb_cumulative = MAX_SUM(W->x(i+1, ip-1), WMB->x(i+1, ip-1));
			double random_w_wmb_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), w_wmb_cumulative);
			if(GEQ(W->x(i+1, ip-1), random_w_wmb_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, i+1, ip-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, i+1, ip-1);
			}

			pushed = true;
		}

		//double coaxial_stacking_closing_energy = perfect_stacking_energy;
		//coaxial_stacking_closing_energy = MAX_SUM(coaxial_stacking_closing_energy, imperfect_stacking_energy1);
		//coaxial_stacking_closing_energy = MAX_SUM(coaxial_stacking_closing_energy, imperfect_stacking_energy2);
		//mbl_closing_energy = MAX_SUM(mbl_closing_energy, coaxial_stacking_closing_energy);
	}

#endif // _TRANS_fp_W_WMB_CONCAT_tp_V_COAX_STACK_2_V_

#ifdef _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_
if(_DUMP_V_MESSAGES_)
	printf("Nonbroken i cases:\n");

	// Breakage between j and jp.
	for(int jp = i + MIN_LOOP + 1; jp < j - MIN_LOOP; jp++)
	{
		// 1: Perfect stacking between (i+1, jp) and (i,j).
		double perfect_stacking_energy = ZERO;

		if(i+1 < jp && jp+1 < j-1)
		{
			perfect_stacking_energy = MUL3(this->x(i+1, jp),
											this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(i, j, jp, i+1),
											MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)));

			perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i+1, jp));
			perfect_stacking_energy = MUL(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			perfect_stacking_energy = MUL(perfect_stacking_energy, multibranch_closing_penalty);

			// Update current cumulative.
			current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);
		}

if(_DUMP_V_MESSAGES_)
		printf("perfect_stacking_energy: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, current_cumulative);

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i+1, jp);

			// Choose W and WMB probabilistically.
			double w_wmb_cumulative = MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1));
			double random_w_wmb_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), w_wmb_cumulative);
			if(GEQ(W->x(jp+1, j-1), random_w_wmb_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, jp+1, j-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, jp+1, j-1);
			}

			pushed = true;
		}

		// 2: Mismatching between
		double stack_on_ij_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(i, j, j-1, i+1);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(i+1, j-1, jp, i+2);

		double imperfect_stacking_energy1 = ZERO;

		if(jp > i+2 && j-2 > jp+1)
		{
			imperfect_stacking_energy1 = MUL4(this->x(i+2,jp), 
												MAX_SUM(W->x(jp+1, j-2), WMB->x(jp+1, j-2)),
												stack_on_ij_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, multibranch_closing_penalty);
		}

		// Update current cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][j-1] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, j-1))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy1);
		}

if(_DUMP_V_MESSAGES_)
		printf("imperfect_stacking_energy1: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, current_cumulative);

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i+2,jp);

			// Choose W and WMB probabilistically.
			double w_wmb_cumulative = MAX_SUM(W->x(jp+1, j-2), WMB->x(jp+1, j-2));
			double random_w_wmb_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), w_wmb_cumulative);
			if(GEQ(W->x(jp+1, j-2), random_w_wmb_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, jp+1, j-2);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, jp+1, j-2);
			}

			pushed = true;
		}

		// 3
		// This is the energy of stacking of mismatched pair on (i, ip-1)
		double stack_on_ipjn_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(jp-1, i+2, i+1, jp);

		// This is the energy of coaxial stacking.
		double energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(i, j, jp, i+1);

		double imperfect_stacking_energy2 = ZERO;
		if(i+2 < jp-1 && jp+1 < j-1)
		{
			imperfect_stacking_energy2 = MUL4(this->x(i+2,jp-1), 
												MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1)),
												stack_on_ipjn_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2);

			// Add unpaired nuc and helix init penalties.
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i+2,jp-1));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,j));
			imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, multibranch_closing_penalty);
		}

		// Update current cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[i+1][jp] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i+1, jp))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy2);
		}

if(_DUMP_V_MESSAGES_)
		printf("imperfect_stacking_energy2: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, current_cumulative);

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i+2,jp-1);

			// Choose W and WMB probabilistically.
			double w_wmb_cumulative = MAX_SUM(W->x(jp+1, j-1), WMB->x(jp+1, j-1));
			double random_w_wmb_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), w_wmb_cumulative);
			if(GEQ(W->x(jp+1, j-1), random_w_wmb_cumulative))
			{
				this->energy_loops->tb_stack->push_substr(tb_W, jp+1, j-1);
			}
			else
			{
				this->energy_loops->tb_stack->push_substr(tb_WMB, jp+1, j-1);
			}

			pushed = true;
		}

//if(_DUMP_V_MESSAGES_)
//		printf("imperfect_stacking_energy2: (%d, %d)-(%d, %d)=%.5f\n", i,jp, jp+1, j, imperfect_stacking_energy2);

		//double coaxial_stacking_closing_energy = perfect_stacking_energy;
		//coaxial_stacking_closing_energy = MAX_SUM(coaxial_stacking_closing_energy, imperfect_stacking_energy1);
		//coaxial_stacking_closing_energy = MAX_SUM(coaxial_stacking_closing_energy, imperfect_stacking_energy2);
		//mbl_closing_energy = MAX_SUM(mbl_closing_energy, coaxial_stacking_closing_energy);
	}
	// End of coaxial stacking cases.

	// Add the helix init and multibranch closure penalties.
	//mbl_closing_energy = MUL(mbl_closing_energy, multibranch_helix_init_energy);

#endif // _TRANS_fp_V_COAX_STACK_V_CONCAT_tp_W_WMB_2_V_

	if(!pushed  || !COMPARE(this->x(i,j), current_cumulative))
	{
		printf("Stochastic Traceback error in V(%d, %d) energy traceback @ %s(%d): %.15f, %.15f (%d)\n", i,j,__FILE__, __LINE__, log(this->x(i,j)), log(current_cumulative), pushed);

		//_DUMP_V_MESSAGES_ = true;
		this->compute(i,j);
		printf("After computing: %lf\n", this->x(i,j));

		exit(0);
	}

} // t_V::stoch_energy_tb


