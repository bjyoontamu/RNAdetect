#ifndef _MIN_ENERGY_STRUCTURE_
#define _MIN_ENERGY_STRUCTURE_

class t_min_energy_structure
{
public:
	t_min_energy_structure(t_energy_loops* _energy_loops);
	~t_min_energy_structure();

	t_energy_loops* energy_loops;

	// Base pairs.
	int* bps;

	void add_bp(int i, int j);
	void dump();
};

#endif // _MIN_ENERGY_STRUCTURE_


