#include <stdio.h>
#include <stdlib.h>
#include "v.h"
#include "wl.h"
#include "w.h"
#include "energy_array.h"
#include "energy_loops.h"
#include "nnm_math.h"
#include "tb_stack.h"
#include "sampling_math.h"
#include "../structure/structure.h"
#include "thermo_parameters.h"
#include "../structure/folding_constraints.h"

#include "coinc_info.h"

bool _DUMP_W_MESSAGES_ = false;

t_W::t_W(t_energy_loops* _energy_loops)
{
	this->energy_loops = _energy_loops;

	// Allocate energy array.
	this->energy_array = new t_energy_array(energy_loops->rna_seq);
	this->ext_energy_array = new t_energy_array(energy_loops->rna_seq);

	// Copy rna sequence pointer for later use.
	this->rna_seq = this->energy_loops->rna_seq;

	// Set MAX_SUM function.
	this->MAX_SUM = this->energy_loops->MAX_SUM;
}

// Free the energy array.
t_W::~t_W()
{
	delete(this->energy_array);
	delete(this->ext_energy_array);
}

void t_W::compute(int i, int j)
{	
	this->x(i, j) = ZERO;

	if(!this->energy_loops->folding_constraints->str_coinc_map[i][j])
	{
		return;
	}

	t_WL* WL = this->energy_loops->WL;

	// Get dangling and unpaired nucleotide energies.
	double unpaired_nuc_in_MBL_energy = (this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

	// Choose minimum energy case.
#ifdef _TRANS_WL_2_W_
	this->x(i, j) = WL->x(i,j);
#endif // _TRANS_WL_2_W_

#ifdef _TRANS_W_3p_EXT_2_W_
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
		this->x(i, j) = MAX_SUM(this->x(i, j), MUL(this->x(i, j-1), unpaired_nuc_in_MBL_energy));
#endif // _TRANS_W_3p_EXT_2_W_

	this->x(i, j) = MUL(this->x(i, j), this->energy_loops->w_coinc_prior(i,j));
} // t_W::compute

double& t_W::x(int i, int j)
{
	return(this->energy_array->x(i,j));
}

void t_W::min_energy_tb(int i, int j)
{
	// Generate the random cumulative.
	double current_max = ZERO;

	bool pushed = false;

	t_WL* WL = this->energy_loops->WL;

	// Get dangling and unpaired nucleotide energies.
	double unpaired_nuc_in_MBL_energy = (this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_WL_2_W_
	current_max = WL->x(i,j);

	// Choose minimum energy case.
	if(!pushed && COMPARE(MUL(current_max, this->energy_loops->w_coinc_prior(i,j)), this->x(i,j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_WL, i, j);
		pushed = true;
	}
#endif // _TRANS_WL_2_W_

#ifdef _TRANS_W_3p_EXT_2_W_
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
		current_max = MAX_SUM(current_max, MUL(this->x(i, j-1), unpaired_nuc_in_MBL_energy));

	if(!pushed && COMPARE(MUL(current_max, this->energy_loops->w_coinc_prior(i,j)), this->x(i,j)))
	{
		this->energy_loops->tb_stack->push_substr(tb_W, i, j-1);
		pushed = true;
	}
#endif // _TRANS_W_3p_EXT_2_W_

	if(!pushed && COMPARE(MUL(current_max, this->energy_loops->w_coinc_prior(i,j)), this->x(i,j)))
	{
		printf("Traceback error in W(%d, %d) @ %s(%d): %.5f <->  %.5f\n", i, j, __FILE__, __LINE__, this->x(i,j), current_max);
		exit(0);
	}
}

void t_W::stoch_energy_tb(int i, int j)
{
	// Generate the random cumulative.
	double random_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), this->x(i,j));

	double current_cumulative = ZERO;

	bool pushed = false;

	t_WL* WL = this->energy_loops->WL;

	// Get dangling and unpaired nucleotide energies.
	double unpaired_nuc_in_MBL_energy = (this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_WL_2_W_
	current_cumulative = WL->x(i,j);

	// Choose minimum energy case.
	if(!pushed && GEQ(current_cumulative, random_cumulative))
	{
		this->energy_loops->tb_stack->push_substr(tb_WL, i, j);
		pushed = true;
	}
#endif // _TRANS_WL_2_W_


#ifdef _TRANS_W_3p_EXT_2_W_
	if(!this->energy_loops->folding_constraints->forbid_non_v_emission(j))
		current_cumulative = MAX_SUM(current_cumulative, MUL(this->x(i, j-1), unpaired_nuc_in_MBL_energy));

	if(!pushed && GEQ(current_cumulative, random_cumulative))
	{
		this->energy_loops->tb_stack->push_substr(tb_W, i, j-1);
		pushed = true;
	}
#endif // _TRANS_W_3p_EXT_2_W_

	if(!COMPARE(this->x(i,j), current_cumulative))
	{
		printf("Traceback error in W(%d, %d) stochastic traceback @ %s(%d): %.5f <->  %.5f\n", i, j, __FILE__, __LINE__, this->x(i,j), current_cumulative);
		exit(0);
	}
}

