#include <stdio.h>
#include <stdlib.h>

#include "sampling_math.h"

#include "wcoax.h"
#include "v.h"
#include "wmb.h"
#include "energy_array.h"
#include "energy_loops.h"

#include "nnm_math.h"
#include "tb_stack.h"
#include "min_energy_structure.h"
#include "stoch_energy_structures.h"
#include "../structure/structure.h"
#include "thermo_parameters.h"
#include "../structure/folding_constraints.h"

bool _DUMP_WCOAX_MESSAGES_ = false;

t_Wcoax::t_Wcoax(t_energy_loops* _energy_loops)
{
	this->energy_loops = _energy_loops;

	// Allocate energy array.
	this->energy_array = new t_energy_array(energy_loops->rna_seq);
	this->ext_energy_array = new t_energy_array(energy_loops->rna_seq);

	// Copy rna sequence pointer for later use.
	this->rna_seq = this->energy_loops->rna_seq;

	// Set the max/sum function for this array.
	this->MAX_SUM = (this->energy_loops->MAX_SUM);
}

// Free the energy array.
t_Wcoax::~t_Wcoax()
{
	delete(this->energy_array);
	delete(this->ext_energy_array);
}

double& t_Wcoax::x(int i, int j)
{
	return(this->energy_array->x(i,j));
}

/*
Wcoax array searches for ip such that there is a coaxial stacking between 
structures of subsequences (i, ip) and (ip+1, j).
*/
void t_Wcoax::compute(int i, int j)
{	
	if(!this->energy_loops->folding_constraints->str_coinc_map[i][j])
	{
		this->x(i,j) = ZERO;
		return;
	}

	this->x(i,j) = ZERO;

	t_V* V = this->energy_loops->V;

	double multibranch_helix_init_energy = this->energy_loops->thermo_pars->per_helix_penalty;
	double two_multibranch_helix_init_energy = MUL(multibranch_helix_init_energy, multibranch_helix_init_energy);
	double unpaired_nuc_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	double two_unpaired_nuc_in_mbl_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_V_COAX_STACK_2_Wcoax_
	for(int ip = i + MIN_LOOP+1; ip < j-MIN_LOOP-1; ip++)
	{
		// Find minimum coaxially stacked configuration:
		// 1) Immediate stacking of helices: Coaxial stacking of V arrays.
		// 2) Stacking of (i+1, ip-1) and (ip+2, j) by non-canonical base pair at (i,ip+1).
		// 3) Stacking of (i,ip) and (ip+2, j-1) by non-canonical base pair at (ip+1, j).

		// Consider all 3 cases of stacking and return max/sum energy.
		//double perfect_stacking_energy = MUL3(V->x(i,ip),
		//										this->energy_loops->V->x(ip+1,j),
		//										this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1));

		//// Add unpaired nuc and helix init penalties.
		//perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
		//perfect_stacking_energy = MUL3(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
		//								this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));


		double perfect_stacking_energy = MUL6(V->x(i,ip),
												this->energy_loops->V->x(ip+1,j),
												this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1),
												two_multibranch_helix_init_energy, 
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));


		//// Add unpaired nuc and helix init penalties.
		//perfect_stacking_energy = MUL(perfect_stacking_energy, two_multibranch_helix_init_energy);
		//perfect_stacking_energy = MUL3(perfect_stacking_energy, this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
		//								this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));


		if(_DUMP_WCOAX_MESSAGES_)
		{
			printf("Wcoax(%d, %d) perfect: V(%d, %d)-V(%d,%d) = %lf x %lf x %lf = %lf\n", i,j, i, ip, ip+1, j, 
				V->x(i,ip), 
				V->x(ip+1,j), 
				this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1),
				perfect_stacking_energy);
		}
		// One of the imperfect coax. stacking is by noncanonical pairing of i and ip.
		double stack_i_p_ip_n_in_coax_stack_energy = ZERO;
		double energy_imperfect_coaxial_stack1 = ZERO;
		if(ip+1 <= this->energy_loops->rna_seq->numofbases)
		{
			stack_i_p_ip_n_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(ip-1, i+1, i, ip);

			// This is the energy of coaxial stacking.
			energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);
		}

		double imperfect_stacking_energy1 = ZERO;


		//imperfect_stacking_energy1 = MUL4(V->x(i+1,ip-1), 
		//										V->x(ip+1,j),
		//										stack_i_p_ip_n_in_coax_stack_energy, 
		//										energy_imperfect_coaxial_stack1);

		//// Add unpaired nuc and helix init penalties.
		//imperfect_stacking_energy1 = MUL(imperfect_stacking_energy1, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
		//imperfect_stacking_energy1 = MUL3(imperfect_stacking_energy1, this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
		//								this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));

		imperfect_stacking_energy1 = MUL8(V->x(i+1,ip-1), 
												V->x(ip+1,j),
												stack_i_p_ip_n_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1, 
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));

		// Other imperfect stacking is by noncanonical pairing of ip+1 and j.
		double stack_ipp_j_in_coax_stack_energy = ZERO;
		double energy_imperfect_coaxial_stack2 = ZERO;

		if(j-1 > ip+2)
		{
			energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);
			stack_ipp_j_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-1, ip+2, ip+1, j);
		}

		//double imperfect_stacking_energy2 = MUL4(V->x(i,ip), 
		//										V->x(ip+2,j-1), 
		//										stack_ipp_j_in_coax_stack_energy, 
		//										energy_imperfect_coaxial_stack2);

		//// Add unpaired nuc and helix init penalties.
		//imperfect_stacking_energy2 = MUL(imperfect_stacking_energy2, MUL(two_multibranch_helix_init_energy, two_unpaired_nuc_in_mbl_energy));
		//imperfect_stacking_energy2 = MUL3(imperfect_stacking_energy2, this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
		//								this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1));

		double imperfect_stacking_energy2 = MUL8(V->x(i,ip), 
												V->x(ip+2,j-1), 
												stack_ipp_j_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2,
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1));

		// Compute final stacking energy and return it.
		this->x(i,j) = this->energy_loops->MAX_SUM(this->x(i,j), perfect_stacking_energy);

		if(this->energy_loops->folding_constraints->str_coinc_map[i][ip] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(i, ip))
		{
			this->x(i,j) = this->energy_loops->MAX_SUM(this->x(i,j), imperfect_stacking_energy1);
		}

		if(this->energy_loops->folding_constraints->str_coinc_map[ip+1][j] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip+1, j))
		{
			this->x(i,j) = this->energy_loops->MAX_SUM(this->x(i,j), imperfect_stacking_energy2);
		}


if(_DUMP_WCOAX_MESSAGES_)
		printf("Wcoax(%d, %d) = %.5f (%.5f)\n", i,j, this->x(i,j), perfect_stacking_energy);

	} // ip loop for enumerating all 
#endif // _TRANS_V_COAX_STACK_2_Wcoax_
}

void t_Wcoax::min_energy_tb(int i, int j)
{
	t_WMB* WMB = this->energy_loops->WMB;
	t_W* W = this->energy_loops->W;

	bool pushed = false;

	double current_max = ZERO;

	t_V* V = this->energy_loops->V;

	double multibranch_helix_init_energy = this->energy_loops->thermo_pars->per_helix_penalty;
	double two_multibranch_helix_init_energy = MUL(multibranch_helix_init_energy, multibranch_helix_init_energy);
	double unpaired_nuc_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	double two_unpaired_nuc_in_mbl_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_V_COAX_STACK_2_Wcoax_
	for(int ip = i + MIN_LOOP+1; ip < j-MIN_LOOP-1; ip++)
	{
		// Find minimum coaxially stacked configuration:
		// 1) Immediate stacking of helices: Coaxial stacking of V arrays.
		// 2) Stacking of (i+1, ip-1) and (ip+2, j) by non-canonical base pair at (i,ip+1).
		// 3) Stacking of (i,ip) and (ip+2, j-1) by non-canonical base pair at (ip+1, j).


		// Consider all 3 cases of stacking and return max/sum energy.
		double perfect_stacking_energy = MUL6(V->x(i,ip),
												this->energy_loops->V->x(ip+1,j),
												this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1),
												two_multibranch_helix_init_energy, 
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));

		if(_DUMP_WCOAX_MESSAGES_)
		{
			printf("Wcoax(%d, %d) perfect: V(%d, %d)-V(%d,%d) = %lf x %lf x %lf = %lf\n", i,j, i, ip, ip+1, j, 
				V->x(i,ip), 
				V->x(ip+1,j), 
				this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1),
				perfect_stacking_energy);
		}

		// Update and check current_cumulative.
		current_max = MAX_SUM(current_max, perfect_stacking_energy);
		if(!pushed && COMPARE(current_max, this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i, ip);
			this->energy_loops->tb_stack->push_substr(tb_V, ip+1, j);
			pushed = true;
		}

		// One of the imperfect coax. stacking is by noncanonical pairing of i and ip.
		double stack_i_p_ip_n_in_coax_stack_energy = ZERO;
		double energy_imperfect_coaxial_stack1 = ZERO;
		if(ip+1 <= this->energy_loops->rna_seq->numofbases)
		{
			stack_i_p_ip_n_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(ip-1, i+1, i, ip);

			// This is the energy of coaxial stacking.
			energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);
		}

		double imperfect_stacking_energy1 = ZERO;

		imperfect_stacking_energy1 = MUL8(V->x(i+1,ip-1), 
												V->x(ip+1,j),
												stack_i_p_ip_n_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1, 
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));

		// Update and check current_cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[i][ip] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip, i))
		{
			current_max = MAX_SUM(current_max, imperfect_stacking_energy1);
		}

		if(!pushed && COMPARE(current_max, this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i+1, ip-1);
			this->energy_loops->tb_stack->push_substr(tb_V, ip+1, j);
			pushed = true;
		}

		// Other imperfect stacking is by noncanonical pairing of ip+1 and j.
		double stack_ipp_j_in_coax_stack_energy = ZERO;
		double energy_imperfect_coaxial_stack2 = ZERO;

		if(j-1 > ip+2)
		{
			energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);
			stack_ipp_j_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-1, ip+2, ip+1, j);
		}

		double imperfect_stacking_energy2 = MUL8(V->x(i,ip), 
												V->x(ip+2,j-1), 
												stack_ipp_j_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2,
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1));

		// Update and check current_cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[ip+1][j] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip+1, j))
		{
			current_max = MAX_SUM(current_max, imperfect_stacking_energy2);
		}

		if(!pushed && COMPARE(current_max, this->x(i,j)))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i, ip);
			this->energy_loops->tb_stack->push_substr(tb_V, ip+2, j-1);
			pushed = true;
		}
	} // ip loop for enumerating all 
#endif // _TRANS_V_COAX_STACK_2_Wcoax_

	if(!pushed || !COMPARE(current_max, this->x(i, j)))
	{
		printf("Error in stoch energy traceback of WMBL(%d, %d) @ %s(%d)\n", i,j, __FILE__, __LINE__);
		exit(0);
	}

}

void t_Wcoax::stoch_energy_tb(int i, int j)
{
	t_WMB* WMB = this->energy_loops->WMB;
	t_W* W = this->energy_loops->W;

	bool pushed = false;

	double random_cumulative = MUL(this->energy_loops->sampling_math->random_double_exc_0_inc_1(), this->x(i,j));
	double current_cumulative = ZERO;

	t_V* V = this->energy_loops->V;

	double multibranch_helix_init_energy = this->energy_loops->thermo_pars->per_helix_penalty;
	double two_multibranch_helix_init_energy = MUL(multibranch_helix_init_energy, multibranch_helix_init_energy);
	double unpaired_nuc_in_mbl_energy = this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty;
	double two_unpaired_nuc_in_mbl_energy = MUL(this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty, 
												this->energy_loops->thermo_pars->unpaired_nuc_in_MBL_penalty);

#ifdef _TRANS_V_COAX_STACK_2_Wcoax_
	for(int ip = i + MIN_LOOP+1; ip < j-MIN_LOOP-1; ip++)
	{
		// Find minimum coaxially stacked configuration:
		// 1) Immediate stacking of helices: Coaxial stacking of V arrays.
		// 2) Stacking of (i+1, ip-1) and (ip+2, j) by non-canonical base pair at (i,ip+1).
		// 3) Stacking of (i,ip) and (ip+2, j-1) by non-canonical base pair at (ip+1, j).


		// Consider all 3 cases of stacking and return max/sum energy.
		double perfect_stacking_energy = MUL6(V->x(i,ip),
												this->energy_loops->V->x(ip+1,j),
												this->energy_loops->thermo_pars->perfect_coaxial_stack_energy(ip, i, j, ip+1),
												two_multibranch_helix_init_energy, 
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));

		// Update and check current_cumulative.
		current_cumulative = MAX_SUM(current_cumulative, perfect_stacking_energy);
		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i, ip);
			this->energy_loops->tb_stack->push_substr(tb_V, ip+1, j);
			pushed = true;
		}

		// One of the imperfect coax. stacking is by noncanonical pairing of i and ip.
		double stack_i_p_ip_n_in_coax_stack_energy = ZERO;
		double energy_imperfect_coaxial_stack1 = ZERO;
		if(ip+1 <= this->energy_loops->rna_seq->numofbases)
		{
			stack_i_p_ip_n_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(ip-1, i+1, i, ip);

			// This is the energy of coaxial stacking.
			energy_imperfect_coaxial_stack1 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);
		}

		double imperfect_stacking_energy1 = ZERO;

		imperfect_stacking_energy1 = MUL8(V->x(i+1,ip-1), 
												V->x(ip+1,j),
												stack_i_p_ip_n_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack1, 
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i+1,ip-1),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+1,j));

		// Update and check current_cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[i][ip] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip, i))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy1);
		}

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i+1, ip-1);
			this->energy_loops->tb_stack->push_substr(tb_V, ip+1, j);
			pushed = true;
		}

		// Other imperfect stacking is by noncanonical pairing of ip+1 and j.
		double stack_ipp_j_in_coax_stack_energy = ZERO;
		double energy_imperfect_coaxial_stack2 = ZERO;

		if(j-1 > ip+2)
		{
			energy_imperfect_coaxial_stack2 = this->energy_loops->thermo_pars->imperfect_coaxial_stack_energy(ip, i, j, ip+1);
			stack_ipp_j_in_coax_stack_energy = this->energy_loops->thermo_pars->mm_stack_coax_helix_energy(j-1, ip+2, ip+1, j);
		}

		double imperfect_stacking_energy2 = MUL8(V->x(i,ip), 
												V->x(ip+2,j-1), 
												stack_ipp_j_in_coax_stack_energy, 
												energy_imperfect_coaxial_stack2,
												two_multibranch_helix_init_energy, 
												two_unpaired_nuc_in_mbl_energy,
												this->energy_loops->thermo_pars->terminal_pair_penalty(i,ip),
												this->energy_loops->thermo_pars->terminal_pair_penalty(ip+2,j-1));

		// Update and check current_cumulative.
		if(this->energy_loops->folding_constraints->str_coinc_map[ip+1][j] &&
			!this->energy_loops->folding_constraints->forbid_non_v_emission(ip+1, j))
		{
			current_cumulative = MAX_SUM(current_cumulative, imperfect_stacking_energy2);
		}

		if(!pushed && GEQ(current_cumulative, random_cumulative))
		{
			this->energy_loops->tb_stack->push_substr(tb_V, i, ip);
			this->energy_loops->tb_stack->push_substr(tb_V, ip+2, j-1);
			pushed = true;
		}
	} // ip loop for enumerating all 
#endif // _TRANS_V_COAX_STACK_2_Wcoax_

	if(!pushed || !COMPARE(current_cumulative, this->x(i, j)))
	{
		printf("Error in stoch energy traceback of WMBL(%d, %d) @ %s(%d)\n", i,j, __FILE__, __LINE__);
		exit(0);
	}	
}
