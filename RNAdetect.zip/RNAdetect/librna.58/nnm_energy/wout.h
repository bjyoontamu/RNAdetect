#ifndef _WOUT_
#define _WOUT_

class t_structure;
class t_energy_array;
class t_energy_loops;

class t_Wout
{
public:
	t_Wout(t_energy_loops* _energy_loops);
	~t_Wout();

	// This is the energy storage.
	double* energy_array;
	double* ext_energy_array;

	double mem_usage;

	// RNA sequence.
	t_structure* rna_seq;

	// Minimum energy loops that this WL array belongs to.
	// By gaining access to this class, WL has access to all other arrays.
	t_energy_loops* energy_loops;

	double (*MAX_SUM)(double,double);

	// Compute WMBL for a subsequence.
	void compute();
	void compute_ext();
	void compute_ext_V_dependencies();

	void min_energy_tb(int j);
	void stoch_energy_tb(int j);

	// Accession function.
	double& x(int j);
	double& x_ext(int j);
};

#endif // _WOUT_



