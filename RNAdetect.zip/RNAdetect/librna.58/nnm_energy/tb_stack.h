#ifndef _TB_STACK_
#define _TB_STACK_

#include <stack>

using namespace std;

enum{tb_V, tb_WL, tb_branchized_V, tb_W, tb_WMBL, tb_WMB, tb_Wcoax, tb_Wout, n_arrays};

static char array_names[n_arrays][100] = {"tb_V", "tb_WL", "tb_WLclosed", "tb_W", "tb_WMBL", "tb_WMB", "tb_Wcoax", "tb_Wout"};

struct t_tb_substructure
{
	int i;
	int j;
	int tb_array_id;
};

class t_tb_stack
{
private:
	stack<t_tb_substructure*>* tb_stack;

public:
	t_tb_stack();
	~t_tb_stack();

	void push_substr(int tb_array_id, int i, int j);
	void pop_substr(int& tb_array_id, int& i, int& j);

	int size();
};

#endif // _TB_STACK_


