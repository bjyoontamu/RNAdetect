#ifndef _PHMM_PATHS_
#define _PHMM_PATHS_

// Relative to the data directory.
#define PHMM_FAM_PARS_FP "fam_hmm_pars.dat"

#endif // _PHMM_PATHS_
