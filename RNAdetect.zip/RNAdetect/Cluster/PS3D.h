extern void ps3d_Preambel(FILE *fp, float view[3], float axis[3], char *projtype);
extern void PS_DrawSimplifiedBox(float X,float Y, float Z, float T, float P, FILE *fp);
